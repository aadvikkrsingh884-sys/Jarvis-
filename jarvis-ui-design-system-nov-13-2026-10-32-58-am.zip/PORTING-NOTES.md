# Android Porting & Rendering Notes (`PORTING-NOTES.md`)

**Target Hardware:** Samsung Galaxy A50s (Exynos 9611 / Mali-G72 MP3 GPU, Android 11, 4 GB RAM).

## 1. Fake Glass Surface (Zero Heavy Blur)
Real-time `RenderEffect.createBlurEffect` across multiple scrolling cards causes severe frame drops on Mali-G72 and isn't supported below Android 12 (API 31). Instead, Jarvis uses layered Compose `drawBehind` + `border`:
- **Base Fill:** Vertical `Brush.verticalGradient` from `surfaceTop` (`alpha 0.72` dark / `0.94` light) to `surfaceBottom` (`alpha 0.52` dark / `0.86` light).
- **1 dp Specular Top Rim:** `Modifier.drawWithContent` or `1.dp` gradient border (`Color.White.copy(alpha = 0.22f)` at top fading to `0.04f` at bottom; in Light Mode, pure white `#FFFFFF` top highlight + soft tinted shadow below).
- **Soft Depth Shadow:** `Modifier.shadow(elevation = 8.dp, shape = RoundedCornerShape(24.dp), ambientColor = accent.copy(0.25f), spotColor = Color.Black.copy(0.45f))`.
- **Blur Budget:** Maximum `2` blurred or heavy-scrim surfaces simultaneously (e.g., modal bottom sheet scrim + floating orb backdrop).

## 2. 60 fps Animation Rules (Mali-G72 Safe)
- Animate **only** `graphicsLayer { translationX; translationY; scaleX; scaleY; rotationZ; alpha }` and `Modifier.alpha()`.
- **Never** animate `width`, `height`, `padding`, or `shadowElevation` per frame inside infinite loops. Use `scaleX`/`scaleY` on pre-sized `Box` or `Canvas` primitives.
- Respect `reduceMotion` toggle by collapsing infinite `rememberInfiniteTransition` floats to static rest values (`0f` / `1f`).

## 3. Themed Background Styles
Implemented in `ThemedBackground` (`Theme.kt`) using lightweight `Canvas`:
1. **Aurora Blobs (`aurora_blobs`):** 3 radial gradient circles animated purely via `translate` / `scale` transforms inside `Canvas` (`drawCircle` with `Brush.radialGradient`).
2. **Cyber Grid (`cyber_grid`):** Static `1.dp` grid lines (`alpha = 0.08f`) + 1 horizontal scan line translated vertically via `infiniteTransition` (`0f..1f * size.height`).
3. **Matrix Rain (`matrix_rain`):** Capped at `24` columns (well under the `40` particle ceiling) drawing crisp `JetBrainsMono` / vertical glyph bars with alpha decay—zero bitmap allocation per frame.
4. **Plain Gradient (`plain_gradient`):** Single vertical `Brush.verticalGradient(listOf(bgTop, bgBottom))` with subtle top accent radial wash.

## 4. Bundled Typography & Devanagari Support
Fonts are bundled locally in `app/src/main/res/font/`:
- `sora.ttf` (`SoraFontFamily`)
- `plus_jakarta_sans.ttf` (`PlusJakartaFontFamily`)
- `jetbrains_mono.ttf` (`JetBrainsMonoFontFamily`)
- `noto_sans_devanagari.ttf` (`NotoDevanagariFontFamily`)
This prevents Samsung OneUI system font overrides (such as handwritten system fonts) from leaking into the UI.

## 5. CharacterStage Drop-In Replacement
The prototype `CharacterStage.kt` renders layered vector/Canvas portraits per role (`base`, `eyes`, `mouth viseme`, `expression overlay`) inside the exact normalized anchor boxes defined in `SPEC.md`. When final PART C PNG/WebP assets are ready, replace the `Canvas` draw blocks in each slot with `Image(painterResource(id = ...))`—all breathing, blinking, sway, lip-sync, and `400 ms` cross-fade transitions continue to work without layout changes.

## 6. Voice Feedback-Loop & Echo Protection
- **Speaker Route:** While `AssistantState == SPEAKING` and `AudioRoute == SPEAKER`, `micState` automatically switches to `PAUSED`, the user caption line displays `"(mic paused)"`, and incoming audio frames are gated so no echo chat bubbles are created.
- **Headphones / Bluetooth Route:** Full-duplex barge-in enabled. Shows `"Headphones connected: you can interrupt me."` User speech triggers `INTERRUPTED` state, halting TTS within `150 ms` and showing the `"Interrupted"` status pill.
