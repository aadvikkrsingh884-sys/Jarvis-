# Jarvis UI/UX Specification (`SPEC.md`)

**Target Device:** Samsung Galaxy A50s (1080 × 2340 px, 412 × 915 dp, Android 11, 4 GB RAM, Mali-G72 GPU)  
**Grid & Spacing:** 4 dp base grid | Screen Margin: `20 dp` | Card Padding: `16 dp` | Section Gap: `24 dp`  
**Minimum Touch Target:** `48 dp × 48 dp` | **Minimum Text Size:** `12 sp` (tested up to `130%` font scale)

---

## 1. Navigation Shell & Viewport Frame
- **Prototype Viewport Frame:** Centered `412 × 915 dp` container with optional device bezel toggle and live width switcher (`360 dp | 412 dp | 480 dp`), plus full-bleed native Android mode.
- **Bottom Navigation Bar:** Height `72 dp` + `WindowInsets.navigationBars`.
  - Slots: `Home` | `Chat` | `[TALK 64 dp FAB]` | `Create` | `Settings`.
  - **TALK Center Button:** `64 dp` diameter, raised `-20 dp` above the bar top edge. States: `idle` (mic icon + role gradient), `listening` (pulsing halo ring + animated wave), `speaking`/`thinking` (stop square icon), `connecting` (circular spinner), `muted`/`error` (semantic badge).
  - Labels: `12 sp` Plus Jakarta Sans Medium, active tab highlighted with pill indicator (`height: 32 dp`, `radius: 999 dp`).

---

## 2. `<CharacterStage>` Specification (PART C Drop-In Ready)

`<CharacterStage>` is a layered, transform-only animated container (`clipToBounds`, `380 dp` height on Home Hero, `460 dp` height in Live Voice Mode).

### Exact Layer Stack (Bottom to Top)
| Layer # | Slot ID | Size (dp / aspect) | Anchor Point | Animation & Behaviour |
|---|---|---|---|---|
| **0** | `layer_bg_atmosphere` | `fillMaxSize()` | `(0.5, 0.5)` Center | Cross-fades (`400 ms`) per role's `backgroundMood` |
| **1** | `layer_rim_glow` | `320 × 320 dp` | `(0.5, 0.42)` | Radial accent glow; scales `1.0 → 1.08` when `listening` |
| **2** | `layer_base_portrait` | `280 × 360 dp` | `(0.5, 1.0)` Bottom-Center | Idle breath `scaleY 1.0 → 1.018` (`3800 ms`), head sway `rotationZ ±1.4°` (`6200 ms`) |
| **3** | `layer_eyes` | `96 × 32 dp` | `(0.5, 0.34)` Face Upper | Swaps `eyes_open` / `eyes_closed` every `3000–6000 ms` (`110 ms` blink) |
| **4** | `layer_mouth_viseme` | `56 × 28 dp` | `(0.5, 0.46)` Face Lower | Cycles `closed`, `small_open`, `wide_open`, `round_o`, `smile_open` at `110 ms` cadence while `speaking` |
| **5** | `layer_expression_overlay` | `280 × 360 dp` | `(0.5, 1.0)` | Role accessories (Mentor glasses, Best Friend headset, Jarvis collar) + mood overlays (`happy`, `sad`, `angry`, `surprised`, `thinking` shimmer, `listening` ear-ring, `love/warm`, `sleepy/idle`) |
| **6** | `layer_bottom_vignette` | `fillMaxWidth() × 120 dp` | `(0.5, 1.0)` | Gradient scrim into `bgBottom` so foreground HUD text passes `4.5:1` contrast |

### Drop-In Asset Naming Convention (PART C)
For each role `<role_id>` (`jarvis`, `companion`, `big_brother`, `little_brother`, `sister`, `best_friend`, `mentor`, `listener`):
- `char_<role_id>_bg.png` (or `.webp`)
- `char_<role_id>_base.png`
- `char_<role_id>_eyes_open.png`, `char_<role_id>_eyes_closed.png`
- `char_<role_id>_mouth_closed.png`, `_small.png`, `_wide.png`, `_round.png`, `_smile.png`
- `char_<role_id>_overlay_<expression>.png`

---

## 3. Screen-by-Screen Component Tree & Dimensions

### 7.1 Splash & Onboarding (`SplashAndOnboardingScreen.kt`)
- **Splash:** Full-screen Cosmic Nebula gradient (`#050314 → #170B3B`), zero white flash (`android:windowBackground`). Rotating dual-arc ring (`120 dp`, Electric Violet `#8B5CF6` + Cyber Mint `#00F5D4`) framing Jarvis's cosmic portrait orb, `"JARVIS"` wordmark (`Sora 700, 32/38`), tagline `"Think. Talk. Get things done."` (`15/22`), `3 dp` linear progress bar (`radius: 999 dp`).
- **Onboarding (4 Cards):** Horizontal pager / stepped cards (`radius: 32 dp`, `padding: 20 dp`):
  1. Meet Jarvis
  2. Choose your role and look
  3. Give permissions step by step
  4. Say your first command
  - Top-right `"Skip"` tertiary button (`48 dp` min target), bottom `"Next"` / `"Start Setup"` primary `56 dp` gradient button.

### 7.2 Setup Wizard (`SetupWizardScreen.kt`)
- **8-Step Cards + Readiness Screen:** Step indicator (`8` pills), card (`radius: 24 dp`, `padding: 20 dp`), friendly 1-line rationale (`15/22`), primary action button (`56 dp`), live status pill (`Done` / `Not yet`), and `Skip` button (`48 dp`).
- **Steps:** (1) AI Key (`Get free key`, paste field, `Test key`), (2) Microphone, (3) Accessibility (phone control), (4) Display over other apps, (5) Notification access, (6) Battery unrestricted (Samsung: Never sleeping apps), (7) Contacts/Phone/Camera/Location/Media, (8) Optional 3×3 Screen-lock pattern + Voice enrolment.
- **Readiness Summary:** Circular progress ring (`112 dp`, `stroke: 10 dp`) + 8-row checklist.

### 7.3 Home (`HomeScreen.kt`)
- **Top Bar (`56 dp`):** Greeting `"Good evening, Aadvik"` (`Sora 600, 22/28`), **Status Pill** (long-press opens hidden Debug Panel), compact Battery (`%`) and Connection indicator icons with labels.
- **Hero (`360 dp`):** Swipeable `CharacterStage` with high-detail anime-realistic portraits (`char_jarvis_hoodie`, `char_jarvis_cosmic_banner`, and custom portraits for all 8 roles), rotating Arc-HUD rings, breathing/sway `graphicsLayer` motion, 1-tap `Cosmic / Hoodie` variant toggle, and quick Role/Theme sheet buttons.
- **Jarvis Autopilot & Game Copilot Strip:** 1-tap Iron Man automation launchers for **BGMI 60FPS**, **Free Fire**, **Minecraft Bot**, **Auto-Unlock**, and **WhatsApp Bot** opening the live Mission HUD.
- **Cosmic Insights Sparkline Card (`98.4 Sync Score`):** Glowing spline chart, Deep Work focus metric, Efficiency %, and active Streak counter.
- **Live Voice HUD Card (`radius: 24 dp`):** Animated waveform (`listening`), lip-sync cadence badge (`speaking`), shimmer bar (`thinking`), and 2-line last caption.
- **Quick Mode Chips:** Horizontal row with `24 dp` right-edge fade hint (`Music`, `Study`, `Journal`, `Documents`, `Off`), `height: 40 dp`, `radius: 999 dp`, `minWidth` unconstrained so labels never clip at `130%` scale.
- **Intelligent Widgets Grid (7.14):** 2-column adaptive grid (`12 dp` gap) of all 8 widgets (`Weather`, `Today`, `Mood`, `Battery`, `Reminders`, `Music`, `Device Status`, `Quick Toggles`), styled uniquely per active role & theme, each supporting `Ready`, `Loading`, `Empty`, `Error`, `Offline` states.
- **Quick Actions Grid:** 4×2 grid (`Unlock`, `Call`, `WhatsApp`, `YouTube`, `Camera`, `Flashlight`, `Timer`, `Screenshot`), `48 dp+` touch targets, Lucide-style outline icons + `12 sp` labels.
- **Ask Bar:** Glass pill (`height: 56 dp`, `radius: 16 dp`) with text field, mic icon button (`48 dp`), and send button (`48 dp`).

### 7.4 Live Voice Mode (`LiveVoiceScreen.kt`)
- Full-screen overlay (`padding: 20 dp`, safe drawing insets).
- Giant `CharacterStage` (`420 dp`), radial soft vignette.
- **Feedback-Loop & Echo UX:**
  - Persistent Mic State badge: `Live` | `Paused (Jarvis is speaking)` | `Muted` | `Blocked`.
  - Two-line Captions: User line shows `"(mic paused)"` when speaking through phone speaker; Headphones route shows `"Headphones: you can interrupt me"` banner and enables `"Simulate Interrupt"` (`<150 ms` stop + `"Interrupted"` pill).
  - `"Echo protection: on"` status chip + compact live mic level meter.
- **Bottom Control Bar:** 5 `48 dp+` icon+label buttons (`Mute`, `Stop`, `Camera`, `Keyboard`, `Switch Role`).

### 7.5 Chat & Coding (`ChatAndCodingScreen.kt`)
- Top `JarvisSegmentedControl`: `Chat | Coding`.
- **Chat Tab:** User bubbles (accent tint, right-aligned), Assistant bubbles (glass surface, left-aligned with Role avatar), System event cards (distinct bordered banner e.g. `"New WhatsApp message from Rahul"`), typing/thinking indicator, long-press timestamp reveal + action bar (`Copy`, `Speak again`, `Save to journal`).
- **Coding Tab:** Prompt input card, `"Build App"` `56 dp` primary button, interactive live preview frame, build history list, action row (`Save ZIP`, `Share`, `Change`), empty-state suggestion chips.

### 7.6 Create Hub & 7.13 Modes (`CreateHubScreen.kt`)
- 2-column grid of 6 Create cards (`Website or game`, `Resume`, `Biodata`, `Letter`, `Report`, `Journal entry`).
- Interactive 3-step drawer/screen per card: **Form** (title, details, style chips) → **Progress** (animated step checklist) → **Result** (rendered preview + `Save`, `Share`, `Edit with Jarvis`).
- Horizontal **Recent Creations** gallery with scroll fade + quick launchers for **Journal Timeline**, **Study Mode** (`25m` focus timer ring, interactive quiz card, streak badge), and **Music Mode** (now-playing card, transport controls, queue chips).

### 7.7 Mission HUD, 7.8 Confirmation Sheet, 7.9 Camera Vision (`ModalsAndSheets.kt`)
- **Mission HUD:** Floating card/sheet with task title, step timeline, live status (`"Mining at Y -58"`), game badges (`Health 18/20`, `Hunger 16/20`, `Threat: Low`), elapsed timer, circular progress ring, `56 dp` red Stop button, and Success/Failure completion states.
- **Confirmation Sheet:** Action icon, plain-language prompt (`"Want me to send it?"`), target details, `30s` countdown ring, `"Don't ask again for 5 minutes"` checkbox (low-risk items only), `No` (default focused, outlined/filled contrast) and `Yes` buttons.
- **Camera Vision:** Simulated viewfinder glass frame with grid reticles, floating `"Describe what you see"` primary button, Jarvis answer caption card, Flip Camera & Close (`48 dp`), and `"Press TALK first"` empty state when session is idle.

### 7.10 Overlay Components Artboard & Section 5 Design System (`SettingsAndSystemScreens.kt`)
- **Overlay Components Artboard:** Simulated phone wallpaper canvas demonstrating: `84 dp` draggable Floating Orb (tap to mute, long-press to open, state colors), Live Caption Pill, Notification Card (app icon, sender, text, `Reply` & `Dismiss`), and Mission Mini-HUD.
- **Design System Screen:** Dedicated screen showcasing all 29 components across all 6 states (`Default`, `Pressed`, `Disabled`, `Loading`, `Error`, `Success`).

### 7.11 Grouped Settings (`SettingsAndSystemScreens.kt`)
12 expandable/navigable groups with icons, subtitles, and live status badges:
1. **AI Provider** (6 cards: Gemini, Groq, OpenRouter, Cerebras, Mistral, OpenAI with `Free`/`Paid` tags, `Get free key`, key input, `Test key`, model picker)
2. **Voice** (30-voice picker including Indian English/Hindi TTS + Play sample, language selector, Reply pause slider `0.5s – 3.0s`, headphones tip)
3. **Roles & Characters** (8-role grid, tap to preview, per-role voice, Auto-switch toggle, emotion style)
4. **Look** (18-theme live preview grid, background style override, font scale `100%–130%`, reduce motion toggle)
5. **Avatar** (Built-in characters + 4 custom upload slots with framing crop & remove-background toggles)
6. **Phone Control** (8 permission rows with ON/OFF & `Fix` button)
7. **Screen-lock Pattern** (Interactive 3×3 drag/tap pattern pad, position/size/speed sliders, `Test unlock` result card & attempts warning)
8. **Notifications** (Master message-reading toggle + per-app switches: WhatsApp, Instagram, Telegram, Messages, Gmail)
9. **Saved Accounts** (YouTube, Instagram, Facebook, Telegram status & connect toggles)
10. **Memory & Privacy** (Save conversation toggle, Journal link, `Clear conversation`, Voice lock enrolment, `Erase everything` with type-to-confirm `"ERASE"` dialog)
11. **Diagnostics** (Connection status, model name, plain-English last error, live mic level meter, echo & half-duplex status, speaker/headphone/bluetooth route, reconnect log, `Copy report` button)
12. **About** (Version, Galaxy A50s Mali-G72 profile, shortcuts to Design System & Overlay Artboard)
