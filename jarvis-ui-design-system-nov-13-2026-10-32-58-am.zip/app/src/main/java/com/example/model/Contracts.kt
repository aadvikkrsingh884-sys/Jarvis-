package com.example.model

import androidx.annotation.DrawableRes
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap

enum class AssistantState {
    IDLE,
    CONNECTING,
    LISTENING,
    THINKING,
    SPEAKING,
    INTERRUPTED,
    MUTED,
    ERROR,
    OFFLINE
}

enum class MicState {
    LIVE,
    PAUSED,
    MUTED,
    BLOCKED
}

enum class RoleId(val id: String) {
    JARVIS("jarvis"),
    COMPANION("companion"),
    BIG_BROTHER("big_brother"),
    LITTLE_BROTHER("little_brother"),
    SISTER("sister"),
    BEST_FRIEND("best_friend"),
    MENTOR("mentor"),
    LISTENER("listener")
}

enum class Expression {
    NEUTRAL,
    HAPPY,
    SAD,
    ANGRY,
    SURPRISED,
    THINKING,
    LISTENING,
    LOVE_WARM,
    SLEEPY_IDLE
}

enum class MouthViseme {
    CLOSED,
    SMALL_OPEN,
    WIDE_OPEN,
    ROUND_O,
    SMILE_OPEN
}

data class CharacterAssets(
    val basePortraitKey: String,
    @DrawableRes val portraitResId: Int,
    @DrawableRes val altPortraitResId: Int? = null,
    @DrawableRes val portrait3dResId: Int? = null,
    val eyesOpenKey: String,
    val eyesClosedKey: String,
    val mouthVisemeSetKey: String,
    val hairStyle: String,
    val attireStyle: String,
    val hasGlasses: Boolean = false,
    val hasHeadset: Boolean = false,
    val rimHue: Color
)

data class Role(
    val id: RoleId,
    val name: String,
    val tagline: String,
    val personalityLine: String,
    val accent: Color,
    val accent2: Color,
    val voiceName: String,
    val characterAssets: CharacterAssets,
    val backgroundMood: String,
    val defaultExpression: Expression
)

enum class BackgroundStyle(val label: String) {
    COSMIC_NEBULA("Cosmic Nebula"),
    AURORA_BLOBS("Aurora Blobs"),
    CYBER_GRID("Cyber Grid"),
    MATRIX_RAIN("Matrix Rain"),
    PLAIN_GRADIENT("Plain Gradient")
}

data class ThemeSpec(
    val id: String,
    val name: String,
    val bgTop: Color,
    val bgBottom: Color,
    val accent: Color,
    val accent2: Color,
    val backgroundStyle: BackgroundStyle,
    val isLight: Boolean,
    val followsRole: Boolean = false
)

enum class LanguageMode(val code: String, val label: String) {
    EN("en", "English"),
    HI("hi", "हिन्दी"),
    HINGLISH("hinglish", "Hinglish")
}

enum class MessageKind {
    USER,
    ASSISTANT,
    SYSTEM
}

enum class AttachmentKind(val label: String) {
    PHOTO("Photo"),
    CAMERA("Camera"),
    FILE("File"),
    VOICE_NOTE("Voice"),
    SCREENSHOT("Screen")
}

data class ChatAttachment(
    val id: String,
    val kind: AttachmentKind,
    val label: String,
    val detail: String,
    val previewBitmap: ImageBitmap? = null
)

data class ChatMessage(
    val id: String,
    val kind: MessageKind,
    val text: String,
    val time: String,
    val roleId: RoleId,
    val language: LanguageMode,
    val savedToJournal: Boolean = false,
    val attachments: List<ChatAttachment> = emptyList()
)

enum class CosmicIntensity(val label: String, val starCount: Int, val nebulaAlpha: Float) {
    SUBTLE("Subtle", 18, 0.16f),
    BALANCED("Balanced", 30, 0.28f),
    HYPERDRIVE("Hyperdrive", 38, 0.42f)
}

data class TrendingSearchItem(
    val id: String,
    val title: String,
    val category: String,
    val query: String,
    val hotLabel: String
)

data class SystemBridgeNode(
    val id: String,
    val name: String,
    val subtitle: String,
    val latencyMs: Int,
    val connected: Boolean
)

data class HumanAutopilotWorkflow(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: String,
    val targetTaskId: String,
    val etaLabel: String
)

enum class TaskKind {
    GAME,
    SOCIAL,
    MEDIA,
    CREATE
}

enum class TaskStepStatus {
    PENDING,
    ACTIVE,
    DONE,
    FAILED
}

data class TaskStep(
    val id: String,
    val label: String,
    val status: TaskStepStatus
)

enum class TaskRunStatus {
    RUNNING,
    SUCCESS,
    FAILED,
    STOPPED
}

data class TaskItem(
    val id: String,
    val title: String,
    val kind: TaskKind,
    val steps: List<TaskStep>,
    val status: TaskRunStatus,
    val liveLine: String,
    val progress: Float,
    val startedAt: String,
    val elapsedSeconds: Int,
    val health: Int? = null,
    val hunger: Int? = null,
    val threat: String? = null,
    val gameBadge: String? = null
)

data class InsightsData(
    val syncScore: Float,
    val deltaLabel: String,
    val deepWorkLabel: String,
    val efficiencyPct: Int,
    val streakDays: Int,
    val sparkline: List<Float>
)

enum class WidgetModeState {
    READY,
    LOADING,
    EMPTY,
    ERROR,
    OFFLINE
}

data class WeatherWidgetData(
    val tempC: Int,
    val condition: String,
    val highC: Int,
    val lowC: Int,
    val rainChancePct: Int,
    val city: String,
    val state: WidgetModeState = WidgetModeState.READY
)

data class TodayWidgetData(
    val dateLabel: String,
    val nextEvent: String,
    val nextAlarm: String,
    val state: WidgetModeState = WidgetModeState.READY
)

data class MoodWidgetData(
    val label: String,
    val summary: String,
    val suggestedRoleId: RoleId,
    val state: WidgetModeState = WidgetModeState.READY
)

data class BatteryWidgetData(
    val percent: Int,
    val isCharging: Boolean,
    val estimatedTime: String,
    val state: WidgetModeState = WidgetModeState.READY
)

data class ReminderItem(
    val id: String,
    val title: String,
    val dueTime: String,
    val done: Boolean = false
)

data class ReminderWidgetData(
    val items: List<ReminderItem>,
    val state: WidgetModeState = WidgetModeState.READY
)

data class MusicWidgetData(
    val title: String,
    val artist: String,
    val isPlaying: Boolean,
    val progress: Float,
    val queue: List<String>,
    val state: WidgetModeState = WidgetModeState.READY
)

data class DeviceStatusWidgetData(
    val wifiOn: Boolean,
    val mobileDataOn: Boolean,
    val bluetoothOn: Boolean,
    val state: WidgetModeState = WidgetModeState.READY
)

data class QuickTogglesData(
    val flashlightOn: Boolean,
    val volumeHigh: Boolean,
    val dndOn: Boolean,
    val state: WidgetModeState = WidgetModeState.READY
)

data class PermissionStatus(
    val key: String,
    val label: String,
    val why: String,
    val granted: Boolean,
    val fixAction: String,
    val optional: Boolean = false
)

enum class AudioRoute(val label: String) {
    SPEAKER("Phone Speaker"),
    HEADPHONES("Wired Headphones"),
    BLUETOOTH("Bluetooth Audio")
}

data class DiagnosticsData(
    val connection: String,
    val modelName: String,
    val lastError: String,
    val micLevel: Float,
    val route: AudioRoute,
    val echoSuspected: Boolean,
    val halfDuplexMode: Boolean,
    val reconnectLog: List<String>
)

data class AiProviderSpec(
    val id: String,
    val name: String,
    val isFree: Boolean,
    val models: List<String>,
    val selectedModel: String,
    val apiKey: String,
    val keyTestedOk: Boolean?,
    val portalHint: String
)

data class VoiceSpec(
    val id: String,
    val name: String,
    val accent: String,
    val style: String,
    val isIndianTts: Boolean
)

enum class CreateProjectType(val id: String, val title: String, val subtitle: String) {
    WEBSITE_GAME("website", "Website or game", "Interactive web app or mini game"),
    RESUME("resume", "Resume", "ATS-ready student or tech CV"),
    BIODATA("biodata", "Biodata", "Clean Indian family or academic format"),
    LETTER("letter", "Letter", "Formal application or personal note"),
    REPORT("report", "Report", "Structured lab or project summary"),
    JOURNAL_ENTRY("journal", "Journal entry", "Reflective mood-tagged daily log")
}

data class CreatedArtifact(
    val id: String,
    val type: CreateProjectType,
    val title: String,
    val style: String,
    val previewSummary: String,
    val createdAt: String
)

data class JournalEntry(
    val id: String,
    val dateLabel: String,
    val mood: String,
    val title: String,
    val body: String,
    val roleId: RoleId
)

data class StudyQuizCard(
    val id: String,
    val subject: String,
    val question: String,
    val options: List<String>,
    val correctIndex: Int
)

data class BuildHistoryItem(
    val id: String,
    val prompt: String,
    val title: String,
    val timestamp: String,
    val summary: String,
    val accent: Color
)

data class ConfirmationRequest(
    val id: String,
    val actionTitle: String,
    val targetDescription: String,
    val isLowRisk: Boolean,
    val actionType: String
)

data class AppNotificationItem(
    val id: String,
    val appName: String,
    val sender: String,
    val text: String,
    val time: String
)

enum class QuickMode(val label: String) {
    OFF("Off"),
    MUSIC("Music"),
    STUDY("Study"),
    JOURNAL("Journal"),
    DOCUMENTS("Documents")
}

enum class EdgeErrorBanner(val label: String) {
    NONE("None"),
    NO_INTERNET("No internet"),
    INVALID_API_KEY("Invalid AI key"),
    FREE_LIMIT("Free limit reached"),
    MIC_BUSY("Microphone busy"),
    ACCESSIBILITY_OFF("Accessibility off"),
    PERMISSION_DENIED("Permission denied"),
    RECONNECTING("Session dropped (reconnecting)")
}

enum class MainTab {
    HOME,
    CHAT,
    CREATE,
    SETTINGS
}

enum class SubScreen {
    NONE,
    SETUP_WIZARD,
    DESIGN_SYSTEM,
    OVERLAY_ARTBOARD,
    JOURNAL_TIMELINE,
    STUDY_MODE,
    MUSIC_MODE,
    COMMAND_CENTER
}

enum class ComponentDemoState(val label: String) {
    DEFAULT("Default"),
    PRESSED("Pressed"),
    DISABLED("Disabled"),
    LOADING("Loading"),
    ERROR("Error"),
    SUCCESS("Success")
}
