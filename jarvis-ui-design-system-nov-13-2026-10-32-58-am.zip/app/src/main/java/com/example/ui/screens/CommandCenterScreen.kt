package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.MockData
import com.example.model.BackgroundStyle
import com.example.model.CosmicIntensity
import com.example.ui.components.*
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalJarvisTokens
import com.example.viewmodel.JarvisUiState
import com.example.viewmodel.JarvisViewModel

@Composable
fun CommandCenterScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    BackHandler { viewModel.closeSubScreen() }

    val activeBridges = uiState.systemBridges.count { it.connected }

    JarvisPullToRefreshBox(
        isRefreshing = uiState.isRefreshing,
        onRefresh = { viewModel.refreshPage("System Brain") },
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(top = 12.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header with user J.A.R.V.I.S. Arc Logo
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    JarvisIconButton(
                        icon = Icons.AutoMirrored.Rounded.ArrowBack,
                        contentDescription = "Back",
                        onClick = { viewModel.closeSubScreen() }
                    )
                    Image(
                        painter = painterResource(id = R.drawable.img_jarvis_user_logo),
                        contentDescription = "Jarvis Core Logo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, tokens.accent2, CircleShape)
                    )
                Column {
                    JarvisText(text = "System Brain", style = JarvisTypographyTokens.Title.copy(fontSize = 20.sp))
                    JarvisText(
                        text = "$activeBridges/${uiState.systemBridges.size} OS Bridges • Human Autonomy",
                        style = JarvisTypographyTokens.Caption,
                        color = tokens.accent2
                    )
                }
            }
            JarvisStatusPill(
                state = uiState.assistantState,
                label = "LIVE OS",
                onClick = { viewModel.setLiveVoiceOpen(true) },
                onLongPress = { viewModel.setDebugPanelVisible(true) }
            )
        }

        // Quick Launchers for Welcome Opening Page & Loading HUD
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            JarvisChip(
                label = "Welcome Page",
                selected = false,
                icon = Icons.Rounded.WavingHand,
                onClick = { viewModel.openWelcomeScreen() }
            )
            JarvisChip(
                label = "Loading HUD",
                selected = false,
                icon = Icons.Rounded.Autorenew,
                onClick = { viewModel.triggerLoadingPreview() }
            )
            JarvisChip(
                label = "Onboarding Tour",
                selected = false,
                icon = Icons.Rounded.AutoAwesome,
                onClick = { viewModel.openOnboarding() }
            )
        }

        // 0. Real System-Level Automation Console (App Launching, Screen-Lock, Notification Manager)
        SystemAutomationConsoleSection(uiState = uiState, viewModel = viewModel)

        // 1. Cosmic Theme Engine Studio
        JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp, accentTint = tokens.accent) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    JarvisText(text = "Cosmic Theme Engine", style = JarvisTypographyTokens.Subtitle)
                    JarvisText(text = "${uiState.activeTheme.name} • ${MockData.themes.size} themes", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                }
                JarvisChip(
                    label = "All Themes",
                    selected = true,
                    icon = Icons.Rounded.Palette,
                    onClick = { viewModel.setThemeSheetVisible(true) }
                )
            }
            Spacer(Modifier.height(12.dp))
            JarvisText(text = "Starfield & Nebula Intensity", style = JarvisTypographyTokens.Caption, color = tokens.textSecondary)
            Spacer(Modifier.height(6.dp))
            JarvisSegmentedControl(
                options = CosmicIntensity.entries.map { it.label },
                selectedIndex = CosmicIntensity.entries.indexOf(uiState.cosmicIntensity),
                onSelect = { viewModel.setCosmicIntensity(CosmicIntensity.entries[it]) }
            )
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                JarvisText(text = "Glass Card Frost", style = JarvisTypographyTokens.Caption, color = tokens.textSecondary)
                JarvisText(text = "${(uiState.glassFrost * 100).toInt()}%", style = JarvisTypographyTokens.Caption.copy(fontFamily = JetBrainsMonoFontFamily), color = tokens.accent2)
            }
            Slider(
                value = uiState.glassFrost,
                onValueChange = { viewModel.setGlassFrost(it) },
                valueRange = 0.45f..0.96f,
                colors = SliderDefaults.colors(thumbColor = tokens.accent2, activeTrackColor = tokens.accent)
            )
            JarvisText(text = "Backdrop Engine", style = JarvisTypographyTokens.Caption, color = tokens.textSecondary)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val activeBg = uiState.bgStyleOverride ?: uiState.activeTheme.backgroundStyle
                BackgroundStyle.entries.forEach { bg ->
                    JarvisChip(label = bg.label, selected = activeBg == bg, onClick = { viewModel.setBackgroundOverride(bg) })
                }
            }
        }

        // 2. Deep Android OS Integration Matrix
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisText(text = "Deep Android Integrations", style = JarvisTypographyTokens.Subtitle)
                JarvisText(text = "Galaxy A50s Bridge", style = JarvisTypographyTokens.Caption, color = tokens.accent2)
            }
            uiState.systemBridges.forEach { node ->
                JarvisGlassCard(elevationLevel = 1, cornerRadius = 20.dp, contentPadding = PaddingValues(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (node.connected) tokens.accent.copy(alpha = 0.18f) else tokens.surfaceCardBottom),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (node.connected) Icons.Rounded.Hub else Icons.Rounded.LinkOff,
                                contentDescription = node.name,
                                tint = if (node.connected) tokens.accent2 else tokens.textMuted,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                JarvisText(text = node.name, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                                Surface(shape = RoundedCornerShape(999.dp), color = tokens.success.copy(alpha = 0.16f)) {
                                    JarvisText(
                                        text = "${node.latencyMs}ms",
                                        style = JarvisTypographyTokens.Caption.copy(fontSize = 10.sp, fontFamily = JetBrainsMonoFontFamily),
                                        color = tokens.success,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            JarvisText(text = node.subtitle, style = JarvisTypographyTokens.Caption, color = tokens.textMuted, maxLines = 2)
                        }
                        Switch(checked = node.connected, onCheckedChange = { viewModel.toggleSystemBridge(node.id) })
                    }
                }
            }
        }

        // 3. Human-Inside-Phone Multi-App Workflows
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            JarvisText(text = "Human-Inside-Phone Workflows", style = JarvisTypographyTokens.Subtitle)
            MockData.humanWorkflows.forEach { wf ->
                JarvisGlassCard(
                    elevationLevel = 2,
                    cornerRadius = 20.dp,
                    onClick = { viewModel.launchTaskById(wf.targetTaskId) }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Surface(shape = RoundedCornerShape(999.dp), color = tokens.accent.copy(alpha = 0.18f)) {
                                    JarvisText(
                                        text = wf.category.uppercase(),
                                        style = JarvisTypographyTokens.Caption.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                        color = tokens.accent2,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                                JarvisText(text = "• ${wf.etaLabel}", style = JarvisTypographyTokens.Caption, color = tokens.success)
                            }
                            Spacer(Modifier.height(4.dp))
                            JarvisText(text = wf.title, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 15.sp))
                            JarvisText(text = wf.subtitle, style = JarvisTypographyTokens.Caption, color = tokens.textSecondary, maxLines = 2)
                        }
                        Spacer(Modifier.width(8.dp))
                        JarvisIconButton(
                            icon = Icons.Rounded.PlayArrow,
                            contentDescription = "Run ${wf.title}",
                            containerColor = tokens.accent,
                            tint = tokens.onAccent,
                            onClick = { viewModel.launchTaskById(wf.targetTaskId) }
                        )
                    }
                }
            }
        }

        // 4. Trending Searches 2026
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            JarvisText(text = "Trending Searches & Live Pulse", style = JarvisTypographyTokens.Subtitle)
            MockData.trendingSearches.forEach { trend ->
                Surface(
                    onClick = { viewModel.launchTrendingSearch(trend) },
                    shape = RoundedCornerShape(18.dp),
                    color = tokens.surfaceCardTop,
                    border = BorderStroke(1.dp, tokens.borderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Rounded.TrendingUp, contentDescription = null, tint = tokens.accent2)
                        Column(modifier = Modifier.weight(1f)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                JarvisText(text = trend.title, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                                Surface(shape = RoundedCornerShape(999.dp), color = tokens.accent2.copy(alpha = 0.18f)) {
                                    JarvisText(
                                        text = trend.hotLabel,
                                        style = JarvisTypographyTokens.Caption.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                        color = tokens.accent2,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            JarvisText(text = trend.query, style = JarvisTypographyTokens.Caption, color = tokens.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Icon(Icons.Rounded.NorthEast, contentDescription = "Ask Jarvis", tint = tokens.textMuted, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
    }
    }
}
