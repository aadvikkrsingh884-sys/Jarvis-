package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.ViewInAr
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AssistantState
import com.example.model.Expression
import com.example.model.Role
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalJarvisTokens
import kotlinx.coroutines.delay
import kotlin.math.sin
import kotlin.random.Random

/**
 * Unobstructed 3D Holographic <CharacterStage> renderer supporting interactive 3D tilt,
 * 3D CGI vs Anime look toggle, holographic orbital projector rings, and 60fps breathing/sway.
 * Never places obstructing pop-ups over the character's face or torso.
 */
@Composable
fun CharacterStage(
    role: Role,
    assistantState: AssistantState,
    expressionOverride: Expression? = null,
    height: Dp = 368.dp,
    compact: Boolean = false,
    useCosmicVariant: Boolean = false,
    use3dCharacter: Boolean = true,
    onToggleCosmicVariant: (() -> Unit)? = null,
    onToggle3dCharacter: (() -> Unit)? = null,
    onTap: (() -> Unit)? = null,
    onDoubleTap: (() -> Unit)? = null,
    onLongPress: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    val density = LocalDensity.current.density

    val effectiveExpression = expressionOverride ?: when (assistantState) {
        AssistantState.LISTENING -> Expression.LISTENING
        AssistantState.THINKING -> Expression.THINKING
        AssistantState.SPEAKING -> Expression.HAPPY
        AssistantState.INTERRUPTED -> Expression.SURPRISED
        AssistantState.ERROR -> Expression.SAD
        AssistantState.MUTED, AssistantState.OFFLINE -> Expression.SLEEPY_IDLE
        else -> role.defaultExpression
    }

    // Interactive 3D tilt offset (resets smoothly on release)
    var tiltTargetX by remember { mutableFloatStateOf(0f) }
    var tiltTargetY by remember { mutableFloatStateOf(0f) }
    val tiltX by animateFloatAsState(
        targetValue = tiltTargetX,
        animationSpec = spring(stiffness = 220f, dampingRatio = 0.72f),
        label = "tilt_x"
    )
    val tiltY by animateFloatAsState(
        targetValue = tiltTargetY,
        animationSpec = spring(stiffness = 220f, dampingRatio = 0.72f),
        label = "tilt_y"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "char_3d_holo")
    val breathScale = if (tokens.reduceMotion) 1f else infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.025f,
        animationSpec = infiniteRepeatable(
            animation = tween(3600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breath"
    ).value

    val ambientRotY = if (tokens.reduceMotion) 0f else infiniteTransition.animateFloat(
        initialValue = -3.8f,
        targetValue = 3.8f,
        animationSpec = infiniteRepeatable(
            animation = tween(5200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ambient_rot_y"
    ).value

    val hudRotation = if (tokens.reduceMotion) 0f else infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(14000, easing = LinearEasing)
        ),
        label = "hud_rot"
    ).value

    val pulseScale = if (tokens.reduceMotion) 1f else infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.07f,
        animationSpec = infiniteRepeatable(
            animation = tween(1150, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_ring"
    ).value

    val shimmerPhase = if (tokens.reduceMotion) 0f else infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "shimmer"
    ).value

    val interruptTurn by animateFloatAsState(
        targetValue = if (assistantState == AssistantState.INTERRUPTED) -8f else 0f,
        animationSpec = tween(130),
        label = "interrupt_turn"
    )

    var glintActive by remember { mutableStateOf(false) }
    LaunchedEffect(role.id) {
        while (true) {
            delay(Random.nextLong(3200L, 5800L))
            if (!tokens.reduceMotion) {
                glintActive = true
                delay(180L)
                glintActive = false
            }
        }
    }

    AnimatedContent(
        targetState = Triple(role, useCosmicVariant, use3dCharacter),
        transitionSpec = {
            fadeIn(tween(360)) togetherWith fadeOut(tween(360))
        },
        modifier = modifier
            .fillMaxWidth()
            .height(height)
            .pointerInput(onTap, onDoubleTap, onLongPress) {
                if (onTap != null || onDoubleTap != null || onLongPress != null) {
                    detectTapGestures(
                        onTap = { onTap?.invoke() },
                        onDoubleTap = { onDoubleTap?.invoke() },
                        onLongPress = { onLongPress?.invoke() }
                    )
                }
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragEnd = {
                        tiltTargetX = 0f
                        tiltTargetY = 0f
                    },
                    onDragCancel = {
                        tiltTargetX = 0f
                        tiltTargetY = 0f
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        tiltTargetY = (tiltTargetY + dragAmount.x * 0.14f).coerceIn(-12f, 12f)
                        tiltTargetX = (tiltTargetX - dragAmount.y * 0.12f).coerceIn(-9f, 9f)
                    }
                )
            }
            .clip(RoundedCornerShape(32.dp))
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF060416),
                        tokens.bgBottom.copy(alpha = 0.92f)
                    )
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.verticalGradient(
                    listOf(
                        role.accent2.copy(alpha = 0.75f),
                        role.accent.copy(alpha = 0.30f)
                    )
                ),
                shape = RoundedCornerShape(32.dp)
            ),
        label = "role_3d_crossfade"
    ) { (currentRole, cosmicAlt, prefer3d) ->
        val activeDrawable = when {
            prefer3d && currentRole.characterAssets.portrait3dResId != null ->
                currentRole.characterAssets.portrait3dResId
            cosmicAlt && currentRole.characterAssets.altPortraitResId != null ->
                currentRole.characterAssets.altPortraitResId
            else -> currentRole.characterAssets.portraitResId
        }

        Box(modifier = Modifier.fillMaxSize()) {
            // LAYER 0: Deep Cosmic Volumetric Glow Aura behind character
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            currentRole.accent.copy(alpha = 0.34f),
                            currentRole.accent2.copy(alpha = 0.12f),
                            Color.Transparent
                        ),
                        center = Offset(w * 0.5f, h * 0.44f),
                        radius = w * 0.65f
                    ),
                    radius = w * 0.65f,
                    center = Offset(w * 0.5f, h * 0.44f)
                )
            }

            // LAYER 1: Full Unobstructed 3D / Anime Portrait with Real 3D Perspective Tilt
            Image(
                painter = painterResource(id = activeDrawable),
                contentDescription = "${currentRole.name} 3D character",
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        cameraDistance = 16f * density
                        scaleX = breathScale
                        scaleY = breathScale
                        rotationY = ambientRotY + tiltY + interruptTurn
                        rotationX = tiltX
                        translationY = if (assistantState == AssistantState.THINKING) {
                            sin(shimmerPhase * 6.28f) * 3f
                        } else 0f
                    }
            )

            // LAYER 2: 3D Holographic Orbital Rings & Perspective Base Disc (subtle, non-obstructing)
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val cx = w * 0.5f
                val cy = h * 0.38f
                val ringRadius = minOf(w, h) * 0.42f

                val hudAlpha = when (assistantState) {
                    AssistantState.LISTENING, AssistantState.SPEAKING -> 0.58f
                    AssistantState.THINKING, AssistantState.CONNECTING -> 0.45f
                    else -> 0.22f
                }

                // Rotating upper Arc-Reactor HUD arcs
                rotate(hudRotation, pivot = Offset(cx, cy)) {
                    drawArc(
                        color = currentRole.accent2.copy(alpha = hudAlpha),
                        startAngle = 0f,
                        sweepAngle = 72f,
                        useCenter = false,
                        topLeft = Offset(cx - ringRadius * pulseScale, cy - ringRadius * pulseScale),
                        size = Size(ringRadius * 2 * pulseScale, ringRadius * 2 * pulseScale),
                        style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = currentRole.accent.copy(alpha = hudAlpha),
                        startAngle = 180f,
                        sweepAngle = 68f,
                        useCenter = false,
                        topLeft = Offset(cx - ringRadius * pulseScale, cy - ringRadius * pulseScale),
                        size = Size(ringRadius * 2 * pulseScale, ringRadius * 2 * pulseScale),
                        style = Stroke(width = 2.2.dp.toPx(), cap = StrokeCap.Round)
                    )
                }

                // 3D Perspective Floor Projection Ellipse at bottom (leaves face & chest 100% clear)
                drawOval(
                    color = currentRole.accent2.copy(alpha = hudAlpha * 0.75f),
                    topLeft = Offset(w * 0.14f, h * 0.87f),
                    size = Size(w * 0.72f, h * 0.09f),
                    style = Stroke(width = 1.6.dp.toPx())
                )
                drawOval(
                    color = currentRole.accent.copy(alpha = hudAlpha * 0.45f),
                    topLeft = Offset(w * 0.24f, h * 0.89f),
                    size = Size(w * 0.52f, h * 0.055f),
                    style = Stroke(width = 1.2.dp.toPx())
                )

                if (glintActive) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color.White.copy(alpha = 0.24f), Color.Transparent),
                            center = Offset(cx, h * 0.26f),
                            radius = w * 0.16f
                        ),
                        radius = w * 0.16f,
                        center = Offset(cx, h * 0.26f)
                    )
                }
            }

            // LAYER 3: Slim Non-Obstructing Bottom Rim Edge (just 56dp high so zero face/chest covered)
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(if (compact) 46.dp else 56.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                tokens.bgBottom.copy(alpha = if (tokens.isLight) 0.55f else 0.78f)
                            )
                        )
                    )
            )

            // LAYER 4: Top Corner Compact Telemetry & 3D Switcher Chips
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(14.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color(0xCC060416))
                        .border(1.dp, currentRole.accent.copy(alpha = 0.7f), RoundedCornerShape(999.dp))
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(currentRole.accent2)
                    )
                    JarvisText(
                        text = currentRole.name,
                        style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                    JarvisText(
                        text = "• ${effectiveExpression.name.lowercase().replace('_', ' ')}",
                        style = JarvisTypographyTokens.Caption.copy(fontSize = 10.5.sp, fontFamily = JetBrainsMonoFontFamily),
                        color = currentRole.accent2
                    )
                }

                // 3D vs Anime Look Toggle
                if (currentRole.characterAssets.portrait3dResId != null && onToggle3dCharacter != null) {
                    Surface(
                        onClick = onToggle3dCharacter,
                        shape = RoundedCornerShape(999.dp),
                        color = Color(0xCC060416),
                        border = BorderStroke(1.dp, currentRole.accent2.copy(alpha = 0.65f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Rounded.ViewInAr, contentDescription = "Toggle 3D character", tint = currentRole.accent2, modifier = Modifier.size(13.dp))
                            JarvisText(
                                text = if (prefer3d) "3D" else "2.5D",
                                style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                    }
                }

                if (!prefer3d && currentRole.characterAssets.altPortraitResId != null && onToggleCosmicVariant != null) {
                    Surface(
                        onClick = onToggleCosmicVariant,
                        shape = RoundedCornerShape(999.dp),
                        color = Color(0xCC060416),
                        border = BorderStroke(1.dp, currentRole.accent2.copy(alpha = 0.65f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(Icons.Rounded.AutoAwesome, contentDescription = "Switch portrait look", tint = currentRole.accent2, modifier = Modifier.size(13.dp))
                            JarvisText(
                                text = if (cosmicAlt) "Cosmic" else "Hoodie",
                                style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp),
                                color = Color.White
                            )
                        }
                    }
                }
            }

            // Bottom-left subtle 3D drag hint & bottom-right Live Audio speaking pill (both tiny, clear of face)
            if (!compact) {
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = Color(0xAA060416),
                    modifier = Modifier.align(Alignment.BottomStart).padding(12.dp)
                ) {
                    JarvisText(
                        text = "3D Holo • Drag to tilt • 2×Tap 3D/2.5D",
                        style = JarvisTypographyTokens.Caption.copy(fontSize = 10.sp),
                        color = currentRole.accent2,
                        modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                    )
                }
            }

            if (assistantState == AssistantState.SPEAKING) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(12.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(currentRole.accent.copy(alpha = 0.90f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.GraphicEq, contentDescription = "Speaking", tint = Color.White, modifier = Modifier.size(14.dp))
                    JarvisText(text = "LIVE AUDIO", style = JarvisTypographyTokens.Caption.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold), color = Color.White)
                }
            }
        }
    }
}
