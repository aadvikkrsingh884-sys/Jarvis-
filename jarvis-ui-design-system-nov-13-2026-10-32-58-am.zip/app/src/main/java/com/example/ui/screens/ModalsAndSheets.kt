package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.MockData
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.LocalJarvisTokens
import com.example.viewmodel.JarvisUiState
import com.example.viewmodel.JarvisViewModel

@Composable
fun EdgeErrorBannerCard(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    val msg = when (uiState.edgeBanner) {
        EdgeErrorBanner.NO_INTERNET -> MockData.copy("error_no_internet", uiState.language)
        EdgeErrorBanner.INVALID_API_KEY -> MockData.copy("error_invalid_key", uiState.language)
        EdgeErrorBanner.FREE_LIMIT -> MockData.copy("error_rate_limit", uiState.language)
        EdgeErrorBanner.MIC_BUSY -> MockData.copy("error_mic_busy", uiState.language)
        EdgeErrorBanner.ACCESSIBILITY_OFF -> MockData.copy("error_accessibility_off", uiState.language)
        EdgeErrorBanner.PERMISSION_DENIED -> MockData.copy("error_permission_denied", uiState.language)
        EdgeErrorBanner.RECONNECTING -> "${MockData.copy("reconnecting_countdown", uiState.language)} ${uiState.reconnectCountdownSec}s..."
        EdgeErrorBanner.NONE -> return
    }
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = tokens.error.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, tokens.error.copy(alpha = 0.65f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(Icons.Rounded.WarningAmber, contentDescription = "Alert", tint = tokens.error)
            JarvisText(text = msg, style = JarvisTypographyTokens.Caption.copy(fontSize = 13.sp), color = tokens.textPrimary, modifier = Modifier.weight(1f))
            JarvisTertiaryButton(
                text = if (uiState.edgeBanner == EdgeErrorBanner.ACCESSIBILITY_OFF) "Fix" else "Clear",
                color = tokens.error,
                onClick = { viewModel.setEdgeBanner(EdgeErrorBanner.NONE) }
            )
        }
    }
}

@Composable
fun MissionHudOverlay(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    val mission = uiState.activeMission
    BackHandler { viewModel.closeMissionHud() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.65f))
            .clickable { viewModel.closeMissionHud() }
            .padding(20.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        JarvisGlassCard(
            elevationLevel = 3,
            cornerRadius = 28.dp,
            onClick = {},
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
        ) {
            // Switch between sample missions
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                MockData.sampleTasks.forEach { t ->
                    val chipLabel = t.gameBadge ?: t.title.split(" ").take(2).joinToString(" ")
                    JarvisChip(label = chipLabel, selected = t.id == mission.id, onClick = { viewModel.openMissionHud(t) })
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    mission.gameBadge?.let { badge ->
                        Surface(
                            shape = RoundedCornerShape(999.dp),
                            color = tokens.accent2.copy(alpha = 0.18f),
                            border = BorderStroke(1.dp, tokens.accent2.copy(alpha = 0.55f))
                        ) {
                            JarvisText(
                                text = badge,
                                style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                                color = tokens.accent2,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                    JarvisText(text = mission.title, style = JarvisTypographyTokens.Title.copy(fontSize = 18.sp))
                    JarvisText(text = mission.liveLine, style = JarvisTypographyTokens.Caption, color = tokens.accent2)
                }
                JarvisProgressRing(progress = mission.progress, size = 56.dp, strokeWidth = 5.dp, centerLabel = "${(mission.progress * 100).toInt()}%")
            }

            if (mission.health != null && mission.hunger != null && mission.threat != null) {
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    StatusBadgePill("HP ${mission.health}/20", tokens.error)
                    StatusBadgePill("Energy ${mission.hunger}/20", tokens.warning)
                    StatusBadgePill("Threat: ${mission.threat}", tokens.success)
                    StatusBadgePill("${mission.elapsedSeconds}s", tokens.info)
                }
            }

            if (mission.kind == TaskKind.GAME || mission.id == "task_unlock") {
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val launchAppId = when (mission.id) {
                        "task_bgmi" -> "app_bgmi" to "Launch BGMI"
                        "task_ff" -> "app_freefire" to "Launch Free Fire"
                        "task_mc" -> "app_minecraft" to "Launch Minecraft"
                        else -> null
                    }
                    launchAppId?.let { (appId, cta) ->
                        JarvisChip(
                            label = cta,
                            selected = true,
                            icon = Icons.Rounded.Launch,
                            onClick = { viewModel.launchSystemApp(appId) }
                        )
                    }
                    if (mission.id == "task_unlock") {
                        JarvisChip(
                            label = "Execute Gesture",
                            selected = true,
                            icon = Icons.Rounded.LockOpen,
                            onClick = { viewModel.executeUnlockGesture() }
                        )
                    }
                    if (mission.kind == TaskKind.GAME) {
                        JarvisChip(
                            label = "Voice Callout",
                            selected = false,
                            icon = Icons.Rounded.RecordVoiceOver,
                            onClick = { viewModel.showToast("Squad voice alert sent: \"Zone rotating — move in 10s!\"") }
                        )
                        JarvisChip(
                            label = "DND Focus",
                            selected = uiState.quickToggles.dndOn,
                            icon = Icons.Rounded.DoNotDisturbOn,
                            onClick = { viewModel.toggleDnd() }
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            mission.steps.forEach { step ->
                val icon = when (step.status) {
                    TaskStepStatus.DONE -> Icons.Rounded.CheckCircle
                    TaskStepStatus.ACTIVE -> Icons.Rounded.Autorenew
                    TaskStepStatus.FAILED -> Icons.Rounded.Error
                    TaskStepStatus.PENDING -> Icons.Rounded.RadioButtonUnchecked
                }
                val tint = when (step.status) {
                    TaskStepStatus.DONE -> tokens.success
                    TaskStepStatus.ACTIVE -> tokens.accent
                    TaskStepStatus.FAILED -> tokens.error
                    TaskStepStatus.PENDING -> tokens.textMuted
                }
                Row(
                    modifier = Modifier.padding(vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
                    JarvisText(text = step.label, style = JarvisTypographyTokens.Body.copy(fontSize = 14.sp))
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (mission.status == TaskRunStatus.RUNNING) {
                    JarvisPrimaryButton(
                        text = "STOP MISSION",
                        icon = Icons.Rounded.Stop,
                        demoState = ComponentDemoState.ERROR,
                        onClick = { viewModel.stopMission() },
                        modifier = Modifier.weight(1f)
                    )
                    JarvisSecondaryButton(
                        text = "Sim Fail",
                        onClick = { viewModel.failMissionDemo() }
                    )
                } else {
                    JarvisPrimaryButton(
                        text = if (mission.status == TaskRunStatus.SUCCESS) "Mission Complete ✓" else "Restart Mission",
                        demoState = if (mission.status == TaskRunStatus.SUCCESS) ComponentDemoState.SUCCESS else ComponentDemoState.DEFAULT,
                        onClick = { viewModel.openMissionHud(mission.copy(status = TaskRunStatus.RUNNING, progress = 0.25f)) },
                        modifier = Modifier.weight(1f)
                    )
                    JarvisSecondaryButton(text = "Close", onClick = { viewModel.closeMissionHud() })
                }
            }
        }
    }
}

@Composable
private fun StatusBadgePill(label: String, color: Color) {
    Surface(shape = RoundedCornerShape(999.dp), color = color.copy(alpha = 0.16f)) {
        JarvisText(text = label, style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold), color = color, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
    }
}

@Composable
fun ConfirmationSheetOverlay(
    req: ConfirmationRequest,
    countdownSec: Int,
    onResolve: (approved: Boolean, skipFiveMin: Boolean) -> Unit
) {
    val tokens = LocalJarvisTokens.current
    var skipLowRisk by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.65f))
            .padding(20.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        JarvisGlassCard(
            elevationLevel = 3,
            cornerRadius = 28.dp,
            modifier = Modifier.fillMaxWidth().navigationBarsPadding()
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier.size(44.dp).clip(CircleShape).background(tokens.accent.copy(alpha = 0.18f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Send, contentDescription = null, tint = tokens.accent)
                    }
                    Column {
                        JarvisText(text = req.actionTitle, style = JarvisTypographyTokens.Subtitle)
                        JarvisText(text = req.targetDescription, style = JarvisTypographyTokens.Caption, color = tokens.textSecondary)
                    }
                }
                JarvisProgressRing(
                    progress = countdownSec / 30f,
                    size = 46.dp,
                    strokeWidth = 4.dp,
                    centerLabel = "${countdownSec}s"
                )
            }

            if (req.isLowRisk) {
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().clickable { skipLowRisk = !skipLowRisk },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = skipLowRisk, onCheckedChange = { skipLowRisk = it })
                    JarvisText(text = "Don't ask again for 5 minutes (low-risk only)", style = JarvisTypographyTokens.Caption, color = tokens.textSecondary)
                }
            }

            Spacer(Modifier.height(14.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                // "No" has default focus emphasis per Section 7.8
                JarvisPrimaryButton(
                    text = "No, Cancel",
                    onClick = { onResolve(false, false) },
                    modifier = Modifier.weight(1f)
                )
                JarvisSecondaryButton(
                    text = "Yes, Proceed",
                    onClick = { onResolve(true, skipLowRisk) },
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun CameraVisionScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    BackHandler { viewModel.setCameraVisionOpen(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070A10))
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
    ) {
        // Simulated Camera Viewfinder Frame
        Box(
            modifier = Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(32.dp))
                .background(
                    Brush.verticalGradient(
                        if (uiState.cameraFacingBack) listOf(Color(0xFF131D2B), Color(0xFF0A0F18))
                        else listOf(Color(0xFF21172B), Color(0xFF0D0A14))
                    )
                )
                .border(1.5.dp, tokens.accent.copy(alpha = 0.5f), RoundedCornerShape(32.dp))
        ) {
            // Subtle viewfinder reticle grid
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                drawLine(Color.White.copy(0.12f), Offset(w / 3f, 0f), Offset(w / 3f, h), strokeWidth = 1f)
                drawLine(Color.White.copy(0.12f), Offset(2 * w / 3f, 0f), Offset(2 * w / 3f, h), strokeWidth = 1f)
                drawLine(Color.White.copy(0.12f), Offset(0f, h / 3f), Offset(w, h / 3f), strokeWidth = 1f)
                drawLine(Color.White.copy(0.12f), Offset(0f, 2 * h / 3f), Offset(w, 2 * h / 3f), strokeWidth = 1f)
            }

            // Top Camera Bar
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(shape = RoundedCornerShape(999.dp), color = Color.Black.copy(0.55f)) {
                    JarvisText(
                        text = if (uiState.cameraFacingBack) "Rear Lens • Vision" else "Front Lens • Vision",
                        style = JarvisTypographyTokens.Caption,
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    JarvisIconButton(icon = Icons.Rounded.Cameraswitch, contentDescription = "Flip camera", onClick = { viewModel.flipCamera() })
                    JarvisIconButton(icon = Icons.Rounded.Close, contentDescription = "Close camera", onClick = { viewModel.setCameraVisionOpen(false) })
                }
            }

            // Empty state when no session is running ("Press TALK first")
            if (uiState.assistantState == AssistantState.IDLE) {
                JarvisGlassCard(
                    elevationLevel = 2,
                    cornerRadius = 22.dp,
                    modifier = Modifier.align(Alignment.Center).padding(24.dp)
                ) {
                    Icon(Icons.Rounded.MicNone, contentDescription = null, tint = tokens.accent, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.height(8.dp))
                    JarvisText(text = "Press TALK first", style = JarvisTypographyTokens.Title.copy(fontSize = 18.sp))
                    Spacer(Modifier.height(4.dp))
                    JarvisText(text = MockData.copy("camera_empty", uiState.language), style = JarvisTypographyTokens.Body, color = tokens.textSecondary)
                    Spacer(Modifier.height(12.dp))
                    JarvisPrimaryButton(
                        text = "Activate Voice Session",
                        icon = Icons.Rounded.Mic,
                        onClick = { viewModel.startVoiceSession(openFullScreen = false) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // Bottom Caption + Floating "Describe what you see" button
            Column(
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                JarvisGlassCard(elevationLevel = 2, cornerRadius = 20.dp) {
                    JarvisText(text = "Jarvis Vision", style = JarvisTypographyTokens.Caption, color = tokens.accent)
                    Spacer(Modifier.height(4.dp))
                    JarvisText(text = uiState.cameraCaption, style = JarvisTypographyTokens.Body)
                }
                JarvisPrimaryButton(
                    text = "Describe what you see",
                    icon = Icons.Rounded.Visibility,
                    onClick = { viewModel.describeCameraScene() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoleSelectionBottomSheet(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    ModalBottomSheet(
        onDismissRequest = { viewModel.setRoleSheetVisible(false) },
        containerColor = tokens.surfaceElevatedTop,
        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    JarvisText(text = "Choose Role", style = JarvisTypographyTokens.Title)
                    JarvisText(text = "8 original personalities with distinct voices", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    JarvisText(text = "Auto-switch", style = JarvisTypographyTokens.Caption, color = tokens.textSecondary)
                    Switch(checked = uiState.autoSwitchRole, onCheckedChange = { viewModel.setAutoSwitchRole(it) })
                }
            }

            MockData.roles.forEach { role ->
                val selected = role.id == uiState.activeRole.id
                Surface(
                    onClick = { viewModel.selectRole(role.id) },
                    shape = RoundedCornerShape(20.dp),
                    color = if (selected) role.accent.copy(alpha = 0.16f) else tokens.surfaceCardBottom,
                    border = BorderStroke(if (selected) 1.5.dp else 1.dp, if (selected) role.accent else tokens.borderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        val sheetPortraitRes = (if (uiState.use3dCharacter) role.characterAssets.portrait3dResId else null)
                            ?: role.characterAssets.portraitResId
                        Image(
                            painter = painterResource(id = sheetPortraitRes),
                            contentDescription = role.name,
                            contentScale = ContentScale.Crop,
                            alignment = Alignment.TopCenter,
                            modifier = Modifier
                                .size(56.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .border(2.dp, role.accent, RoundedCornerShape(16.dp))
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                JarvisText(text = role.name, style = JarvisTypographyTokens.Subtitle)
                                JarvisText(text = "• ${role.voiceName}", style = JarvisTypographyTokens.Caption, color = role.accent)
                            }
                            JarvisText(text = role.personalityLine, style = JarvisTypographyTokens.Caption, color = tokens.textSecondary, maxLines = 2)
                        }
                        JarvisIconButton(
                            icon = Icons.Rounded.VolumeUp,
                            contentDescription = "Preview ${role.name}",
                            onClick = { viewModel.showToast("Previewing ${role.name} (${role.voiceName})") }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ThemeSelectionBottomSheet(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    ModalBottomSheet(
        onDismissRequest = { viewModel.setThemeSheetVisible(false) },
        containerColor = tokens.surfaceElevatedTop,
        shape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 28.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            JarvisText(text = "${MockData.themes.size} Cohesive Themes", style = JarvisTypographyTokens.Title)
            JarvisText(text = "Contrast-checked palettes with animated backgrounds", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)

            val list = MockData.themes
            for (i in list.indices step 2) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    for (j in 0..1) {
                        val t = list.getOrNull(i + j)
                        if (t != null) {
                            val selected = t.id == uiState.activeTheme.id
                            val previewAccent = if (t.followsRole) uiState.activeRole.accent else t.accent
                            val previewAccent2 = if (t.followsRole) uiState.activeRole.accent2 else t.accent2
                            val textCol = if (t.isLight) Color(0xFF151822) else Color(0xFFF6F8FC)

                            Surface(
                                onClick = { viewModel.selectTheme(t.id) },
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) previewAccent else tokens.borderSubtle),
                                modifier = Modifier.weight(1f).height(112.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Brush.verticalGradient(listOf(t.bgTop, t.bgBottom)))
                                        .padding(12.dp)
                                ) {
                                    // Mini animated-style orb + glass preview strip
                                    Row(
                                        modifier = Modifier.align(Alignment.TopStart),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(modifier = Modifier.size(16.dp).clip(CircleShape).background(previewAccent))
                                        Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(previewAccent2))
                                    }
                                    if (selected) {
                                        Icon(
                                            imageVector = Icons.Rounded.CheckCircle,
                                            contentDescription = "Selected",
                                            tint = previewAccent,
                                            modifier = Modifier.align(Alignment.TopEnd).size(20.dp)
                                        )
                                    }
                                    Column(modifier = Modifier.align(Alignment.BottomStart)) {
                                        JarvisText(text = t.name, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp), color = textCol, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        JarvisText(text = t.backgroundStyle.label, style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp), color = textCol.copy(alpha = 0.72f), maxLines = 1)
                                    }
                                }
                            }
                        } else {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DebugPanelDialog(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    Dialog(
        onDismissRequest = { viewModel.setDebugPanelVisible(false) },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        JarvisGlassCard(
            elevationLevel = 3,
            cornerRadius = 28.dp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .heightIn(max = 760.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    JarvisText(text = "Hidden Debug Panel", style = JarvisTypographyTokens.Title.copy(fontSize = 19.sp))
                    JarvisText(text = "Long-press status pill anytime to inspect states", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                }
                JarvisIconButton(icon = Icons.Rounded.Close, contentDescription = "Close Debug", onClick = { viewModel.setDebugPanelVisible(false) })
            }
            Spacer(Modifier.height(10.dp))
            Column(
                modifier = Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // AssistantState
                JarvisText(text = "AssistantState", style = JarvisTypographyTokens.Caption, color = tokens.accent)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AssistantState.entries.forEach { st ->
                        JarvisChip(label = st.name, selected = uiState.assistantState == st, onClick = { viewModel.setAssistantStateDirect(st) })
                    }
                }

                // Role
                JarvisText(text = "Active Role", style = JarvisTypographyTokens.Caption, color = tokens.accent)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MockData.roles.forEach { r ->
                        JarvisChip(label = r.name, selected = uiState.activeRole.id == r.id, onClick = { viewModel.selectRole(r.id) })
                    }
                }

                // Theme
                JarvisText(text = "Theme", style = JarvisTypographyTokens.Caption, color = tokens.accent)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MockData.themes.forEach { t ->
                        JarvisChip(label = t.name, selected = uiState.activeTheme.id == t.id, onClick = { viewModel.selectTheme(t.id) })
                    }
                }

                // Language & Font Scale (100% vs 130%)
                JarvisText(text = "Language & Font Scale", style = JarvisTypographyTokens.Caption, color = tokens.accent)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    LanguageMode.entries.forEach { l ->
                        JarvisChip(label = l.label, selected = uiState.language == l, onClick = { viewModel.setLanguage(l) })
                    }
                    JarvisChip(label = "100%", selected = uiState.fontScaleMultiplier < 1.15f, onClick = { viewModel.setFontScale(1.0f) })
                    JarvisChip(label = "130%", selected = uiState.fontScaleMultiplier >= 1.25f, onClick = { viewModel.setFontScale(1.3f) })
                }

                // Prototype Viewport Frame (360 / 412 / 480 dp)
                JarvisText(text = "Prototype Viewport Frame", style = JarvisTypographyTokens.Caption, color = tokens.accent)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    JarvisChip(label = if (uiState.deviceFrameEnabled) "Frame ON" else "Full Native", selected = uiState.deviceFrameEnabled, onClick = { viewModel.setDeviceFrameEnabled(!uiState.deviceFrameEnabled) })
                    listOf(360, 412, 480).forEach { w ->
                        JarvisChip(label = "${w}dp", selected = uiState.deviceFrameEnabled && uiState.viewportWidthDp == w, onClick = {
                            viewModel.setDeviceFrameEnabled(true)
                            viewModel.setViewportWidth(w)
                        })
                    }
                }

                // Edge / Error State (7.15)
                JarvisText(text = "Simulate Error / Edge State", style = JarvisTypographyTokens.Caption, color = tokens.accent)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    EdgeErrorBanner.entries.forEach { err ->
                        JarvisChip(label = err.label, selected = uiState.edgeBanner == err, onClick = { viewModel.setEdgeBanner(err) })
                    }
                }

                // Audio Route
                JarvisText(text = "Audio Route", style = JarvisTypographyTokens.Caption, color = tokens.accent)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    AudioRoute.entries.forEach { route ->
                        JarvisChip(label = route.label, selected = uiState.diagnostics.route == route, onClick = { viewModel.setAudioRoute(route) })
                    }
                }

                // Quick Screen Jumpers
                JarvisText(text = "Jump to Special Views", style = JarvisTypographyTokens.Caption, color = tokens.accent)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    JarvisChip(label = "Welcome", selected = false, onClick = { viewModel.setDebugPanelVisible(false); viewModel.openWelcomeScreen() })
                    JarvisChip(label = "Loading HUD", selected = false, onClick = { viewModel.setDebugPanelVisible(false); viewModel.triggerLoadingPreview() })
                    JarvisChip(label = "System Brain", selected = false, onClick = { viewModel.openSubScreen(SubScreen.COMMAND_CENTER) })
                    JarvisChip(label = "Design System", selected = false, onClick = { viewModel.openSubScreen(SubScreen.DESIGN_SYSTEM) })
                    JarvisChip(label = "Overlay Artboard", selected = false, onClick = { viewModel.openSubScreen(SubScreen.OVERLAY_ARTBOARD) })
                    JarvisChip(label = "Setup Wizard", selected = false, onClick = { viewModel.openSubScreen(SubScreen.SETUP_WIZARD) })
                    JarvisChip(label = "Mission HUD", selected = false, onClick = { viewModel.setDebugPanelVisible(false); viewModel.openMissionHud() })
                    JarvisChip(label = "Confirm Sheet", selected = false, onClick = { viewModel.setDebugPanelVisible(false); viewModel.requestConfirmation("Post Story to Instagram", "Study Desk 9:16 Card", true, "post") })
                }
            }
        }
    }
}
