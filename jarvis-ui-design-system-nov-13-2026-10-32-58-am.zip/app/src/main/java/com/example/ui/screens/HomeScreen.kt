package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.MockData
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalJarvisTokens
import com.example.viewmodel.JarvisUiState
import com.example.viewmodel.JarvisViewModel

@Composable
fun HomeScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    var askInput by remember { mutableStateOf("") }
    val attachmentController = rememberAttachmentController(
        onAddAttachment = { viewModel.addAttachment(it) },
        onOpenCameraVision = { viewModel.setCameraVisionOpen(true) }
    )

    val statusLabel = when (uiState.assistantState) {
        AssistantState.IDLE -> MockData.copy("ready", uiState.language)
        AssistantState.CONNECTING -> MockData.copy("connecting", uiState.language)
        AssistantState.LISTENING -> MockData.copy("listening", uiState.language)
        AssistantState.THINKING -> MockData.copy("thinking", uiState.language)
        AssistantState.SPEAKING -> MockData.copy("speaking", uiState.language)
        AssistantState.INTERRUPTED -> MockData.copy("interrupted", uiState.language)
        AssistantState.MUTED -> MockData.copy("muted", uiState.language)
        AssistantState.ERROR -> MockData.copy("error", uiState.language)
        AssistantState.OFFLINE -> MockData.copy("offline", uiState.language)
    }

    val activeBridgeCount = uiState.systemBridges.count { it.connected }

    JarvisPullToRefreshBox(
        isRefreshing = uiState.isRefreshing,
        onRefresh = { viewModel.refreshPage("Home Hub") },
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(top = 12.dp, bottom = 112.dp), // Clear bottom nav cleanly
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Top Header: User J.A.R.V.I.S. Logo + Greeting + Status Pill + System Brain / Role / Theme buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_jarvis_user_logo),
                        contentDescription = "Jarvis Core Logo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, tokens.accent2.copy(alpha = 0.85f), CircleShape)
                            .clickable { viewModel.openSubScreen(SubScreen.COMMAND_CENTER) }
                    )
                Column(modifier = Modifier.weight(1f)) {
                    JarvisText(
                        text = MockData.copy("greeting", uiState.language),
                        style = JarvisTypographyTokens.Title.copy(fontSize = 19.sp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        JarvisStatusPill(
                            state = uiState.assistantState,
                            label = statusLabel,
                            onClick = { viewModel.setLiveVoiceOpen(true) },
                            onLongPress = { viewModel.setDebugPanelVisible(true) }
                        )
                        Icon(
                            imageVector = if (uiState.deviceStatus.wifiOn) Icons.Rounded.Wifi else Icons.Rounded.WifiOff,
                            contentDescription = "Connection status",
                            tint = if (uiState.deviceStatus.wifiOn) tokens.success else tokens.error,
                            modifier = Modifier.size(15.dp)
                        )
                        JarvisText(
                            text = "${uiState.battery.percent}%",
                            style = JarvisTypographyTokens.Caption,
                            color = tokens.textSecondary
                        )
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                JarvisIconButton(
                    icon = Icons.Rounded.Hub,
                    contentDescription = "System Brain & Deep OS",
                    onClick = { viewModel.openSubScreen(SubScreen.COMMAND_CENTER) }
                )
                JarvisIconButton(
                    icon = Icons.Rounded.People,
                    contentDescription = "Switch Role",
                    onClick = { viewModel.setRoleSheetVisible(true) }
                )
                JarvisIconButton(
                    icon = Icons.Rounded.Palette,
                    contentDescription = "Switch Theme",
                    onClick = { viewModel.setThemeSheetVisible(true) }
                )
            }
        }

        // Edge Error / Reconnection Banner (7.15)
        if (uiState.edgeBanner != EdgeErrorBanner.NONE) {
            EdgeErrorBannerCard(uiState = uiState, viewModel = viewModel)
        }

        // UNOBSTRUCTED 3D HERO STAGE (Zero overlapping pop-ups over face or chest!)
        Box(modifier = Modifier.fillMaxWidth()) {
            CharacterStage(
                role = uiState.activeRole,
                assistantState = uiState.assistantState,
                height = 376.dp,
                useCosmicVariant = uiState.useCosmicJarvisPortrait,
                use3dCharacter = uiState.use3dCharacter,
                onToggleCosmicVariant = { viewModel.toggleCosmicJarvisPortrait() },
                onToggle3dCharacter = { viewModel.toggle3dCharacter() },
                onTap = { viewModel.setLiveVoiceOpen(true) },
                onDoubleTap = { viewModel.toggle3dCharacter() },
                onLongPress = { viewModel.startVoiceSession(openFullScreen = true) }
            )

            // Top-right Mission HUD launcher only (kept small at top corner, never hides face)
            Surface(
                onClick = { viewModel.openMissionHud() },
                shape = RoundedCornerShape(999.dp),
                color = tokens.surfaceElevatedTop.copy(alpha = 0.90f),
                border = BorderStroke(1.dp, tokens.accent2.copy(alpha = 0.55f)),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(Icons.Rounded.RocketLaunch, contentDescription = "Open Mission HUD", tint = tokens.accent2, modifier = Modifier.size(14.dp))
                    JarvisText(text = "Mission", style = JarvisTypographyTokens.Caption, color = tokens.textPrimary)
                }
            }

            // Sleek Side Role Switcher Arrows at mid-edges (outside face area, replaces gesture conflict with 3D tilt)
            JarvisIconButton(
                icon = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
                contentDescription = "Previous Character",
                containerColor = tokens.surfaceElevatedTop.copy(alpha = 0.65f),
                onClick = { viewModel.swipeRole(-1) },
                modifier = Modifier.align(Alignment.CenterStart).padding(start = 8.dp)
            )
            JarvisIconButton(
                icon = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = "Next Character",
                containerColor = tokens.surfaceElevatedTop.copy(alpha = 0.65f),
                onClick = { viewModel.swipeRole(1) },
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)
            )
        }

        // LIVE VOICE HUD BAR (Placed cleanly BELOW CharacterStage — swipe horizontally to cycle roles!)
        JarvisGlassCard(
            elevationLevel = 2,
            cornerRadius = 22.dp,
            contentPadding = PaddingValues(14.dp),
            onClick = { viewModel.setLiveVoiceOpen(true) },
            modifier = Modifier
                .fillMaxWidth()
                .pointerInput(Unit) {
                    var dragAccum = 0f
                    detectHorizontalDragGestures(
                        onDragStart = { dragAccum = 0f },
                        onHorizontalDrag = { _, dragAmount -> dragAccum += dragAmount },
                        onDragEnd = {
                            if (dragAccum < -65f) viewModel.swipeRole(1)
                            else if (dragAccum > 65f) viewModel.swipeRole(-1)
                            dragAccum = 0f
                        },
                        onDragCancel = { dragAccum = 0f }
                    )
                }
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                JarvisWaveform(
                    active = uiState.assistantState == AssistantState.LISTENING || uiState.assistantState == AssistantState.SPEAKING,
                    isThinking = uiState.assistantState == AssistantState.THINKING,
                    color = uiState.activeRole.accent
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = tokens.accent.copy(alpha = 0.16f)
                    ) {
                        val micLabel = when (uiState.micState) {
                            MicState.LIVE -> "Mic Live"
                            MicState.PAUSED -> "Mic Paused"
                            MicState.MUTED -> "Mic Muted"
                            MicState.BLOCKED -> "Mic Blocked"
                        }
                        JarvisText(
                            text = micLabel,
                            style = JarvisTypographyTokens.Caption,
                            color = tokens.accent2,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Surface(
                        onClick = { viewModel.setLiveVoiceOpen(true) },
                        shape = RoundedCornerShape(999.dp),
                        color = tokens.accent2.copy(alpha = 0.16f)
                    ) {
                        JarvisText(
                            text = "Full HUD ↗",
                            style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                            color = tokens.accent2,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp)
                        )
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            JarvisText(
                text = if (uiState.micState == MicState.PAUSED) {
                    MockData.copy("mic_paused_banner", uiState.language)
                } else {
                    uiState.lastCaptionJarvis
                },
                style = JarvisTypographyTokens.Body.copy(fontSize = 14.sp),
                color = tokens.textPrimary,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(4.dp))
            JarvisText(
                text = "← Swipe card to switch role • Pull down page to refresh",
                style = JarvisTypographyTokens.Caption.copy(fontSize = 10.5.sp),
                color = tokens.textMuted
            )
        }

        // Quick Mode Chips with Right Scroll Fade Hint
        Box(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(end = 28.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val modes = listOf(
                    Triple(QuickMode.MUSIC, "Music", Icons.Rounded.MusicNote),
                    Triple(QuickMode.STUDY, "Study", Icons.Rounded.School),
                    Triple(QuickMode.JOURNAL, "Journal", Icons.Rounded.Book),
                    Triple(QuickMode.DOCUMENTS, "Documents", Icons.Rounded.Description),
                    Triple(QuickMode.OFF, "Off", Icons.Rounded.PowerSettingsNew)
                )
                modes.forEach { (mode, label, icon) ->
                    JarvisChip(
                        label = label,
                        icon = icon,
                        selected = uiState.quickMode == mode,
                        onClick = { viewModel.selectQuickMode(mode) }
                    )
                }
            }
            ScrollFadeEdge(modifier = Modifier.align(Alignment.CenterEnd).height(44.dp))
        }

        // Deep Integration ("System Brain") & Cosmic Engine Live Bar
        JarvisGlassCard(
            elevationLevel = 2,
            cornerRadius = 22.dp,
            accentTint = tokens.accent2,
            contentPadding = PaddingValues(14.dp),
            onClick = { viewModel.openSubScreen(SubScreen.COMMAND_CENTER) }
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(tokens.accent2.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Rounded.Hub, contentDescription = "Deep OS Integration", tint = tokens.accent2, modifier = Modifier.size(20.dp))
                    }
                    Column {
                        JarvisText(text = "Deep OS Integration & Cosmic Engine", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                        JarvisText(
                            text = "$activeBridgeCount/6 Bridges Linked • ${uiState.cosmicIntensity.label} Starfield",
                            style = JarvisTypographyTokens.Caption,
                            color = tokens.success
                        )
                    }
                }
                Surface(shape = RoundedCornerShape(999.dp), color = tokens.accent.copy(alpha = 0.18f)) {
                    JarvisText(
                        text = "Open Hub",
                        style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                        color = tokens.accent2,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                JarvisChip(
                    label = "Open BGMI",
                    selected = false,
                    icon = Icons.Rounded.SportsEsports,
                    onClick = { viewModel.launchSystemApp("app_bgmi") }
                )
                JarvisChip(
                    label = "Open Minecraft",
                    selected = false,
                    icon = Icons.Rounded.ViewInAr,
                    onClick = { viewModel.launchSystemApp("app_minecraft") }
                )
                JarvisChip(
                    label = "Lock Screen",
                    selected = false,
                    icon = Icons.Rounded.Lock,
                    onClick = { viewModel.executeScreenLock() }
                )
                JarvisChip(
                    label = "Notifications",
                    selected = false,
                    icon = Icons.Rounded.Notifications,
                    onClick = { viewModel.openSystemNotificationShade() }
                )
                CosmicIntensity.entries.forEach { lvl ->
                    JarvisChip(
                        label = "Cosmic: ${lvl.label}",
                        selected = uiState.cosmicIntensity == lvl,
                        onClick = { viewModel.setCosmicIntensity(lvl) }
                    )
                }
                JarvisChip(
                    label = "${MockData.themes.size} Themes",
                    selected = false,
                    icon = Icons.Rounded.Palette,
                    onClick = { viewModel.setThemeSheetVisible(true) }
                )
            }
        }

        // Trending Searches & Knowledge Pulse
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                JarvisText(text = "Trending Searches & Pulse", style = JarvisTypographyTokens.Subtitle)
                JarvisTertiaryButton(text = "See all", onClick = { viewModel.openSubScreen(SubScreen.COMMAND_CENTER) })
            }
            Box(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(end = 28.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MockData.trendingSearches.forEach { trend ->
                        Surface(
                            onClick = { viewModel.launchTrendingSearch(trend) },
                            shape = RoundedCornerShape(18.dp),
                            color = tokens.surfaceCardTop,
                            border = BorderStroke(1.dp, tokens.accent.copy(alpha = 0.35f)),
                            modifier = Modifier.width(196.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    JarvisText(text = trend.category, style = JarvisTypographyTokens.Caption, color = tokens.accent2)
                                    Surface(shape = RoundedCornerShape(999.dp), color = tokens.accent.copy(alpha = 0.2f)) {
                                        JarvisText(
                                            text = trend.hotLabel,
                                            style = JarvisTypographyTokens.Caption.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                            color = tokens.accent2,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                JarvisText(text = trend.title, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                JarvisText(text = trend.query, style = JarvisTypographyTokens.Caption, color = tokens.textMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
                ScrollFadeEdge(modifier = Modifier.align(Alignment.CenterEnd).height(88.dp))
            }
        }

        // Iron Man Jarvis: Game Copilot & Hands-Free Autonomy Deck (BGMI, Free Fire, Minecraft, Auto-Unlock)
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                JarvisText(text = "Jarvis Autopilot & Game Copilot", style = JarvisTypographyTokens.Subtitle)
                JarvisText(text = "Tap to deploy", style = JarvisTypographyTokens.Caption, color = tokens.accent2)
            }
            Box(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(end = 28.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    JarvisChip(label = "BGMI 60FPS", selected = uiState.showMissionHud && uiState.activeMission.id == "task_bgmi", icon = Icons.Rounded.SportsEsports, onClick = { viewModel.launchTaskById("task_bgmi") })
                    JarvisChip(label = "Free Fire", selected = uiState.showMissionHud && uiState.activeMission.id == "task_ff", icon = Icons.Rounded.FlashOn, onClick = { viewModel.launchTaskById("task_ff") })
                    JarvisChip(label = "Minecraft Bot", selected = uiState.showMissionHud && uiState.activeMission.id == "task_mc", icon = Icons.Rounded.ViewInAr, onClick = { viewModel.launchTaskById("task_mc") })
                    JarvisChip(label = "Auto-Unlock", selected = uiState.showMissionHud && uiState.activeMission.id == "task_unlock", icon = Icons.Rounded.LockOpen, onClick = { viewModel.launchTaskById("task_unlock") })
                    JarvisChip(label = "WhatsApp Bot", selected = uiState.showMissionHud && uiState.activeMission.id == "task_wa", icon = Icons.Rounded.Chat, onClick = { viewModel.launchTaskById("task_wa") })
                }
                ScrollFadeEdge(modifier = Modifier.align(Alignment.CenterEnd).height(44.dp))
            }
        }

        // Cosmic Insights & Focus Telemetry Card
        CosmicInsightsCard(
            insights = uiState.insights,
            onOpenStudy = { viewModel.openSubScreen(SubScreen.STUDY_MODE) }
        )

        // Intelligent Widgets Grid (All 8 real components from 7.14)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                JarvisText(text = "Live Context", style = JarvisTypographyTokens.Subtitle)
                JarvisTertiaryButton(
                    text = "Cycle states",
                    onClick = {
                        val next = when (uiState.weather.state) {
                            WidgetModeState.READY -> WidgetModeState.LOADING
                            WidgetModeState.LOADING -> WidgetModeState.EMPTY
                            WidgetModeState.EMPTY -> WidgetModeState.ERROR
                            WidgetModeState.ERROR -> WidgetModeState.OFFLINE
                            WidgetModeState.OFFLINE -> WidgetModeState.READY
                        }
                        viewModel.setAllWidgetsMode(next)
                        viewModel.showToast("Widgets state: ${next.name}")
                    }
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                WeatherWidgetCard(
                    data = uiState.weather,
                    activeRole = uiState.activeRole,
                    onRefresh = { viewModel.setAllWidgetsMode(WidgetModeState.READY) },
                    modifier = Modifier.weight(1f)
                )
                TodayWidgetCard(
                    data = uiState.today,
                    onTap = { viewModel.setAllWidgetsMode(WidgetModeState.READY) },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                MoodWidgetCard(
                    data = uiState.mood,
                    onSwitchSuggestedRole = { viewModel.selectRole(it, isAutoSwitch = true) },
                    modifier = Modifier.weight(1f)
                )
                BatteryWidgetCard(
                    data = uiState.battery,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                RemindersWidgetCard(
                    data = uiState.reminders,
                    onToggleReminder = { viewModel.toggleReminder(it) },
                    modifier = Modifier.weight(1f)
                )
                MusicWidgetCard(
                    data = uiState.music,
                    onTogglePlay = { viewModel.toggleMusicPlay() },
                    onOpenMusicMode = { viewModel.openSubScreen(SubScreen.MUSIC_MODE) },
                    modifier = Modifier.weight(1f)
                )
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                DeviceStatusWidgetCard(
                    data = uiState.deviceStatus,
                    onToggleWifi = { viewModel.toggleWifi() },
                    onToggleMobile = { viewModel.toggleMobileData() },
                    onToggleBluetooth = { viewModel.toggleBluetooth() },
                    modifier = Modifier.weight(1f)
                )
                QuickTogglesWidgetCard(
                    data = uiState.quickToggles,
                    onToggleFlash = { viewModel.toggleFlashlight() },
                    onToggleVolume = { viewModel.toggleVolume() },
                    onToggleDnd = { viewModel.toggleDnd() },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Quick Actions Grid (8 items)
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            JarvisText(text = "Quick Phone Actions", style = JarvisTypographyTokens.Subtitle)
            val actions = listOf(
                Pair("Unlock", Icons.Rounded.LockOpen),
                Pair("Call", Icons.Rounded.Call),
                Pair("WhatsApp", Icons.Rounded.Chat),
                Pair("YouTube", Icons.Rounded.PlayCircleOutline),
                Pair("Camera", Icons.Rounded.PhotoCamera),
                Pair("Flashlight", Icons.Rounded.FlashlightOn),
                Pair("Timer", Icons.Rounded.Timer),
                Pair("Screenshot", Icons.Rounded.Screenshot)
            )
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for (rowIdx in 0..1) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        for (colIdx in 0..3) {
                            val item = actions[rowIdx * 4 + colIdx]
                            QuickActionTile(
                                label = item.first,
                                icon = item.second,
                                onClick = { viewModel.triggerQuickAction(item.first) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Multimodal Ask Bar with Real Photo Picker, Camera Snap, and File Attachment!
        JarvisGlassCard(
            elevationLevel = 2,
            cornerRadius = 22.dp,
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)
        ) {
            PendingAttachmentsStrip(
                attachments = uiState.pendingAttachments,
                onRemove = { viewModel.removeAttachment(it) },
                modifier = Modifier.padding(bottom = if (uiState.pendingAttachments.isNotEmpty()) 8.dp else 0.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                JarvisIconButton(
                    icon = Icons.Rounded.AddCircleOutline,
                    contentDescription = "Attach file, photo or camera",
                    onClick = { attachmentController.openSheet() }
                )
                OutlinedTextField(
                    value = askInput,
                    onValueChange = { askInput = it },
                    placeholder = {
                        JarvisText(
                            text = MockData.copy("ask_placeholder", uiState.language),
                            style = JarvisTypographyTokens.Body,
                            color = tokens.textMuted,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = tokens.accent.copy(alpha = 0.5f),
                        unfocusedBorderColor = tokens.borderSubtle,
                        focusedTextColor = tokens.textPrimary,
                        unfocusedTextColor = tokens.textPrimary
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.weight(1f)
                )
                JarvisIconButton(
                    icon = Icons.Rounded.Mic,
                    contentDescription = "Voice ask",
                    onClick = { viewModel.startVoiceSession(openFullScreen = true) }
                )
                JarvisIconButton(
                    icon = Icons.Rounded.ArrowUpward,
                    contentDescription = "Send prompt",
                    containerColor = tokens.accent,
                    tint = tokens.onAccent,
                    onClick = {
                        if (askInput.isNotBlank() || uiState.pendingAttachments.isNotEmpty()) {
                            viewModel.sendChatMessage(askInput)
                            askInput = ""
                            viewModel.selectTab(MainTab.CHAT)
                        }
                    }
                )
            }
        }
    }
    }
}

@Composable
private fun QuickActionTile(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    Surface(
        onClick = onClick,
        modifier = modifier.heightIn(min = 68.dp).testTag("action_${label.lowercase()}"),
        shape = RoundedCornerShape(18.dp),
        color = tokens.surfaceCardTop,
        border = BorderStroke(1.dp, tokens.borderSubtle)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(tokens.accent.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = label, tint = tokens.accent, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.height(6.dp))
            JarvisText(
                text = label,
                style = JarvisTypographyTokens.Caption.copy(fontSize = 12.sp),
                color = tokens.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun CosmicInsightsCard(
    insights: InsightsData,
    onOpenStudy: () -> Unit
) {
    val tokens = LocalJarvisTokens.current
    JarvisGlassCard(
        elevationLevel = 2,
        cornerRadius = 24.dp,
        accentTint = tokens.accent,
        onClick = onOpenStudy
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                JarvisText(
                    text = "JARVIS SYNC INSIGHTS",
                    style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                    color = tokens.accent2
                )
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    JarvisText(
                        text = "${insights.syncScore}",
                        style = JarvisTypographyTokens.Display.copy(fontSize = 30.sp),
                        color = tokens.textPrimary
                    )
                    Surface(shape = RoundedCornerShape(999.dp), color = tokens.success.copy(alpha = 0.2f)) {
                        JarvisText(
                            text = insights.deltaLabel,
                            style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                            color = tokens.success,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
            }
            JarvisProgressRing(
                progress = insights.efficiencyPct / 100f,
                size = 54.dp,
                strokeWidth = 5.dp,
                color = tokens.accent2,
                centerLabel = "${insights.efficiencyPct}%"
            )
        }
        Spacer(Modifier.height(10.dp))
        androidx.compose.foundation.Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
        ) {
            val pts = insights.sparkline
            if (pts.size >= 2) {
                val stepX = size.width / (pts.size - 1)
                val path = androidx.compose.ui.graphics.Path()
                pts.forEachIndexed { idx, v ->
                    val x = idx * stepX
                    val y = size.height - (v.coerceIn(0f, 1f) * size.height * 0.85f) - 4f
                    if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                drawPath(
                    path = path,
                    brush = androidx.compose.ui.graphics.Brush.horizontalGradient(listOf(tokens.accent, tokens.accent2)),
                    style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3.dp.toPx(), cap = androidx.compose.ui.graphics.StrokeCap.Round)
                )
                val lastX = (pts.size - 1) * stepX
                val lastY = size.height - (pts.last().coerceIn(0f, 1f) * size.height * 0.85f) - 4f
                drawCircle(color = tokens.accent2, radius = 5.dp.toPx(), center = androidx.compose.ui.geometry.Offset(lastX, lastY))
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            JarvisText(text = "Deep Work: ${insights.deepWorkLabel}", style = JarvisTypographyTokens.Caption, color = tokens.textSecondary)
            JarvisText(text = "${insights.streakDays}d Streak • Focus Ready", style = JarvisTypographyTokens.Caption, color = tokens.accent)
        }
    }
}
