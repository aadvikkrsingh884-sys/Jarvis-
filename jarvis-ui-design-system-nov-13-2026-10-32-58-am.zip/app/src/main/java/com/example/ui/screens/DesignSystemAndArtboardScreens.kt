package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MockData
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.LocalJarvisTokens
import com.example.viewmodel.JarvisUiState
import com.example.viewmodel.JarvisViewModel
import kotlin.math.roundToInt

/**
 * Section 5: Dedicated Design System Screen displaying all 29 components
 * across all 6 interactive states (Default, Pressed, Disabled, Loading, Error, Success).
 */
@Composable
fun DesignSystemScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    BackHandler { viewModel.closeSubScreen() }

    var activeDemoState by remember { mutableStateOf(ComponentDemoState.DEFAULT) }
    var segIdx by remember { mutableIntStateOf(0) }
    var switchVal by remember { mutableStateOf(true) }
    var sliderVal by remember { mutableFloatStateOf(0.65f) }
    var sampleField by remember { mutableStateOf("Jarvis_A50s") }
    var searchField by remember { mutableStateOf("") }
    var showPreviewDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                JarvisIconButton(icon = Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", onClick = { viewModel.closeSubScreen() })
                Column {
                    JarvisText(text = "Design System", style = JarvisTypographyTokens.Title)
                    JarvisText(text = "Tokens, Typography & 6-State Matrix", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                }
            }
            JarvisIconButton(icon = Icons.Rounded.Palette, contentDescription = "Theme Picker", onClick = { viewModel.setThemeSheetVisible(true) })
        }

        // State Selector Bar (Default, Pressed, Disabled, Loading, Error, Success)
        JarvisGlassCard(elevationLevel = 2, cornerRadius = 22.dp) {
            JarvisText(text = "Interactive Component State", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ComponentDemoState.entries.forEach { state ->
                    JarvisChip(label = state.label, selected = activeDemoState == state, onClick = { activeDemoState = state })
                }
            }
        }

        // 1. Buttons & Icon Button
        JarvisGlassCard(elevationLevel = 1, cornerRadius = 24.dp) {
            JarvisText(text = "Buttons & Icon Button (48dp+)", style = JarvisTypographyTokens.Subtitle)
            Spacer(Modifier.height(10.dp))
            JarvisPrimaryButton(
                text = "Primary 56dp Gradient",
                icon = Icons.Rounded.AutoAwesome,
                demoState = activeDemoState,
                onClick = { viewModel.showToast("Primary button tapped") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                JarvisSecondaryButton(
                    text = "Secondary Glass",
                    icon = Icons.Rounded.Tune,
                    demoState = activeDemoState,
                    onClick = {},
                    modifier = Modifier.weight(1f)
                )
                JarvisTertiaryButton(
                    text = "Tertiary",
                    enabled = activeDemoState != ComponentDemoState.DISABLED,
                    onClick = {}
                )
                JarvisIconButton(
                    icon = Icons.Rounded.Mic,
                    contentDescription = "48dp Icon Button",
                    selected = activeDemoState == ComponentDemoState.PRESSED,
                    onClick = {}
                )
            }
        }

        // 2. Segmented Control, Chips, Switch & Slider with Value Bubble
        JarvisGlassCard(elevationLevel = 1, cornerRadius = 24.dp) {
            JarvisText(text = "Controls, Chips, Switch & Slider", style = JarvisTypographyTokens.Subtitle)
            Spacer(Modifier.height(10.dp))
            JarvisSegmentedControl(options = listOf("Voice", "Chat", "Code"), selectedIndex = segIdx, onSelect = { segIdx = it })
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisChip(label = "Selected", selected = true, icon = Icons.Rounded.Check, onClick = {})
                JarvisChip(label = "Music", selected = false, icon = Icons.Rounded.MusicNote, onClick = {})
                JarvisChip(label = "Study", selected = false, icon = Icons.Rounded.School, onClick = {})
            }
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisText(text = "Switch Control", style = JarvisTypographyTokens.Body)
                Switch(checked = switchVal, enabled = activeDemoState != ComponentDemoState.DISABLED, onCheckedChange = { switchVal = it })
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisText(text = "Slider", style = JarvisTypographyTokens.Body)
                Surface(shape = RoundedCornerShape(999.dp), color = tokens.accent) {
                    JarvisText(text = "${(sliderVal * 100).toInt()}%", style = JarvisTypographyTokens.Caption, color = tokens.onAccent, modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp))
                }
            }
            Slider(value = sliderVal, onValueChange = { sliderVal = it }, enabled = activeDemoState != ComponentDemoState.DISABLED)
        }

        // 3. Text Field, Search Field, List Row, Permission Row & Step Indicator
        JarvisGlassCard(elevationLevel = 1, cornerRadius = 24.dp) {
            JarvisText(text = "Inputs, List Row, Permission & Steps", style = JarvisTypographyTokens.Subtitle)
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                value = sampleField,
                onValueChange = { sampleField = it },
                enabled = activeDemoState != ComponentDemoState.DISABLED,
                isError = activeDemoState == ComponentDemoState.ERROR,
                label = { JarvisText("Device Label", style = JarvisTypographyTokens.Caption) },
                supportingText = {
                    JarvisText(
                        text = if (activeDemoState == ComponentDemoState.ERROR) "Invalid name format" else "Helper: Used in greetings",
                        style = JarvisTypographyTokens.Caption,
                        color = if (activeDemoState == ComponentDemoState.ERROR) tokens.error else tokens.textMuted
                    )
                },
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = searchField,
                onValueChange = { searchField = it },
                leadingIcon = { Icon(Icons.Rounded.Search, contentDescription = "Search") },
                placeholder = { JarvisText("Search 30 voices or ${MockData.themes.size} themes...", style = JarvisTypographyTokens.Body, color = tokens.textMuted) },
                singleLine = true,
                shape = RoundedCornerShape(999.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            // List Row + Permission Row
            Row(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(tokens.surfaceCardBottom).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = tokens.accent)
                Column(modifier = Modifier.weight(1f)) {
                    JarvisText(text = "List & Permission Row", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                    JarvisText(text = "Icon + title + subtitle + trailing control", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                }
                JarvisChip(label = if (activeDemoState == ComponentDemoState.ERROR) "Fix" else "ON", selected = activeDemoState != ComponentDemoState.ERROR, onClick = {})
            }
            Spacer(Modifier.height(12.dp))
            // Step indicator
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                repeat(5) { step ->
                    Box(
                        modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(999.dp))
                            .background(if (step <= 2) tokens.accent else tokens.borderSubtle)
                    )
                }
            }
        }

        // 4. Progress Ring, Linear Progress, Skeleton, Waveform, Level Meter, Status Pill, Avatar Frame, Role Badge, Confirmation Card, Toast, Dialog & Bottom Sheet
        JarvisGlassCard(elevationLevel = 1, cornerRadius = 24.dp) {
            JarvisText(text = "Telemetry, Loaders, Badges & Surfaces", style = JarvisTypographyTokens.Subtitle)
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisProgressRing(progress = 0.78f, size = 56.dp, strokeWidth = 5.dp, centerLabel = "78%")
                JarvisWaveform(active = activeDemoState != ComponentDemoState.DISABLED, isThinking = activeDemoState == ComponentDemoState.LOADING)
                JarvisStatusPill(state = uiState.assistantState, label = "Status Pill", onClick = {}, onLongPress = {})
            }
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(progress = { 0.64f }, modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(999.dp)), color = tokens.accent)
            Spacer(Modifier.height(10.dp))
            JarvisLevelMeter(level = 0.72f)
            Spacer(Modifier.height(10.dp))
            JarvisSkeletonBox(modifier = Modifier.fillMaxWidth().height(20.dp))
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                // Avatar frame + Role badge
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Image(
                        painter = painterResource(id = uiState.activeRole.characterAssets.portraitResId),
                        contentDescription = "${uiState.activeRole.name} Avatar",
                        contentScale = ContentScale.Crop,
                        alignment = Alignment.TopCenter,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .border(2.dp, uiState.activeRole.accent, CircleShape)
                    )
                    Surface(shape = RoundedCornerShape(999.dp), color = uiState.activeRole.accent.copy(0.18f)) {
                        JarvisText(text = uiState.activeRole.name, style = JarvisTypographyTokens.Caption, color = uiState.activeRole.accent, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                    }
                }
                JarvisSecondaryButton(text = "Dialog", onClick = { showPreviewDialog = true })
                JarvisSecondaryButton(text = "Sheet", onClick = { viewModel.setThemeSheetVisible(true) })
            }
            Spacer(Modifier.height(12.dp))
            // Confirmation Card & Toast Preview
            Surface(shape = RoundedCornerShape(16.dp), color = tokens.surfaceCardBottom, border = BorderStroke(1.dp, tokens.accent.copy(0.4f)), modifier = Modifier.fillMaxWidth()) {
                Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    JarvisText(text = "Confirmation Card / Toast", style = JarvisTypographyTokens.Caption, color = tokens.textPrimary)
                    JarvisTertiaryButton(text = "Trigger", onClick = { viewModel.requestConfirmation("Sample WhatsApp Send", "Rahul • \"Check notes\"", true, "send") })
                }
            }
        }
    }

    if (showPreviewDialog) {
        AlertDialog(
            onDismissRequest = { showPreviewDialog = false },
            title = { JarvisText(text = "Design System Dialog", style = JarvisTypographyTokens.Subtitle) },
            text = { JarvisText(text = "Styled with high-contrast tokens and bundled Sora / Plus Jakarta Sans.", style = JarvisTypographyTokens.Body, color = tokens.textSecondary) },
            confirmButton = { JarvisPrimaryButton(text = "Close", onClick = { showPreviewDialog = false }) }
        )
    }
}

/**
 * Section 7.10: Overlay Components Artboard
 * Displays the 84dp draggable Floating Orb, Live Caption Pill, Notification Card, and Mission Mini-HUD
 * on top of a simulated Android phone wallpaper.
 */
@Composable
fun OverlayArtboardScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    BackHandler { viewModel.closeSubScreen() }

    var orbX by remember { mutableFloatStateOf(270f) }
    var orbY by remember { mutableFloatStateOf(420f) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF050314), Color(0xFF170B3B), Color(0xFF0A0520))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    JarvisIconButton(icon = Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", onClick = { viewModel.closeSubScreen() })
                    Column {
                        JarvisText(text = "Overlay Artboard", style = JarvisTypographyTokens.Title, color = Color.White)
                        JarvisText(text = "Shown over other apps (Drag the 84dp orb)", style = JarvisTypographyTokens.Caption, color = Color(0xFFD0D7E5))
                    }
                }
            }

            // 1. Live Caption Pill
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = Color(0xFF101522).copy(alpha = 0.92f),
                border = BorderStroke(1.dp, tokens.accent.copy(alpha = 0.65f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    JarvisWaveform(active = true, barCount = 8, color = tokens.accent)
                    JarvisText(
                        text = "Jarvis: \"Reading Rahul's WhatsApp message...\"",
                        style = JarvisTypographyTokens.Caption.copy(fontSize = 13.sp),
                        color = Color.White,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 2. Notification Card with Reply / Dismiss
            uiState.overlayNotifications.firstOrNull()?.let { notif ->
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = Color(0xFF141B2B).copy(alpha = 0.94f),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.22f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(
                                modifier = Modifier.size(30.dp).clip(CircleShape).background(Color(0xFF25D366).copy(alpha = 0.22f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Rounded.Chat, contentDescription = notif.appName, tint = Color(0xFF25D366), modifier = Modifier.size(16.dp))
                            }
                            JarvisText(text = "${notif.appName} • ${notif.sender}", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp), color = Color.White, modifier = Modifier.weight(1f))
                            JarvisText(text = notif.time, style = JarvisTypographyTokens.Caption, color = Color(0xFF9AA4B8))
                        }
                        JarvisText(text = notif.text, style = JarvisTypographyTokens.Body, color = Color(0xFFD0D7E5))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            JarvisPrimaryButton(
                                text = "Reply",
                                icon = Icons.Rounded.Reply,
                                onClick = { viewModel.showToast("Voice reply ready for ${notif.sender}") },
                                modifier = Modifier.weight(1f)
                            )
                            JarvisSecondaryButton(
                                text = "Dismiss",
                                onClick = { viewModel.dismissLiveNotification(notif.id) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }

            // 3. Mission Mini-HUD
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF121826).copy(alpha = 0.92f),
                border = BorderStroke(1.dp, tokens.accent.copy(alpha = 0.55f)),
                modifier = Modifier.fillMaxWidth().clickable { viewModel.openMissionHud() }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    JarvisProgressRing(progress = uiState.activeMission.progress, size = 44.dp, strokeWidth = 4.dp, centerLabel = "${(uiState.activeMission.progress * 100).toInt()}%")
                    Column(modifier = Modifier.weight(1f)) {
                        JarvisText(text = uiState.activeMission.title, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp), color = Color.White)
                        JarvisText(text = uiState.activeMission.liveLine, style = JarvisTypographyTokens.Caption, color = tokens.accent2)
                    }
                    JarvisIconButton(icon = Icons.Rounded.Stop, contentDescription = "Stop mini HUD", containerColor = tokens.error, tint = Color.White, onClick = { viewModel.stopMission() })
                }
            }
        }

        // 4. 84dp Draggable Floating Orb (Tap to mute, Long-press to open)
        Box(
            modifier = Modifier
                .offset { IntOffset(orbX.roundToInt(), orbY.roundToInt()) }
                .size(84.dp)
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        orbX = (orbX + dragAmount.x).coerceIn(16f, 820f)
                        orbY = (orbY + dragAmount.y).coerceIn(120f, 1600f)
                    }
                }
                .shadow(20.dp, CircleShape, ambientColor = tokens.accent, spotColor = tokens.accent2)
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(tokens.accent, Color(0xFF170B3B))))
                .border(2.dp, tokens.accent2, CircleShape)
                .clickable { viewModel.toggleMute() },
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = uiState.activeRole.characterAssets.portraitResId),
                contentDescription = "Floating Orb Character",
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter,
                alpha = if (uiState.isMuted) 0.45f else 0.9f,
                modifier = Modifier.fillMaxSize().clip(CircleShape)
            )
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color(0xCC050314))
                    .padding(vertical = 3.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    Icon(
                        imageVector = if (uiState.isMuted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                        contentDescription = "Floating Orb",
                        tint = if (uiState.isMuted) tokens.error else tokens.accent2,
                        modifier = Modifier.size(12.dp)
                    )
                    JarvisText(
                        text = if (uiState.isMuted) "MUTED" else "84dp",
                        style = JarvisTypographyTokens.Caption.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold),
                        color = Color.White
                    )
                }
            }
        }
    }
}
