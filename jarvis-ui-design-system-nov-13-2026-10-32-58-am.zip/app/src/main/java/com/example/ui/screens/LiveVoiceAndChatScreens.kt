package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MockData
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalJarvisTokens
import com.example.viewmodel.JarvisUiState
import com.example.viewmodel.JarvisViewModel

@Composable
fun LiveVoiceFullScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    BackHandler { viewModel.setLiveVoiceOpen(false) }

    val isHeadphones = uiState.diagnostics.route != AudioRoute.SPEAKER
    val isSpeakingOnSpeaker = uiState.assistantState == AssistantState.SPEAKING && !isHeadphones && uiState.diagnostics.halfDuplexMode

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(tokens.bgTop, tokens.bgBottom)))
            .pointerInput(Unit) {
                var dragY = 0f
                detectVerticalDragGestures(
                    onDragStart = { dragY = 0f },
                    onVerticalDrag = { _, dragAmount -> dragY += dragAmount },
                    onDragEnd = {
                        if (dragY > 90f) viewModel.setLiveVoiceOpen(false)
                        dragY = 0f
                    },
                    onDragCancel = { dragY = 0f }
                )
            }
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Echo Protection & Route Header + Swipe-down indicator
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    modifier = Modifier.fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(42.dp)
                            .height(4.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(tokens.textMuted.copy(alpha = 0.45f))
                    )
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = tokens.surfaceElevatedTop,
                        border = BorderStroke(1.dp, tokens.success.copy(alpha = 0.55f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Rounded.VerifiedUser, contentDescription = null, tint = tokens.success, modifier = Modifier.size(15.dp))
                            JarvisText(
                                text = if (uiState.diagnostics.halfDuplexMode) "Echo protection: on" else "Echo protection: off",
                                style = JarvisTypographyTokens.Caption,
                                color = tokens.textPrimary
                            )
                        }
                    }

                    JarvisIconButton(
                        icon = Icons.Rounded.Close,
                        contentDescription = "Minimize voice screen",
                        onClick = { viewModel.setLiveVoiceOpen(false) }
                    )
                }

                // Route & Feedback-Loop Prevention Banner (Section 8)
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = if (isHeadphones) tokens.info.copy(alpha = 0.16f) else tokens.accent.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, if (isHeadphones) tokens.info.copy(alpha = 0.5f) else tokens.accent.copy(alpha = 0.45f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (isHeadphones) Icons.Rounded.Headphones else Icons.Rounded.GraphicEq,
                                contentDescription = null,
                                tint = if (isHeadphones) tokens.info else tokens.accent,
                                modifier = Modifier.size(18.dp)
                            )
                            JarvisText(
                                text = when {
                                    isSpeakingOnSpeaker -> MockData.copy("mic_paused_banner", uiState.language)
                                    isHeadphones -> MockData.copy("headphones_banner", uiState.language)
                                    uiState.assistantState == AssistantState.INTERRUPTED -> "Interrupted cleanly"
                                    else -> "Mic ${uiState.micState.name.lowercase()} • ${uiState.diagnostics.route.label}"
                                },
                                style = JarvisTypographyTokens.Caption,
                                color = tokens.textPrimary
                            )
                        }
                        if (uiState.assistantState == AssistantState.SPEAKING) {
                            JarvisTertiaryButton(
                                text = "Interrupt",
                                onClick = { viewModel.simulateUserInterrupt() }
                            )
                        }
                    }
                }
            }

            // Giant Character Hero
            CharacterStage(
                role = uiState.activeRole,
                assistantState = uiState.assistantState,
                height = 380.dp,
                useCosmicVariant = uiState.useCosmicJarvisPortrait,
                use3dCharacter = uiState.use3dCharacter,
                onToggleCosmicVariant = { viewModel.toggleCosmicJarvisPortrait() },
                onToggle3dCharacter = { viewModel.toggle3dCharacter() },
                modifier = Modifier.fillMaxWidth()
            )

            // 2-Line Captions + Mic Level Meter + Bottom Controls
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        JarvisText(
                            text = "YOU",
                            style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                            color = tokens.textMuted
                        )
                        Row(
                            modifier = Modifier.width(120.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = if (uiState.micState == MicState.LIVE) Icons.Rounded.Mic else Icons.Rounded.MicOff,
                                contentDescription = "Mic level",
                                tint = if (uiState.micState == MicState.LIVE) tokens.success else tokens.warning,
                                modifier = Modifier.size(14.dp)
                            )
                            JarvisLevelMeter(level = uiState.diagnostics.micLevel, modifier = Modifier.weight(1f))
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    // User caption line: strictly shows "(mic paused)" while speaking on speaker
                    JarvisText(
                        text = if (isSpeakingOnSpeaker) {
                            MockData.copy("mic_paused_user", uiState.language)
                        } else {
                            uiState.lastCaptionUser
                        },
                        style = JarvisTypographyTokens.Body.copy(fontSize = 14.sp),
                        color = tokens.textMuted,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(10.dp))
                    JarvisText(
                        text = uiState.activeRole.name.uppercase(),
                        style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                        color = uiState.activeRole.accent
                    )
                    Spacer(Modifier.height(2.dp))
                    JarvisText(
                        text = uiState.lastCaptionJarvis,
                        style = JarvisTypographyTokens.Subtitle,
                        color = tokens.textPrimary,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // Bottom Control Bar: Mute, Stop, Camera, Keyboard, Switch Role
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    VoiceControlButton(
                        icon = if (uiState.isMuted) Icons.Rounded.MicOff else Icons.Rounded.Mic,
                        label = if (uiState.isMuted) "Unmute" else "Mute",
                        selected = uiState.isMuted,
                        onClick = { viewModel.toggleMute() }
                    )
                    VoiceControlButton(
                        icon = Icons.Rounded.Stop,
                        label = "Stop",
                        tint = Color.White,
                        containerColor = tokens.error,
                        onClick = { viewModel.stopVoiceSession() }
                    )
                    VoiceControlButton(
                        icon = Icons.Rounded.PhotoCamera,
                        label = "Camera",
                        onClick = {
                            viewModel.setLiveVoiceOpen(false)
                            viewModel.setCameraVisionOpen(true)
                        }
                    )
                    VoiceControlButton(
                        icon = Icons.Rounded.Keyboard,
                        label = "Keyboard",
                        onClick = {
                            viewModel.setLiveVoiceOpen(false)
                            viewModel.selectTab(MainTab.CHAT)
                        }
                    )
                    VoiceControlButton(
                        icon = Icons.Rounded.People,
                        label = "Role",
                        onClick = { viewModel.setRoleSheetVisible(true) }
                    )
                }
            }
        }
    }
}

@Composable
private fun VoiceControlButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    selected: Boolean = false,
    tint: Color = LocalJarvisTokens.current.textPrimary,
    containerColor: Color = LocalJarvisTokens.current.surfaceElevatedTop
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        JarvisIconButton(
            icon = icon,
            contentDescription = label,
            onClick = onClick,
            selected = selected,
            tint = tint,
            containerColor = containerColor
        )
        JarvisText(
            text = label,
            style = JarvisTypographyTokens.Caption,
            color = LocalJarvisTokens.current.textSecondary
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatAndCodingScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    val clipboard = LocalClipboardManager.current
    var inputText by remember { mutableStateOf("") }
    var expandedMsgId by remember { mutableStateOf<String?>(null) }
    val attachmentController = rememberAttachmentController(
        onAddAttachment = { viewModel.addAttachment(it) },
        onOpenCameraVision = { viewModel.setCameraVisionOpen(true) }
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header + Segmented Switch: Chat | Coding
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            JarvisText(
                text = if (uiState.chatTabMode == 0) "Conversation" else "Coding Studio",
                style = JarvisTypographyTokens.Title
            )
            JarvisStatusPill(
                state = uiState.assistantState,
                label = uiState.activeRole.name,
                onClick = { viewModel.setRoleSheetVisible(true) },
                onLongPress = { viewModel.setDebugPanelVisible(true) }
            )
        }

        JarvisSegmentedControl(
            options = listOf("Chat", "Coding"),
            selectedIndex = uiState.chatTabMode,
            onSelect = { viewModel.setChatTabMode(it) },
            modifier = Modifier.fillMaxWidth()
        )

        if (uiState.chatTabMode == 0) {
            // CHAT TAB with Pull-to-Refresh
            JarvisPullToRefreshBox(
                isRefreshing = uiState.isRefreshing,
                onRefresh = { viewModel.refreshPage("Conversation") },
                modifier = Modifier.weight(1f).fillMaxWidth()
            ) {
            if (uiState.chatMessages.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                    contentAlignment = Alignment.Center
                ) {
                    JarvisGlassCard(elevationLevel = 1, cornerRadius = 24.dp) {
                        JarvisText(text = "Fresh conversation", style = JarvisTypographyTokens.Subtitle)
                        Spacer(Modifier.height(6.dp))
                        JarvisText(
                            text = "No echo fragments, no clutter. Ask in English, Hindi, or Hinglish.",
                            style = JarvisTypographyTokens.Body,
                            color = tokens.textSecondary
                        )
                        Spacer(Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Summarize today", "Exam stress tips", "Bol, kya karna hai?").forEach { prompt ->
                                JarvisChip(
                                    label = prompt,
                                    selected = false,
                                    onClick = { viewModel.sendChatMessage(prompt) }
                                )
                            }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(uiState.chatMessages, key = { it.id }) { msg ->
                        val msgRole = MockData.roles.firstOrNull { it.id == msg.roleId } ?: uiState.activeRole
                        val showActions = expandedMsgId == msg.id
                        when (msg.kind) {
                            MessageKind.SYSTEM -> {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = tokens.info.copy(alpha = 0.14f),
                                    border = BorderStroke(1.dp, tokens.info.copy(alpha = 0.45f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Icon(Icons.Rounded.NotificationsActive, contentDescription = "System event", tint = tokens.info, modifier = Modifier.size(18.dp))
                                        JarvisText(text = msg.text, style = JarvisTypographyTokens.Caption, color = tokens.textPrimary, modifier = Modifier.weight(1f))
                                        JarvisText(text = msg.time, style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                                    }
                                }
                            }
                            MessageKind.USER -> {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Surface(
                                        shape = RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp),
                                        color = tokens.accent.copy(alpha = if (tokens.isLight) 0.18f else 0.26f),
                                        border = BorderStroke(1.dp, tokens.accent.copy(alpha = 0.5f)),
                                        modifier = Modifier
                                            .widthIn(max = 310.dp)
                                            .combinedClickable(
                                                onClick = { expandedMsgId = if (showActions) null else msg.id },
                                                onLongClick = { expandedMsgId = if (showActions) null else msg.id }
                                            )
                                    ) {
                                        Column(
                                            modifier = Modifier.padding(14.dp),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            if (msg.attachments.isNotEmpty()) {
                                                Row(
                                                    modifier = Modifier.horizontalScroll(rememberScrollState()),
                                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                                ) {
                                                    msg.attachments.forEach { att ->
                                                        if (att.previewBitmap != null) {
                                                            Image(
                                                                bitmap = att.previewBitmap,
                                                                contentDescription = att.label,
                                                                contentScale = ContentScale.Crop,
                                                                modifier = Modifier
                                                                    .size(68.dp)
                                                                    .clip(RoundedCornerShape(12.dp))
                                                                    .border(1.dp, tokens.accent2.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                                                            )
                                                        } else {
                                                            Surface(
                                                                shape = RoundedCornerShape(12.dp),
                                                                color = tokens.surfaceElevatedTop,
                                                                border = BorderStroke(1.dp, tokens.borderSubtle)
                                                            ) {
                                                                Row(
                                                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                                                    verticalAlignment = Alignment.CenterVertically,
                                                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                                ) {
                                                                    Icon(
                                                                        imageVector = when (att.kind) {
                                                                            AttachmentKind.CAMERA -> Icons.Rounded.PhotoCamera
                                                                            AttachmentKind.PHOTO -> Icons.Rounded.Photo
                                                                            AttachmentKind.FILE -> Icons.Rounded.Description
                                                                            AttachmentKind.VOICE_NOTE -> Icons.Rounded.GraphicEq
                                                                            AttachmentKind.SCREENSHOT -> Icons.Rounded.Screenshot
                                                                        },
                                                                        contentDescription = att.kind.label,
                                                                        tint = tokens.accent2,
                                                                        modifier = Modifier.size(16.dp)
                                                                    )
                                                                    JarvisText(
                                                                        text = att.label,
                                                                        style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp),
                                                                        maxLines = 1,
                                                                        overflow = TextOverflow.Ellipsis,
                                                                        modifier = Modifier.widthIn(max = 120.dp)
                                                                    )
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            JarvisText(
                                                text = msg.text,
                                                style = JarvisTypographyTokens.Body,
                                                color = tokens.textPrimary
                                            )
                                        }
                                    }
                                    if (showActions) {
                                        Spacer(Modifier.height(4.dp))
                                        JarvisText(text = "${msg.time} • Tap actions below", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                                    }
                                }
                            }
                            MessageKind.ASSISTANT -> {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.Start
                                ) {
                                    Row(
                                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                                        verticalAlignment = Alignment.Bottom
                                    ) {
                                        // Role Portrait Avatar (3D or Anime look)
                                        val avatarResId = (if (uiState.use3dCharacter) msgRole.characterAssets.portrait3dResId else null)
                                            ?: msgRole.characterAssets.portraitResId
                                        Image(
                                            painter = painterResource(id = avatarResId),
                                            contentDescription = "${msgRole.name} avatar",
                                            contentScale = ContentScale.Crop,
                                            alignment = Alignment.TopCenter,
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .border(1.5.dp, msgRole.accent, CircleShape)
                                        )
                                        JarvisGlassCard(
                                            elevationLevel = 1,
                                            cornerRadius = 20.dp,
                                            contentPadding = PaddingValues(14.dp),
                                            modifier = Modifier
                                                .widthIn(max = 290.dp)
                                                .combinedClickable(
                                                    onClick = { expandedMsgId = if (showActions) null else msg.id },
                                                    onLongClick = { expandedMsgId = if (showActions) null else msg.id }
                                                )
                                        ) {
                                            JarvisText(
                                                text = msgRole.name,
                                                style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                                                color = msgRole.accent
                                            )
                                            Spacer(Modifier.height(4.dp))
                                            JarvisText(text = msg.text, style = JarvisTypographyTokens.Body)
                                        }
                                    }
                                    if (showActions) {
                                        Spacer(Modifier.height(6.dp))
                                        Row(
                                            modifier = Modifier.padding(start = 40.dp),
                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                        ) {
                                            JarvisText(text = msg.time, style = JarvisTypographyTokens.Caption, color = tokens.textMuted, modifier = Modifier.align(Alignment.CenterVertically))
                                            JarvisChip(
                                                label = "Copy",
                                                selected = false,
                                                icon = Icons.Rounded.ContentCopy,
                                                onClick = {
                                                    clipboard.setText(AnnotatedString(msg.text))
                                                    viewModel.showToast("Copied message.")
                                                }
                                            )
                                            JarvisChip(
                                                label = "Speak",
                                                selected = false,
                                                icon = Icons.Rounded.VolumeUp,
                                                onClick = { viewModel.startVoiceSession(openFullScreen = true) }
                                            )
                                            JarvisChip(
                                                label = if (msg.savedToJournal) "Saved" else "Journal",
                                                selected = msg.savedToJournal,
                                                icon = Icons.Rounded.BookmarkAdd,
                                                onClick = { viewModel.saveMessageToJournal(msg.id) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (uiState.isAssistantTyping) {
                        item {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.padding(8.dp)
                            ) {
                                JarvisWaveform(active = false, isThinking = true, barCount = 8)
                                JarvisText(text = "${uiState.activeRole.name} is thinking...", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                            }
                        }
                    }
                }
            }
            }

            PendingAttachmentsStrip(
                attachments = uiState.pendingAttachments,
                onRemove = { viewModel.removeAttachment(it) }
            )

            // Message input bar with Attach button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                JarvisIconButton(
                    icon = Icons.Rounded.AddCircleOutline,
                    contentDescription = "Attach photo, camera, or file",
                    containerColor = tokens.surfaceElevatedTop,
                    tint = tokens.accent2,
                    onClick = { attachmentController.openSheet() }
                )
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = { JarvisText(MockData.copy("ask_placeholder", uiState.language), style = JarvisTypographyTokens.Body, color = tokens.textMuted) },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.weight(1f)
                )
                JarvisIconButton(
                    icon = Icons.Rounded.ArrowUpward,
                    contentDescription = "Send chat message",
                    containerColor = tokens.accent,
                    tint = tokens.onAccent,
                    onClick = {
                        if (inputText.isNotBlank() || uiState.pendingAttachments.isNotEmpty()) {
                            viewModel.sendChatMessage(inputText)
                            inputText = ""
                        }
                    }
                )
            }
        } else {
            // CODING TAB
            var codeInput by remember { mutableStateOf(uiState.codingPrompt) }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp) {
                    JarvisText(text = "Build a website or mini app", style = JarvisTypographyTokens.Subtitle)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = codeInput,
                        onValueChange = { codeInput = it },
                        placeholder = { JarvisText("e.g., Physics formula cheat-sheet with dark search...", style = JarvisTypographyTokens.Body, color = tokens.textMuted) },
                        minLines = 2,
                        maxLines = 4,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    // Empty state suggestion chips
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Study Pomodoro App", "Retro Space Dodger", "College Timetable Site").forEach { suggestion ->
                            JarvisChip(
                                label = suggestion,
                                selected = false,
                                onClick = { codeInput = suggestion }
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    JarvisPrimaryButton(
                        text = "Build Preview",
                        icon = Icons.Rounded.Code,
                        demoState = if (uiState.isBuildingCode) ComponentDemoState.LOADING else ComponentDemoState.DEFAULT,
                        onClick = { viewModel.runCodingBuild(codeInput) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // Live Preview Frame
                uiState.activePreviewBuild?.let { build ->
                    JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp, accentTint = build.accent) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                JarvisText(text = "LIVE PREVIEW", style = JarvisTypographyTokens.Caption.copy(fontFamily = JetBrainsMonoFontFamily), color = tokens.accent)
                                JarvisText(text = build.title, style = JarvisTypographyTokens.Subtitle)
                            }
                            Surface(shape = RoundedCornerShape(999.dp), color = tokens.success.copy(alpha = 0.2f)) {
                                JarvisText(text = "Ready", style = JarvisTypographyTokens.Caption, color = tokens.success, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(130.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Brush.linearGradient(listOf(tokens.bgTop, build.accent.copy(alpha = 0.25f))))
                                .border(1.dp, build.accent.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
                                .padding(14.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                                JarvisText(text = "index.html • app.js • styles.css", style = JarvisTypographyTokens.Caption.copy(fontFamily = JetBrainsMonoFontFamily), color = tokens.textMuted)
                                JarvisText(text = build.summary, style = JarvisTypographyTokens.Body, color = tokens.textPrimary)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            JarvisSecondaryButton(text = "Save ZIP", icon = Icons.Rounded.Download, onClick = { viewModel.showToast("Saved ${build.title}.zip") }, modifier = Modifier.weight(1f))
                            JarvisSecondaryButton(text = "Share", icon = Icons.Rounded.Share, onClick = { viewModel.showToast("Share sheet opened") }, modifier = Modifier.weight(1f))
                            JarvisSecondaryButton(text = "Change", icon = Icons.Rounded.Edit, onClick = { codeInput = build.prompt }, modifier = Modifier.weight(1f))
                        }
                    }
                }

                // Build History
                JarvisText(text = "Build History", style = JarvisTypographyTokens.Subtitle)
                uiState.buildHistory.forEach { item ->
                    JarvisGlassCard(
                        elevationLevel = 1,
                        cornerRadius = 18.dp,
                        onClick = { viewModel.showToast("Loaded preview: ${item.title}") }
                    ) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            JarvisText(text = item.title, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 15.sp), modifier = Modifier.weight(1f))
                            JarvisText(text = item.timestamp, style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                        }
                        Spacer(Modifier.height(4.dp))
                        JarvisText(text = item.prompt, style = JarvisTypographyTokens.Caption, color = tokens.textSecondary, maxLines = 2)
                    }
                }
            }
        }
    }
}
