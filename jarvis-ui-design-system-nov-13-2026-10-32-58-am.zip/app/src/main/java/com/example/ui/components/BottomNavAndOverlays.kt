package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MockData
import com.example.model.AssistantState
import com.example.model.LanguageMode
import com.example.model.MainTab
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.LocalJarvisTokens

@Composable
fun JarvisBottomNavigationBar(
    selectedTab: MainTab,
    assistantState: AssistantState,
    language: LanguageMode,
    onSelectTab: (MainTab) -> Unit,
    onTalkPress: () -> Unit,
    onSwipeUpTalk: () -> Unit = onTalkPress,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    val pulse = rememberInfiniteTransition(label = "talk_pulse")
    val haloScale = if (tokens.reduceMotion || assistantState != AssistantState.LISTENING) {
        1f
    } else {
        pulse.animateFloat(
            initialValue = 1.0f,
            targetValue = 1.22f,
            animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
            label = "talk_halo"
        ).value
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .height(92.dp),
        contentAlignment = Alignment.BottomCenter
    ) {
        // Base 72dp bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            color = tokens.surfaceElevatedTop.copy(alpha = if (tokens.isLight) 0.98f else 0.94f),
            border = BorderStroke(1.dp, tokens.borderTop.copy(alpha = 0.35f)),
            shadowElevation = 16.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                NavTabItem(
                    label = MockData.copy("nav_home", language),
                    icon = if (selectedTab == MainTab.HOME) Icons.Rounded.Home else Icons.Outlined.Home,
                    selected = selectedTab == MainTab.HOME,
                    onClick = { onSelectTab(MainTab.HOME) },
                    modifier = Modifier.weight(1f).testTag("nav_home")
                )
                NavTabItem(
                    label = MockData.copy("nav_chat", language),
                    icon = if (selectedTab == MainTab.CHAT) Icons.Rounded.ChatBubble else Icons.Outlined.ChatBubbleOutline,
                    selected = selectedTab == MainTab.CHAT,
                    onClick = { onSelectTab(MainTab.CHAT) },
                    modifier = Modifier.weight(1f).testTag("nav_chat")
                )
                // Center spacer for 64dp TALK FAB
                Box(
                    modifier = Modifier.weight(1f),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    JarvisText(
                        text = MockData.copy("nav_talk", language),
                        style = JarvisTypographyTokens.Caption.copy(
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = tokens.accent,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
                NavTabItem(
                    label = MockData.copy("nav_create", language),
                    icon = if (selectedTab == MainTab.CREATE) Icons.Rounded.AutoAwesome else Icons.Outlined.AutoAwesome,
                    selected = selectedTab == MainTab.CREATE,
                    onClick = { onSelectTab(MainTab.CREATE) },
                    modifier = Modifier.weight(1f).testTag("nav_create")
                )
                NavTabItem(
                    label = MockData.copy("nav_settings", language),
                    icon = if (selectedTab == MainTab.SETTINGS) Icons.Rounded.Settings else Icons.Outlined.Settings,
                    selected = selectedTab == MainTab.SETTINGS,
                    onClick = { onSelectTab(MainTab.SETTINGS) },
                    modifier = Modifier.weight(1f).testTag("nav_settings")
                )
            }
        }

        // Raised 64dp TALK button overlapping the bar by 20dp
        Box(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 0.dp)
                .size(68.dp),
            contentAlignment = Alignment.Center
        ) {
            if (assistantState == AssistantState.LISTENING) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .graphicsLayer {
                            scaleX = haloScale
                            scaleY = haloScale
                        }
                        .clip(CircleShape)
                        .background(tokens.accent.copy(alpha = 0.28f))
                )
            }
            val fabBrush = when (assistantState) {
                AssistantState.SPEAKING, AssistantState.THINKING -> Brush.linearGradient(listOf(tokens.error, tokens.error.copy(alpha = 0.85f)))
                AssistantState.MUTED -> Brush.linearGradient(listOf(tokens.textMuted, tokens.textMuted.copy(alpha = 0.85f)))
                else -> Brush.linearGradient(listOf(tokens.accent, tokens.accent2))
            }
            val fabFg = if (assistantState == AssistantState.SPEAKING || assistantState == AssistantState.THINKING) Color.White else tokens.onAccent

            Box(
                modifier = Modifier
                    .size(64.dp)
                    .shadow(14.dp, CircleShape, ambientColor = tokens.accent, spotColor = tokens.accent)
                    .clip(CircleShape)
                    .background(fabBrush)
                    .border(2.dp, Color.White.copy(alpha = 0.45f), CircleShape)
                    .pointerInput(Unit) {
                        var dragY = 0f
                        detectVerticalDragGestures(
                            onDragEnd = { dragY = 0f },
                            onDragCancel = { dragY = 0f },
                            onVerticalDrag = { _, dy ->
                                dragY += dy
                                if (dragY < -55f) {
                                    dragY = 0f
                                    onSwipeUpTalk()
                                }
                            }
                        )
                    }
                    .clickable(onClick = onTalkPress)
                    .testTag("nav_talk_fab"),
                contentAlignment = Alignment.Center
            ) {
                when (assistantState) {
                    AssistantState.CONNECTING -> CircularProgressIndicator(
                        modifier = Modifier.size(26.dp),
                        strokeWidth = 3.dp,
                        color = fabFg
                    )
                    AssistantState.SPEAKING, AssistantState.THINKING -> Icon(
                        imageVector = Icons.Rounded.Stop,
                        contentDescription = "Stop voice session",
                        tint = fabFg,
                        modifier = Modifier.size(30.dp)
                    )
                    AssistantState.MUTED -> Icon(
                        imageVector = Icons.Rounded.MicOff,
                        contentDescription = "Microphone muted",
                        tint = fabFg,
                        modifier = Modifier.size(26.dp)
                    )
                    else -> Icon(
                        imageVector = Icons.Rounded.Mic,
                        contentDescription = "Start talking to Jarvis",
                        tint = fabFg,
                        modifier = Modifier.size(28.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun NavTabItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    Column(
        modifier = modifier
            .heightIn(min = 56.dp)
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(999.dp))
                .background(if (selected) tokens.accent.copy(alpha = 0.22f) else Color.Transparent)
                .padding(horizontal = 14.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (selected) tokens.accent else tokens.textMuted,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(Modifier.height(2.dp))
        JarvisText(
            text = label,
            style = JarvisTypographyTokens.Caption.copy(
                fontSize = 11.5.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            ),
            color = if (selected) tokens.textPrimary else tokens.textMuted,
            maxLines = 1
        )
    }
}

/**
 * Wraps the entire prototype inside either full-bleed native Android mode
 * or the centered 360/412/480 x 915 dp Galaxy A50s prototype frame when enabled.
 */
@Composable
fun ViewportFrameWrapper(
    deviceFrameEnabled: Boolean,
    viewportWidthDp: Int,
    onToggleFrame: () -> Unit,
    onSelectWidth: (Int) -> Unit,
    content: @Composable () -> Unit
) {
    val tokens = LocalJarvisTokens.current
    if (!deviceFrameEnabled) {
        Box(modifier = Modifier.fillMaxSize()) {
            content()
        }
    } else {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF06070B))
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxSize().padding(8.dp)
            ) {
                // Live Viewport Width Switcher (360 / 412 / 480 dp)
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(360, 412, 480).forEach { w ->
                        JarvisChip(
                            label = "${w}dp",
                            selected = viewportWidthDp == w,
                            onClick = { onSelectWidth(w) }
                        )
                    }
                    JarvisChip(
                        label = "Full",
                        selected = false,
                        onClick = onToggleFrame,
                        icon = Icons.Rounded.Fullscreen
                    )
                }

                // Centered Phone Bezel
                Box(
                    modifier = Modifier
                        .widthIn(max = viewportWidthDp.dp)
                        .fillMaxWidth()
                        .weight(1f)
                        .clip(RoundedCornerShape(36.dp))
                        .border(3.dp, tokens.accent.copy(alpha = 0.55f), RoundedCornerShape(36.dp))
                ) {
                    content()
                }
            }
        }
    }
}
