package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AssistantState
import com.example.model.ComponentDemoState
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.LocalJarvisTokens
import com.example.ui.theme.PlusJakartaFontFamily
import com.example.ui.theme.fontForText
import kotlin.math.sin

@Composable
fun JarvisText(
    text: String,
    modifier: Modifier = Modifier,
    style: TextStyle = JarvisTypographyTokens.Body,
    color: Color = LocalJarvisTokens.current.textPrimary,
    fontFamily: FontFamily = style.fontFamily ?: PlusJakartaFontFamily,
    fontWeight: FontWeight? = style.fontWeight,
    maxLines: Int = Int.MAX_VALUE,
    overflow: TextOverflow = TextOverflow.Clip
) {
    Text(
        text = text,
        modifier = modifier,
        style = style.copy(
            fontFamily = fontForText(fontFamily, text),
            fontWeight = fontWeight ?: style.fontWeight
        ),
        color = color,
        maxLines = maxLines,
        overflow = overflow
    )
}

@Composable
fun JarvisGlassCard(
    modifier: Modifier = Modifier,
    elevationLevel: Int = 1,
    cornerRadius: Dp = 24.dp,
    accentTint: Color? = null,
    onClick: (() -> Unit)? = null,
    contentPadding: PaddingValues = PaddingValues(16.dp),
    content: @Composable ColumnScope.() -> Unit
) {
    val tokens = LocalJarvisTokens.current
    val shape = RoundedCornerShape(cornerRadius)
    val shadowDp = when (elevationLevel) {
        3 -> 20.dp
        2 -> 12.dp
        else -> 6.dp
    }
    val topColor = when {
        accentTint != null && tokens.isLight -> Color.White
        accentTint != null -> accentTint.copy(alpha = 0.16f)
        elevationLevel >= 2 -> tokens.surfaceElevatedTop
        else -> tokens.surfaceCardTop
    }
    val bottomColor = when {
        accentTint != null && tokens.isLight -> accentTint.copy(alpha = 0.08f)
        accentTint != null -> tokens.surfaceCardBottom
        elevationLevel >= 2 -> tokens.surfaceElevatedBottom
        else -> tokens.surfaceCardBottom
    }
    val borderBrush = Brush.verticalGradient(
        colors = listOf(
            tokens.borderTop,
            tokens.borderSubtle.copy(alpha = if (tokens.isLight) 0.35f else 0.14f)
        )
    )

    val clickMod = if (onClick != null) {
        Modifier.clickable(role = Role.Button, onClick = onClick)
    } else Modifier

    Column(
        modifier = modifier
            .shadow(
                elevation = shadowDp,
                shape = shape,
                ambientColor = accentTint?.copy(alpha = 0.25f) ?: tokens.shadowColor,
                spotColor = tokens.shadowColor
            )
            .clip(shape)
            .background(Brush.verticalGradient(listOf(topColor, bottomColor)))
            .border(width = 1.dp, brush = borderBrush, shape = shape)
            .then(clickMod)
            .padding(contentPadding),
        content = content
    )
}

@Composable
fun JarvisPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    demoState: ComponentDemoState = ComponentDemoState.DEFAULT,
    enabled: Boolean = true,
    testTag: String = "primary_button"
) {
    val tokens = LocalJarvisTokens.current
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val effectivePressed = isPressed || demoState == ComponentDemoState.PRESSED
    val effectiveEnabled = enabled && demoState != ComponentDemoState.DISABLED && demoState != ComponentDemoState.LOADING

    val scale by animateFloatAsState(
        targetValue = if (effectivePressed) 0.97f else 1f,
        animationSpec = tween(120),
        label = "btn_scale"
    )

    val bgBrush = when (demoState) {
        ComponentDemoState.ERROR -> Brush.horizontalGradient(listOf(tokens.error, tokens.error.copy(alpha = 0.85f)))
        ComponentDemoState.SUCCESS -> Brush.horizontalGradient(listOf(tokens.success, tokens.success.copy(alpha = 0.85f)))
        ComponentDemoState.DISABLED -> Brush.horizontalGradient(listOf(tokens.textMuted.copy(alpha = 0.28f), tokens.textMuted.copy(alpha = 0.22f)))
        else -> Brush.horizontalGradient(listOf(tokens.accent, tokens.accent2))
    }

    val fgColor = when (demoState) {
        ComponentDemoState.DISABLED -> tokens.textMuted
        ComponentDemoState.ERROR -> Color.White
        ComponentDemoState.SUCCESS -> Color(0xFF06150E)
        else -> tokens.onAccent
    }

    Box(
        modifier = modifier
            .heightIn(min = 56.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(
                elevation = if (effectiveEnabled) 10.dp else 0.dp,
                shape = RoundedCornerShape(16.dp),
                ambientColor = tokens.accent.copy(alpha = 0.35f),
                spotColor = tokens.accent.copy(alpha = 0.35f)
            )
            .clip(RoundedCornerShape(16.dp))
            .background(bgBrush)
            .border(1.dp, Color.White.copy(alpha = if (effectiveEnabled) 0.25f else 0.08f), RoundedCornerShape(16.dp))
            .clickable(
                interactionSource = interactionSource,
                indication = androidx.compose.material3.ripple(color = fgColor),
                enabled = effectiveEnabled,
                onClick = onClick
            )
            .padding(horizontal = 20.dp, vertical = 14.dp)
            .testTag(testTag),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when (demoState) {
                ComponentDemoState.LOADING -> {
                    CircularProgressIndicator(
                        modifier = Modifier.size(18.dp),
                        strokeWidth = 2.dp,
                        color = fgColor
                    )
                }
                ComponentDemoState.ERROR -> Icon(Icons.Rounded.ErrorOutline, contentDescription = null, tint = fgColor, modifier = Modifier.size(20.dp))
                ComponentDemoState.SUCCESS -> Icon(Icons.Rounded.Check, contentDescription = null, tint = fgColor, modifier = Modifier.size(20.dp))
                else -> if (icon != null) {
                    Icon(icon, contentDescription = null, tint = fgColor, modifier = Modifier.size(20.dp))
                }
            }
            JarvisText(
                text = when (demoState) {
                    ComponentDemoState.LOADING -> "Working..."
                    ComponentDemoState.ERROR -> "Retry"
                    ComponentDemoState.SUCCESS -> "Done"
                    else -> text
                },
                style = JarvisTypographyTokens.Subtitle,
                color = fgColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun JarvisSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    demoState: ComponentDemoState = ComponentDemoState.DEFAULT
) {
    val tokens = LocalJarvisTokens.current
    val effectiveEnabled = enabled && demoState != ComponentDemoState.DISABLED
    val borderColor = when (demoState) {
        ComponentDemoState.ERROR -> tokens.error
        ComponentDemoState.SUCCESS -> tokens.success
        else -> tokens.accent.copy(alpha = 0.45f)
    }
    Surface(
        onClick = onClick,
        enabled = effectiveEnabled,
        modifier = modifier.heightIn(min = 48.dp),
        shape = RoundedCornerShape(16.dp),
        color = if (demoState == ComponentDemoState.PRESSED) tokens.accent.copy(alpha = 0.16f) else tokens.surfaceCardTop,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            if (demoState == ComponentDemoState.LOADING) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = tokens.accent)
                Spacer(Modifier.width(8.dp))
            } else if (icon != null) {
                Icon(icon, contentDescription = null, tint = if (effectiveEnabled) tokens.accent else tokens.textMuted, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
            }
            JarvisText(
                text = text,
                style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp),
                color = if (effectiveEnabled) tokens.textPrimary else tokens.textMuted,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun JarvisTertiaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    color: Color = LocalJarvisTokens.current.accent,
    enabled: Boolean = true
) {
    Box(
        modifier = modifier
            .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        JarvisText(
            text = text,
            style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp),
            color = if (enabled) color else LocalJarvisTokens.current.textMuted
        )
    }
}

@Composable
fun JarvisIconButton(
    icon: ImageVector,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    tint: Color = LocalJarvisTokens.current.textPrimary,
    containerColor: Color = LocalJarvisTokens.current.surfaceCardTop,
    selected: Boolean = false
) {
    val tokens = LocalJarvisTokens.current
    Surface(
        onClick = onClick,
        modifier = modifier.size(48.dp),
        shape = CircleShape,
        color = if (selected) tokens.accent.copy(alpha = 0.22f) else containerColor,
        border = BorderStroke(1.dp, if (selected) tokens.accent else tokens.borderTop.copy(alpha = 0.35f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (selected) tokens.accent else tint,
                modifier = Modifier.size(22.dp)
            )
        }
    }
}

@Composable
fun JarvisChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    accentOverride: Color? = null
) {
    val tokens = LocalJarvisTokens.current
    val activeColor = accentOverride ?: tokens.accent
    val bgColor by animateColorAsState(
        targetValue = if (selected) activeColor.copy(alpha = if (tokens.isLight) 0.16f else 0.22f) else tokens.surfaceCardTop,
        animationSpec = tween(220),
        label = "chip_bg"
    )
    val borderColor = if (selected) activeColor else tokens.borderSubtle

    Surface(
        onClick = onClick,
        modifier = modifier.heightIn(min = 40.dp),
        shape = RoundedCornerShape(999.dp),
        color = bgColor,
        border = BorderStroke(1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            if (icon != null) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (selected) activeColor else tokens.textSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
            JarvisText(
                text = label,
                style = JarvisTypographyTokens.Caption.copy(fontSize = 13.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium),
                color = if (selected) (if (tokens.isLight) activeColor else tokens.textPrimary) else tokens.textSecondary,
                maxLines = 1
            )
        }
    }
}

@Composable
fun JarvisSegmentedControl(
    options: List<String>,
    selectedIndex: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(tokens.surfaceCardBottom)
            .border(1.dp, tokens.borderSubtle, RoundedCornerShape(16.dp))
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        options.forEachIndexed { index, title ->
            val selected = index == selectedIndex
            Box(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (selected) Brush.horizontalGradient(listOf(tokens.accent, tokens.accent2))
                        else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
                    )
                    .clickable { onSelect(index) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                JarvisText(
                    text = title,
                    style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp),
                    color = if (selected) tokens.onAccent else tokens.textSecondary,
                    maxLines = 1
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun JarvisStatusPill(
    state: AssistantState,
    label: String,
    onClick: () -> Unit,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    val dotColor = when (state) {
        AssistantState.IDLE -> tokens.success
        AssistantState.CONNECTING -> tokens.warning
        AssistantState.LISTENING -> tokens.accent
        AssistantState.THINKING -> tokens.accent2
        AssistantState.SPEAKING -> tokens.info
        AssistantState.INTERRUPTED -> tokens.warning
        AssistantState.MUTED -> tokens.textMuted
        AssistantState.ERROR -> tokens.error
        AssistantState.OFFLINE -> tokens.textMuted
    }

    val pulse = rememberInfiniteTransition(label = "pill_pulse")
    val dotAlpha = if (tokens.reduceMotion || (state != AssistantState.LISTENING && state != AssistantState.SPEAKING && state != AssistantState.CONNECTING)) {
        1f
    } else {
        pulse.animateFloat(
            initialValue = 0.4f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(650), RepeatMode.Reverse),
            label = "dot_alpha"
        ).value
    }

    Row(
        modifier = modifier
            .heightIn(min = 36.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(tokens.surfaceElevatedTop)
            .border(1.dp, dotColor.copy(alpha = 0.55f), RoundedCornerShape(999.dp))
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongPress
            )
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("status_pill"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .alpha(dotAlpha)
                .clip(CircleShape)
                .background(dotColor)
        )
        JarvisText(
            text = label,
            style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.SemiBold),
            color = tokens.textPrimary,
            maxLines = 1
        )
    }
}

@Composable
fun JarvisProgressRing(
    progress: Float,
    modifier: Modifier = Modifier,
    size: Dp = 64.dp,
    strokeWidth: Dp = 6.dp,
    color: Color = LocalJarvisTokens.current.accent,
    trackColor: Color = LocalJarvisTokens.current.borderSubtle,
    centerLabel: String? = null
) {
    val tokens = LocalJarvisTokens.current
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokePx = strokeWidth.toPx()
            drawArc(
                color = trackColor,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = (progress.coerceIn(0f, 1f)) * 360f,
                useCenter = false,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
        }
        if (centerLabel != null) {
            JarvisText(
                text = centerLabel,
                style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                color = tokens.textPrimary
            )
        }
    }
}

@Composable
fun JarvisWaveform(
    active: Boolean,
    isThinking: Boolean = false,
    barCount: Int = 14,
    modifier: Modifier = Modifier,
    color: Color = LocalJarvisTokens.current.accent
) {
    val tokens = LocalJarvisTokens.current
    val transition = rememberInfiniteTransition(label = "wave")
    val phase = if (tokens.reduceMotion || (!active && !isThinking)) {
        0f
    } else {
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 6.28318f,
            animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing)),
            label = "wave_phase"
        ).value
    }

    Row(
        modifier = modifier.height(28.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        for (i in 0 until barCount) {
            val scaleY = when {
                !active && !isThinking -> 0.25f
                isThinking -> 0.35f + 0.35f * ((sin(phase + i * 0.55f) + 1f) / 2f)
                else -> 0.25f + 0.75f * ((sin(phase * 1.4f + i * 0.7f) + 1f) / 2f)
            }
            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(24.dp)
                    .graphicsLayer { this.scaleY = scaleY }
                    .clip(RoundedCornerShape(999.dp))
                    .background(if (isThinking) tokens.accent2 else color)
            )
        }
    }
}

@Composable
fun JarvisLevelMeter(
    level: Float,
    modifier: Modifier = Modifier,
    segments: Int = 12
) {
    val tokens = LocalJarvisTokens.current
    Row(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        for (i in 0 until segments) {
            val threshold = (i + 1) / segments.toFloat()
            val lit = level >= threshold
            val barColor = when {
                !lit -> tokens.borderSubtle.copy(alpha = 0.45f)
                i >= segments - 2 -> tokens.error
                i >= segments - 4 -> tokens.warning
                else -> tokens.success
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(8.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(barColor)
            )
        }
    }
}

@Composable
fun JarvisSkeletonBox(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 12.dp
) {
    val tokens = LocalJarvisTokens.current
    val pulse = rememberInfiniteTransition(label = "skel")
    val alpha = if (tokens.reduceMotion) 0.35f else pulse.animateFloat(
        initialValue = 0.22f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "skel_alpha"
    ).value

    Box(
        modifier = modifier
            .alpha(alpha)
            .clip(RoundedCornerShape(cornerRadius))
            .background(tokens.textMuted.copy(alpha = 0.30f))
    )
}

@Composable
fun ScrollFadeEdge(
    modifier: Modifier = Modifier,
    bgColor: Color = LocalJarvisTokens.current.bgBottom
) {
    Box(
        modifier = modifier
            .width(28.dp)
            .fillMaxHeight()
            .background(
                Brush.horizontalGradient(
                    colors = listOf(Color.Transparent, bgColor.copy(alpha = 0.92f))
                )
            )
    )
}
