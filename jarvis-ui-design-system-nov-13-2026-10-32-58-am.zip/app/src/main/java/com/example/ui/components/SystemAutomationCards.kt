package com.example.ui.components

import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalJarvisTokens
import com.example.viewmodel.JarvisUiState
import com.example.viewmodel.JarvisViewModel

@Composable
fun SystemAutomationConsoleSection(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    val auto = uiState.automation

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                JarvisText(text = "System Automation Engine", style = JarvisTypographyTokens.Subtitle)
                JarvisText(
                    text = "Real OS intents, Accessibility actions & Notification control",
                    style = JarvisTypographyTokens.Caption,
                    color = tokens.textMuted
                )
            }
            JarvisIconButton(
                icon = Icons.Rounded.Refresh,
                contentDescription = "Refresh OS automation status",
                onClick = {
                    viewModel.refreshSystemAutomation()
                    viewModel.showToast("Refreshed OS capabilities & installed apps.")
                }
            )
        }

        // 1. Live OS Capabilities Row (Accessibility, Notification Listener, DND Policy)
        JarvisGlassCard(elevationLevel = 2, cornerRadius = 22.dp, accentTint = tokens.accent2) {
            JarvisText(text = "Android OS Service Bridges", style = JarvisTypographyTokens.Caption, color = tokens.accent2)
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ServiceStatusChip(
                    label = "Accessibility",
                    enabled = auto.accessibilityEnabled,
                    onClick = { viewModel.openAutomationSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS) },
                    testTag = "auto_service_accessibility"
                )
                ServiceStatusChip(
                    label = "Notification Access",
                    enabled = auto.notificationListenerEnabled,
                    onClick = { viewModel.openAutomationSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) },
                    testTag = "auto_service_notifications"
                )
                ServiceStatusChip(
                    label = "DND Policy",
                    enabled = auto.dndPolicyGranted,
                    onClick = { viewModel.openAutomationSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS) },
                    testTag = "auto_service_dnd"
                )
            }

            Spacer(Modifier.height(12.dp))
            JarvisText(text = "Screen-Lock & Notification Actions", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                AutomationQuickPill(
                    label = "Lock Screen",
                    icon = Icons.Rounded.Lock,
                    onClick = { viewModel.executeScreenLock() },
                    testTag = "auto_lock_screen"
                )
                AutomationQuickPill(
                    label = "Unlock Gesture",
                    icon = Icons.Rounded.Pattern,
                    onClick = { viewModel.executeUnlockGesture() },
                    testTag = "auto_unlock_gesture"
                )
                AutomationQuickPill(
                    label = "Open Shade",
                    icon = Icons.Rounded.Notifications,
                    onClick = { viewModel.openSystemNotificationShade() },
                    testTag = "auto_open_shade"
                )
                AutomationQuickPill(
                    label = "Clear Tray",
                    icon = Icons.Rounded.ClearAll,
                    onClick = { viewModel.clearAllSystemNotifications() },
                    testTag = "auto_clear_notifications"
                )
                AutomationQuickPill(
                    label = if (uiState.quickToggles.dndOn) "DND: ON" else "DND: OFF",
                    icon = Icons.Rounded.DoNotDisturbOn,
                    onClick = { viewModel.toggleDnd() },
                    testTag = "auto_toggle_dnd"
                )
                AutomationQuickPill(
                    label = "Screenshot",
                    icon = Icons.Rounded.Screenshot,
                    onClick = { viewModel.triggerQuickAction("Screenshot") },
                    testTag = "auto_screenshot"
                )
            }
        }

        // 2. Gaming & App Launchers (BGMI, Minecraft, Free Fire MAX, YouTube, WhatsApp, Telegram)
        JarvisGlassCard(elevationLevel = 1, cornerRadius = 22.dp) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                JarvisText(text = "Gaming & App Launcher", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 15.sp))
                val installedCount = auto.targetApps.count { it.installed }
                JarvisText(
                    text = "$installedCount/${auto.targetApps.size} installed",
                    style = JarvisTypographyTokens.Caption,
                    color = tokens.accent2
                )
            }
            Spacer(Modifier.height(10.dp))
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                auto.targetApps.chunked(2).forEach { pair ->
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        pair.forEach { app ->
                            Surface(
                                onClick = { viewModel.launchSystemApp(app.id) },
                                shape = RoundedCornerShape(16.dp),
                                color = tokens.surfaceCardBottom,
                                border = BorderStroke(
                                    1.dp,
                                    if (app.installed) tokens.success.copy(alpha = 0.55f) else tokens.borderSubtle
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("launch_${app.id}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (app.installed) tokens.success.copy(alpha = 0.16f)
                                                else tokens.accent.copy(alpha = 0.14f)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (app.category == "Gaming") Icons.Rounded.SportsEsports else Icons.Rounded.Launch,
                                            contentDescription = app.name,
                                            tint = if (app.installed) tokens.success else tokens.accent2,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        JarvisText(
                                            text = app.name,
                                            style = JarvisTypographyTokens.Subtitle.copy(fontSize = 13.sp),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        JarvisText(
                                            text = if (app.installed) "Installed • Open" else "Store • Get App",
                                            style = JarvisTypographyTokens.Caption.copy(fontSize = 10.sp),
                                            color = if (app.installed) tokens.success else tokens.textMuted,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                        if (pair.size == 1) {
                            Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }

        // 3. Live Notification Tray Manager
        JarvisGlassCard(elevationLevel = 1, cornerRadius = 22.dp) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    JarvisText(text = "Notification Manager", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 15.sp))
                    JarvisText(
                        text = if (auto.notificationListenerEnabled) {
                            "${auto.liveNotifications.size} active OS notification(s)"
                        } else {
                            "Enable Notification Access to read & dismiss real OS alerts"
                        },
                        style = JarvisTypographyTokens.Caption,
                        color = tokens.textMuted
                    )
                }
                if (auto.notificationListenerEnabled) {
                    JarvisTertiaryButton(
                        text = "Clear All",
                        onClick = { viewModel.clearAllSystemNotifications() }
                    )
                } else {
                    JarvisChip(
                        label = "Grant",
                        selected = false,
                        icon = Icons.Rounded.NotificationsActive,
                        onClick = { viewModel.openAutomationSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
                    )
                }
            }
            if (uiState.overlayNotifications.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    uiState.overlayNotifications.take(4).forEach { notif ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp))
                                .background(tokens.surfaceCardBottom)
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                JarvisText(
                                    text = "${notif.appName} • ${notif.sender}",
                                    style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                                    color = tokens.accent2,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                JarvisText(
                                    text = notif.text,
                                    style = JarvisTypographyTokens.Caption,
                                    color = tokens.textSecondary,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            JarvisIconButton(
                                icon = Icons.Rounded.Close,
                                contentDescription = "Dismiss ${notif.sender} notification",
                                onClick = { viewModel.dismissLiveNotification(notif.id) }
                            )
                        }
                    }
                }
            }
        }

        // 4. Execution Audit Log
        if (auto.executionLog.isNotEmpty()) {
            JarvisGlassCard(elevationLevel = 1, cornerRadius = 22.dp) {
                JarvisText(text = "Automation Execution Log", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 15.sp))
                Spacer(Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    auto.executionLog.take(5).forEach { entry ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = if (entry.success) Icons.Rounded.CheckCircle else Icons.Rounded.Info,
                                contentDescription = null,
                                tint = if (entry.success) tokens.success else tokens.warning,
                                modifier = Modifier.size(16.dp)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                JarvisText(
                                    text = "${entry.title} • ${entry.executedVia}",
                                    style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                JarvisText(
                                    text = entry.detail,
                                    style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp),
                                    color = tokens.textMuted,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            JarvisText(
                                text = entry.timestamp,
                                style = JarvisTypographyTokens.Caption.copy(fontSize = 10.sp, fontFamily = JetBrainsMonoFontFamily),
                                color = tokens.textMuted
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ServiceStatusChip(
    label: String,
    enabled: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val tokens = LocalJarvisTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(999.dp),
        color = if (enabled) tokens.success.copy(alpha = 0.16f) else tokens.warning.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, if (enabled) tokens.success else tokens.warning),
        modifier = Modifier.heightIn(min = 48.dp).testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = if (enabled) Icons.Rounded.VerifiedUser else Icons.Rounded.SettingsSuggest,
                contentDescription = label,
                tint = if (enabled) tokens.success else tokens.warning,
                modifier = Modifier.size(16.dp)
            )
            JarvisText(
                text = if (enabled) "$label: ON" else "Enable $label",
                style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                color = if (enabled) tokens.success else tokens.warning
            )
        }
    }
}

@Composable
private fun AutomationQuickPill(
    label: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    val tokens = LocalJarvisTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        color = tokens.surfaceCardBottom,
        border = BorderStroke(1.dp, tokens.accent.copy(alpha = 0.45f)),
        modifier = Modifier.heightIn(min = 48.dp).testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon, contentDescription = label, tint = tokens.accent2, modifier = Modifier.size(17.dp))
            JarvisText(
                text = label,
                style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.SemiBold),
                color = tokens.textPrimary
            )
        }
    }
}
