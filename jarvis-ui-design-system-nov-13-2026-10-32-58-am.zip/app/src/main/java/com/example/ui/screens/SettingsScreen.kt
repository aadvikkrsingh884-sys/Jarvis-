package com.example.ui.screens

import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.MockData
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalJarvisTokens
import com.example.viewmodel.JarvisUiState
import com.example.viewmodel.JarvisViewModel

@Composable
fun SettingsScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    val clipboard = LocalClipboardManager.current
    var expandedGroup by remember { mutableStateOf<String?>("ai_provider") }
    var showEraseDialog by remember { mutableStateOf(false) }
    var eraseConfirmText by remember { mutableStateOf("") }
    var voiceFilterIndianOnly by remember { mutableStateOf(false) }

    val selectedProvider = uiState.providers.firstOrNull { it.id == uiState.selectedProviderId } ?: uiState.providers.first()
    val selectedVoice = MockData.voices.firstOrNull { it.id == uiState.selectedVoiceId } ?: MockData.voices.first()
    val grantedCount = uiState.permissions.count { it.granted }

    JarvisPullToRefreshBox(
        isRefreshing = uiState.isRefreshing,
        onRefresh = { viewModel.refreshPage("Settings") },
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(top = 12.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                JarvisText(text = "Settings", style = JarvisTypographyTokens.Title)
                JarvisText(text = "12 grouped controls • Galaxy A50s tuned", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            }
            JarvisStatusPill(
                state = uiState.assistantState,
                label = "${grantedCount}/${uiState.permissions.size} Ready",
                onClick = { viewModel.openSubScreen(SubScreen.SETUP_WIZARD) },
                onLongPress = { viewModel.setDebugPanelVisible(true) }
            )
        }

        // Quick Tools Banner (System Brain & Design System & Overlay Artboard & Setup Wizard)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            JarvisChip(label = "System Brain", selected = false, icon = Icons.Rounded.Hub, onClick = { viewModel.openSubScreen(SubScreen.COMMAND_CENTER) })
            JarvisChip(label = "Design System", selected = false, icon = Icons.Rounded.Widgets, onClick = { viewModel.openSubScreen(SubScreen.DESIGN_SYSTEM) })
            JarvisChip(label = "Overlay Artboard", selected = false, icon = Icons.Rounded.Layers, onClick = { viewModel.openSubScreen(SubScreen.OVERLAY_ARTBOARD) })
            JarvisChip(label = "Setup Wizard", selected = false, icon = Icons.Rounded.FactCheck, onClick = { viewModel.openSubScreen(SubScreen.SETUP_WIZARD) })
        }

        // 1. AI PROVIDER
        SettingsGroupCard(
            id = "ai_provider",
            title = "AI Provider",
            subtitle = "${selectedProvider.name} • ${selectedProvider.selectedModel}",
            statusLabel = if (selectedProvider.keyTestedOk == true) "ACTIVE" else "CHECK KEY",
            statusOk = selectedProvider.keyTestedOk == true,
            icon = Icons.Rounded.Memory,
            expanded = expandedGroup == "ai_provider",
            onToggle = { expandedGroup = if (expandedGroup == "ai_provider") null else "ai_provider" }
        ) {
            // 6 Provider cards
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                uiState.providers.forEach { prov ->
                    val isSel = prov.id == uiState.selectedProviderId
                    Surface(
                        onClick = { viewModel.selectProvider(prov.id) },
                        shape = RoundedCornerShape(16.dp),
                        color = if (isSel) tokens.accent.copy(alpha = 0.2f) else tokens.surfaceCardBottom,
                        border = BorderStroke(1.dp, if (isSel) tokens.accent else tokens.borderSubtle)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                JarvisText(text = prov.name, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                                Surface(
                                    shape = RoundedCornerShape(999.dp),
                                    color = if (prov.isFree) tokens.success.copy(alpha = 0.2f) else tokens.warning.copy(alpha = 0.2f)
                                ) {
                                    JarvisText(
                                        text = if (prov.isFree) "Free" else "Paid",
                                        style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp),
                                        color = if (prov.isFree) tokens.success else tokens.warning,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            JarvisText(text = prov.portalHint, style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = selectedProvider.apiKey,
                onValueChange = { viewModel.updateProviderKey(selectedProvider.id, it) },
                label = { JarvisText("${selectedProvider.name} Key", style = JarvisTypographyTokens.Caption) },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisSecondaryButton(text = "Get free key", icon = Icons.Rounded.OpenInNew, onClick = { viewModel.showToast("Opening ${selectedProvider.portalHint}") }, modifier = Modifier.weight(1f))
                JarvisPrimaryButton(text = "Test key", icon = Icons.Rounded.Verified, onClick = { viewModel.testProviderKey(selectedProvider.id) }, modifier = Modifier.weight(1f))
            }
            selectedProvider.keyTestedOk?.let { ok ->
                Spacer(Modifier.height(6.dp))
                JarvisText(
                    text = if (ok) "Key passed check • Ready for voice & chat." else "Key failed check — paste at least 8 characters.",
                    style = JarvisTypographyTokens.Caption,
                    color = if (ok) tokens.success else tokens.error
                )
            }
            Spacer(Modifier.height(10.dp))
            JarvisText(text = "Model Picker", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                selectedProvider.models.forEach { model ->
                    JarvisChip(label = model, selected = model == selectedProvider.selectedModel, onClick = { viewModel.selectProviderModel(selectedProvider.id, model) })
                }
            }
        }

        // 2. VOICE (30 voices + sample + language + reply pause slider 0.5-3s + headphones tip + Indian TTS)
        SettingsGroupCard(
            id = "voice",
            title = "Voice & Language",
            subtitle = "${selectedVoice.name} • ${uiState.language.label} • ${String.format("%.1f", uiState.replyPauseSec)}s pause",
            statusLabel = if (selectedVoice.isIndianTts) "IN TTS" else "GLOBAL",
            statusOk = true,
            icon = Icons.Rounded.RecordVoiceOver,
            expanded = expandedGroup == "voice",
            onToggle = { expandedGroup = if (expandedGroup == "voice") null else "voice" }
        ) {
            JarvisText(text = "Language", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LanguageMode.entries.forEach { lang ->
                    JarvisChip(label = lang.label, selected = uiState.language == lang, onClick = { viewModel.setLanguage(lang) })
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisText(text = "Reply Pause: ${String.format("%.1f", uiState.replyPauseSec)}s", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                JarvisText(text = "0.5s – 3.0s", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            }
            Slider(
                value = uiState.replyPauseSec,
                onValueChange = { viewModel.setReplyPause(it) },
                valueRange = 0.5f..3.0f,
                colors = SliderDefaults.colors(thumbColor = tokens.accent, activeTrackColor = tokens.accent)
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisText(text = "30 Live Voices", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                JarvisChip(label = "Indian TTS only", selected = voiceFilterIndianOnly, onClick = { voiceFilterIndianOnly = !voiceFilterIndianOnly })
            }
            Spacer(Modifier.height(8.dp))
            val displayedVoices = if (voiceFilterIndianOnly) MockData.voices.filter { it.isIndianTts } else MockData.voices
            Column(modifier = Modifier.heightIn(max = 220.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                displayedVoices.forEach { v ->
                    val isSel = v.id == uiState.selectedVoiceId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSel) tokens.accent.copy(alpha = 0.16f) else tokens.surfaceCardBottom)
                            .clickable { viewModel.selectVoice(v.id) }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            JarvisText(text = v.name, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                            JarvisText(text = "${v.accent} • ${v.style}", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                        }
                        JarvisIconButton(
                            icon = Icons.Rounded.PlayArrow,
                            contentDescription = "Play voice sample ${v.name}",
                            onClick = { viewModel.showToast("Playing sample: ${v.name} (${v.accent})") }
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            JarvisText(
                text = "Tip: Connect wired or Bluetooth headphones for instant barge-in interruption without echo.",
                style = JarvisTypographyTokens.Caption,
                color = tokens.info
            )
        }

        // 3. ROLES & CHARACTERS
        SettingsGroupCard(
            id = "roles",
            title = "Roles & Characters",
            subtitle = "${uiState.activeRole.name} • Auto-switch ${if (uiState.autoSwitchRole) "ON" else "OFF"}",
            statusLabel = uiState.activeRole.name.uppercase(),
            statusOk = true,
            icon = Icons.Rounded.People,
            expanded = expandedGroup == "roles",
            onToggle = { expandedGroup = if (expandedGroup == "roles") null else "roles" }
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    JarvisText(text = "Mood Auto-Switch", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                    JarvisText(text = "Automatically adapts role when stress or warmth is detected", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                }
                Switch(checked = uiState.autoSwitchRole, onCheckedChange = { viewModel.setAutoSwitchRole(it) })
            }
            Spacer(Modifier.height(10.dp))
            JarvisText(text = "Emotion Style", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Balanced Natural", "Calm Precision", "Warm Expressive", "Concise Brief").forEach { style ->
                    JarvisChip(label = style, selected = uiState.emotionStyle == style, onClick = { viewModel.setEmotionStyle(style) })
                }
            }
            Spacer(Modifier.height(10.dp))
            JarvisText(text = "Quick Character Switch", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Spacer(Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MockData.roles.forEach { role ->
                    val selected = role.id == uiState.activeRole.id
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .clickable { viewModel.selectRole(role.id) }
                            .padding(4.dp)
                    ) {
                        val previewResId = (if (uiState.use3dCharacter) role.characterAssets.portrait3dResId else null)
                            ?: role.characterAssets.portraitResId
                        Image(
                            painter = painterResource(id = previewResId),
                            contentDescription = role.name,
                            contentScale = ContentScale.Crop,
                            alignment = Alignment.TopCenter,
                            modifier = Modifier
                                .size(48.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .border(if (selected) 2.dp else 1.dp, if (selected) role.accent else tokens.borderSubtle, RoundedCornerShape(14.dp))
                        )
                        Spacer(Modifier.height(4.dp))
                        JarvisText(
                            text = role.name.split(" ").first(),
                            style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp),
                            color = if (selected) role.accent else tokens.textSecondary
                        )
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            JarvisSecondaryButton(
                text = "Browse All 8 Character Cards",
                icon = Icons.Rounded.GridView,
                onClick = { viewModel.setRoleSheetVisible(true) },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 4. LOOK (Themes + BG Style + Text Size + Reduce Motion)
        SettingsGroupCard(
            id = "look",
            title = "Look & Appearance",
            subtitle = "${uiState.activeTheme.name} • Font ${(uiState.fontScaleMultiplier * 100).toInt()}%",
            statusLabel = if (uiState.activeTheme.isLight) "LIGHT" else "DARK",
            statusOk = true,
            icon = Icons.Rounded.Palette,
            expanded = expandedGroup == "look",
            onToggle = { expandedGroup = if (expandedGroup == "look") null else "look" }
        ) {
            JarvisPrimaryButton(
                text = "Open ${MockData.themes.size}-Theme Live Preview Sheet",
                icon = Icons.Rounded.ColorLens,
                onClick = { viewModel.setThemeSheetVisible(true) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            JarvisText(text = "Background Style", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BackgroundStyle.entries.forEach { bg ->
                    val currentBg = uiState.bgStyleOverride ?: uiState.activeTheme.backgroundStyle
                    JarvisChip(label = bg.label, selected = currentBg == bg, onClick = { viewModel.setBackgroundOverride(bg) })
                }
            }
            Spacer(Modifier.height(12.dp))
            JarvisText(text = "Cosmic Engine Intensity", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CosmicIntensity.entries.forEach { intensity ->
                    JarvisChip(
                        label = intensity.label,
                        selected = uiState.cosmicIntensity == intensity,
                        onClick = { viewModel.setCosmicIntensity(intensity) }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                JarvisText(text = "Glass Card Frost: ${(uiState.glassFrost * 100).toInt()}%", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                JarvisText(text = "45% – 100%", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            }
            Slider(
                value = uiState.glassFrost,
                onValueChange = { viewModel.setGlassFrost(it) },
                valueRange = 0.45f..1.0f,
                colors = SliderDefaults.colors(thumbColor = tokens.accent2, activeTrackColor = tokens.accent2)
            )
            JarvisSecondaryButton(
                text = "Open System Brain & Cosmic Engine",
                icon = Icons.Rounded.Hub,
                onClick = { viewModel.openSubScreen(SubScreen.COMMAND_CENTER) },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                JarvisText(text = "Text Size: ${(uiState.fontScaleMultiplier * 100).toInt()}%", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                JarvisText(text = "100% – 130%", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            }
            Slider(
                value = uiState.fontScaleMultiplier,
                onValueChange = { viewModel.setFontScale(it) },
                valueRange = 1.0f..1.3f,
                colors = SliderDefaults.colors(thumbColor = tokens.accent, activeTrackColor = tokens.accent)
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisText(text = "Reduce Motion (60fps static)", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                Switch(checked = uiState.reduceMotion, onCheckedChange = { viewModel.setReduceMotion(it) })
            }
        }

        // 5. AVATAR (Built-in + 4 custom upload slots with framing & remove-bg)
        SettingsGroupCard(
            id = "avatar",
            title = "Avatar & Custom Slots",
            subtitle = "${uiState.customAvatarSlots.count { it != null }} of 4 custom slots active",
            statusLabel = if (uiState.avatarRemoveBg) "BG CLEAN" else "RAW",
            statusOk = true,
            icon = Icons.Rounded.FaceRetouchingNatural,
            expanded = expandedGroup == "avatar",
            onToggle = { expandedGroup = if (expandedGroup == "avatar") null else "avatar" }
        ) {
            val activeRes = if (uiState.use3dCharacter && uiState.activeRole.characterAssets.portrait3dResId != null) {
                uiState.activeRole.characterAssets.portrait3dResId!!
            } else if (uiState.activeRole.id == RoleId.JARVIS && uiState.useCosmicJarvisPortrait) {
                uiState.activeRole.characterAssets.altPortraitResId ?: uiState.activeRole.characterAssets.portraitResId
            } else {
                uiState.activeRole.characterAssets.portraitResId
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(tokens.surfaceCardBottom)
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Image(
                    painter = painterResource(id = activeRes),
                    contentDescription = "${uiState.activeRole.name} active portrait",
                    contentScale = ContentScale.Crop,
                    alignment = Alignment.TopCenter,
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.5.dp, uiState.activeRole.accent, RoundedCornerShape(14.dp))
                )
                Column(modifier = Modifier.weight(1f)) {
                    JarvisText(text = "Built-in ${uiState.activeRole.name} Look", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                    JarvisText(text = uiState.activeRole.backgroundMood, style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                }
                if (uiState.activeRole.characterAssets.portrait3dResId != null) {
                    JarvisChip(
                        label = if (uiState.use3dCharacter) "3D CGI" else "2.5D",
                        selected = uiState.use3dCharacter,
                        onClick = { viewModel.toggle3dCharacter() }
                    )
                } else if (uiState.activeRole.characterAssets.altPortraitResId != null) {
                    JarvisChip(
                        label = if (uiState.useCosmicJarvisPortrait) "Cosmic" else "Hoodie",
                        selected = uiState.useCosmicJarvisPortrait,
                        onClick = { viewModel.toggleCosmicJarvisPortrait() }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                uiState.customAvatarSlots.forEachIndexed { idx, slotName ->
                    Surface(
                        onClick = { viewModel.toggleCustomAvatarSlot(idx) },
                        shape = RoundedCornerShape(16.dp),
                        color = if (slotName != null) tokens.accent.copy(alpha = 0.16f) else tokens.surfaceCardBottom,
                        border = BorderStroke(1.dp, if (slotName != null) tokens.accent else tokens.borderSubtle),
                        modifier = Modifier.weight(1f).height(76.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = if (slotName != null) Icons.Rounded.CheckCircle else Icons.Rounded.AddPhotoAlternate,
                                contentDescription = "Custom avatar slot ${idx + 1}",
                                tint = if (slotName != null) tokens.accent else tokens.textMuted,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.height(4.dp))
                            JarvisText(
                                text = slotName ?: "Slot ${idx + 1}",
                                style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp),
                                maxLines = 1
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisText(text = "Auto Remove Background & Center Framing", style = JarvisTypographyTokens.Body.copy(fontSize = 14.sp), modifier = Modifier.weight(1f))
                Switch(checked = uiState.avatarRemoveBg, onCheckedChange = { viewModel.toggleAvatarRemoveBg() })
            }
        }

        // 6. PHONE CONTROL
        SettingsGroupCard(
            id = "phone_control",
            title = "Phone Control Permissions",
            subtitle = "$grantedCount of ${uiState.permissions.size} enabled",
            statusLabel = if (grantedCount >= 6) "ON" else "PARTIAL",
            statusOk = grantedCount >= 6,
            icon = Icons.Rounded.PhonelinkSetup,
            expanded = expandedGroup == "phone_control",
            onToggle = { expandedGroup = if (expandedGroup == "phone_control") null else "phone_control" }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                uiState.permissions.forEach { p ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(tokens.surfaceCardBottom)
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            JarvisText(text = p.label, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                            JarvisText(text = p.why, style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                        }
                        Spacer(Modifier.width(8.dp))
                        JarvisChip(
                            label = if (p.granted) "ON" else "Fix",
                            selected = p.granted,
                            onClick = { viewModel.togglePermission(p.key) }
                        )
                    }
                }
            }
        }

        // 7. SCREEN-LOCK PATTERN (Interactive 3x3 pattern pad + pos/size/speed + Test unlock)
        SettingsGroupCard(
            id = "screen_lock",
            title = "Screen-Lock Pattern",
            subtitle = "${uiState.savedPattern.size}-node gesture • ${uiState.patternSpeedMs.toInt()}ms",
            statusLabel = if (uiState.savedPattern.size >= 4) "SET" else "SHORT",
            statusOk = uiState.savedPattern.size >= 4,
            icon = Icons.Rounded.Pattern,
            expanded = expandedGroup == "screen_lock",
            onToggle = { expandedGroup = if (expandedGroup == "screen_lock") null else "screen_lock" }
        ) {
            PatternPad3x3(
                selectedNodes = uiState.savedPattern,
                onNodeTap = { node ->
                    val list = uiState.savedPattern.toMutableList()
                    if (node in list) list.remove(node) else list.add(node)
                    viewModel.updatePattern(list)
                },
                onClear = { viewModel.updatePattern(emptyList()) }
            )
            Spacer(Modifier.height(10.dp))
            JarvisText(text = "Swipe Speed: ${uiState.patternSpeedMs.toInt()} ms • Pad Scale: ${String.format("%.1f", uiState.patternScale)}x", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Slider(
                value = uiState.patternSpeedMs,
                onValueChange = { viewModel.setPatternTuning(it, uiState.patternScale) },
                valueRange = 200f..800f,
                colors = SliderDefaults.colors(thumbColor = tokens.accent, activeTrackColor = tokens.accent)
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisPrimaryButton(
                    text = "Test Unlock Gesture",
                    icon = Icons.Rounded.LockOpen,
                    onClick = { viewModel.testUnlockPattern() },
                    modifier = Modifier.weight(1f)
                )
                JarvisSecondaryButton(
                    text = "Lock Screen",
                    icon = Icons.Rounded.Lock,
                    onClick = { viewModel.executeScreenLock() },
                    modifier = Modifier.weight(0.75f)
                )
            }
            uiState.patternTestResult?.let { res ->
                Spacer(Modifier.height(8.dp))
                JarvisGlassCard(cornerRadius = 14.dp, accentTint = if (uiState.savedPattern.size >= 4) tokens.success else tokens.error) {
                    JarvisText(text = res, style = JarvisTypographyTokens.Caption, color = tokens.textPrimary)
                    JarvisText(text = "Warning: Avoid >4 failed unlock tests to prevent Android 30s lockout.", style = JarvisTypographyTokens.Caption, color = tokens.warning)
                }
            }
        }

        // 8. NOTIFICATIONS
        SettingsGroupCard(
            id = "notifications",
            title = "Notifications & Message Reading",
            subtitle = if (uiState.notificationsEnabled) "Reads WhatsApp & Telegram aloud" else "Paused",
            statusLabel = if (uiState.notificationsEnabled) "ON" else "OFF",
            statusOk = uiState.notificationsEnabled,
            icon = Icons.Rounded.NotificationsActive,
            expanded = expandedGroup == "notifications",
            onToggle = { expandedGroup = if (expandedGroup == "notifications") null else "notifications" }
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisText(text = "Read Incoming Messages Aloud", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                Switch(checked = uiState.notificationsEnabled, onCheckedChange = { viewModel.toggleMasterNotifications() })
            }
            uiState.appNotificationToggles.forEach { (app, enabled) ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    JarvisText(text = app, style = JarvisTypographyTokens.Body)
                    Switch(checked = enabled && uiState.notificationsEnabled, onCheckedChange = { viewModel.toggleAppNotification(app) })
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisSecondaryButton(
                    text = "Open Shade",
                    icon = Icons.Rounded.Notifications,
                    onClick = { viewModel.openSystemNotificationShade() },
                    modifier = Modifier.weight(1f)
                )
                JarvisSecondaryButton(
                    text = "Clear Tray",
                    icon = Icons.Rounded.ClearAll,
                    onClick = { viewModel.clearAllSystemNotifications() },
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(8.dp))
            JarvisSecondaryButton(
                text = if (uiState.automation.notificationListenerEnabled) "Notification Access: Active ✓" else "Grant Notification Access",
                icon = Icons.Rounded.VerifiedUser,
                onClick = { viewModel.openAutomationSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 9. SAVED ACCOUNTS
        SettingsGroupCard(
            id = "accounts",
            title = "Saved Accounts",
            subtitle = "${uiState.savedAccounts.count { it.value }} of 4 linked",
            statusLabel = "LINKED",
            statusOk = true,
            icon = Icons.Rounded.SwitchAccount,
            expanded = expandedGroup == "accounts",
            onToggle = { expandedGroup = if (expandedGroup == "accounts") null else "accounts" }
        ) {
            uiState.savedAccounts.forEach { (platform, connected) ->
                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    JarvisText(text = platform, style = JarvisTypographyTokens.Body)
                    JarvisChip(
                        label = if (connected) "Connected" else "Connect",
                        selected = connected,
                        onClick = { viewModel.toggleSavedAccount(platform) }
                    )
                }
            }
        }

        // 10. MEMORY & PRIVACY
        SettingsGroupCard(
            id = "memory",
            title = "Memory & Privacy",
            subtitle = if (uiState.saveConversations) "Local memory active" else "Ephemeral session mode",
            statusLabel = if (uiState.voiceLockEnrolled) "VOICE LOCK" else "PRIVATE",
            statusOk = true,
            icon = Icons.Rounded.Shield,
            expanded = expandedGroup == "memory",
            onToggle = { expandedGroup = if (expandedGroup == "memory") null else "memory" }
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisText(text = "Save Conversation Locally", style = JarvisTypographyTokens.Body)
                Switch(checked = uiState.saveConversations, onCheckedChange = { viewModel.setSaveConversations(it) })
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisSecondaryButton(text = "Open Journal", icon = Icons.Rounded.Book, onClick = { viewModel.openSubScreen(SubScreen.JOURNAL_TIMELINE) }, modifier = Modifier.weight(1f))
                JarvisSecondaryButton(text = "Clear Chat", icon = Icons.Rounded.CleaningServices, onClick = { viewModel.clearConversation() }, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisSecondaryButton(
                    text = if (uiState.voiceLockEnrolled) "Voice Enrolled ✓" else "Enroll Voice Lock",
                    icon = Icons.Rounded.Fingerprint,
                    onClick = { viewModel.enrollVoiceLock() },
                    modifier = Modifier.weight(1f)
                )
                JarvisPrimaryButton(
                    text = "Erase Everything",
                    demoState = ComponentDemoState.ERROR,
                    onClick = { showEraseDialog = true },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 11. DIAGNOSTICS (Section 8 & 7.11)
        SettingsGroupCard(
            id = "diagnostics",
            title = "Diagnostics & Audio Route",
            subtitle = "${uiState.diagnostics.route.label} • ${uiState.diagnostics.connection}",
            statusLabel = if (uiState.diagnostics.echoSuspected) "ECHO RISK" else "HEALTHY",
            statusOk = !uiState.diagnostics.echoSuspected,
            icon = Icons.Rounded.Troubleshoot,
            expanded = expandedGroup == "diagnostics",
            onToggle = { expandedGroup = if (expandedGroup == "diagnostics") null else "diagnostics" }
        ) {
            JarvisText(text = "Model: ${uiState.diagnostics.modelName}", style = JarvisTypographyTokens.Mono, color = tokens.accent)
            Spacer(Modifier.height(4.dp))
            JarvisText(text = "Last Error: ${uiState.diagnostics.lastError}", style = JarvisTypographyTokens.Caption, color = tokens.textSecondary)
            Spacer(Modifier.height(10.dp))
            JarvisText(text = "Live Mic Level", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Spacer(Modifier.height(4.dp))
            JarvisLevelMeter(level = uiState.diagnostics.micLevel)
            Spacer(Modifier.height(12.dp))
            JarvisText(text = "Audio Route", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            Spacer(Modifier.height(6.dp))
            Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AudioRoute.entries.forEach { r ->
                    JarvisChip(label = r.label, selected = uiState.diagnostics.route == r, onClick = { viewModel.setAudioRoute(r) })
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    JarvisText(text = "Use Half-Duplex Mode", style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp))
                    JarvisText(text = "Pauses mic while speaking on phone speaker to prevent echo loops", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                }
                Switch(checked = uiState.diagnostics.halfDuplexMode, onCheckedChange = { viewModel.setHalfDuplexMode(it) })
            }
            if (uiState.diagnostics.echoSuspected) {
                Spacer(Modifier.height(8.dp))
                JarvisGlassCard(cornerRadius = 14.dp, accentTint = tokens.warning) {
                    JarvisText(text = "Echo suspected! Turn on Half-Duplex Mode or wear headphones.", style = JarvisTypographyTokens.Caption, color = tokens.warning)
                }
            }
            Spacer(Modifier.height(10.dp))
            JarvisText(text = "Reconnect Log", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            uiState.diagnostics.reconnectLog.forEach { log ->
                JarvisText(text = "• $log", style = JarvisTypographyTokens.Mono.copy(fontSize = 11.sp), color = tokens.textSecondary)
            }
            Spacer(Modifier.height(10.dp))
            JarvisSecondaryButton(
                text = "Copy Diagnostics Report",
                icon = Icons.Rounded.ContentCopy,
                onClick = {
                    val report = "Jarvis Diagnostics\nRoute: ${uiState.diagnostics.route}\nHalf-Duplex: ${uiState.diagnostics.halfDuplexMode}\nModel: ${uiState.diagnostics.modelName}"
                    clipboard.setText(AnnotatedString(report))
                    viewModel.showToast("Diagnostics report copied.")
                },
                modifier = Modifier.fillMaxWidth()
            )
        }

        // 12. ABOUT
        SettingsGroupCard(
            id = "about",
            title = "About Jarvis",
            subtitle = "v2.0 Cosmic • Galaxy A50s Mali-G72 Profile",
            statusLabel = "100% READY",
            statusOk = true,
            icon = Icons.Rounded.Info,
            expanded = expandedGroup == "about",
            onToggle = { expandedGroup = if (expandedGroup == "about") null else "about" }
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_jarvis_user_logo),
                    contentDescription = "Jarvis Arc Logo",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, tokens.accent2.copy(alpha = 0.6f), RoundedCornerShape(14.dp))
                )
                JarvisText(
                    text = "Jarvis OS is built for speed, deep phone integration, 3D holographic characters, and Mali-G72 60fps performance—supporting English, Hindi, and Hinglish.",
                    style = JarvisTypographyTokens.Body,
                    color = tokens.textSecondary,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisSecondaryButton(text = "Welcome Page", onClick = { viewModel.openWelcomeScreen() }, modifier = Modifier.weight(1f))
                JarvisSecondaryButton(text = "Loading Screen", onClick = { viewModel.triggerLoadingPreview() }, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisSecondaryButton(text = "Replay Onboarding", onClick = { viewModel.openOnboarding() }, modifier = Modifier.weight(1f))
                JarvisSecondaryButton(text = "Debug Panel", onClick = { viewModel.setDebugPanelVisible(true) }, modifier = Modifier.weight(1f))
            }
        }
    }
    }

    if (showEraseDialog) {
        AlertDialog(
            onDismissRequest = { showEraseDialog = false },
            title = { JarvisText(text = "Erase Everything?", style = JarvisTypographyTokens.Title.copy(fontSize = 19.sp)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    JarvisText(
                        text = "This permanently deletes all local chats, journal entries, and creations. Type ERASE to confirm.",
                        style = JarvisTypographyTokens.Body,
                        color = tokens.textSecondary
                    )
                    OutlinedTextField(
                        value = eraseConfirmText,
                        onValueChange = { eraseConfirmText = it },
                        placeholder = { JarvisText("Type ERASE", style = JarvisTypographyTokens.Caption) },
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                JarvisPrimaryButton(
                    text = "Erase",
                    demoState = ComponentDemoState.ERROR,
                    enabled = eraseConfirmText.trim().equals("ERASE", ignoreCase = true),
                    onClick = {
                        viewModel.eraseEverything()
                        eraseConfirmText = ""
                        showEraseDialog = false
                    }
                )
            },
            dismissButton = {
                JarvisTertiaryButton(text = "Cancel", onClick = { showEraseDialog = false })
            }
        )
    }
}

@Composable
private fun SettingsGroupCard(
    id: String,
    title: String,
    subtitle: String,
    statusLabel: String,
    statusOk: Boolean,
    icon: ImageVector,
    expanded: Boolean,
    onToggle: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    val tokens = LocalJarvisTokens.current
    JarvisGlassCard(elevationLevel = if (expanded) 2 else 1, cornerRadius = 22.dp) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onToggle),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(tokens.accent.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = tokens.accent, modifier = Modifier.size(22.dp))
            }
            Column(modifier = Modifier.weight(1f)) {
                JarvisText(text = title, style = JarvisTypographyTokens.Subtitle)
                JarvisText(text = subtitle, style = JarvisTypographyTokens.Caption, color = tokens.textMuted, maxLines = 1)
            }
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = if (statusOk) tokens.success.copy(alpha = 0.18f) else tokens.warning.copy(alpha = 0.20f)
            ) {
                JarvisText(
                    text = statusLabel,
                    style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                    color = if (statusOk) tokens.success else tokens.warning,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            Icon(
                imageVector = if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                contentDescription = if (expanded) "Collapse" else "Expand",
                tint = tokens.textMuted
            )
        }

        AnimatedVisibility(visible = expanded) {
            Column(modifier = Modifier.padding(top = 14.dp)) {
                HorizontalDivider(color = tokens.borderSubtle, thickness = 1.dp)
                Spacer(Modifier.height(14.dp))
                content()
            }
        }
    }
}

@Composable
private fun PatternPad3x3(
    selectedNodes: List<Int>,
    onNodeTap: (Int) -> Unit,
    onClear: () -> Unit
) {
    val tokens = LocalJarvisTokens.current
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .size(210.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(tokens.surfaceCardBottom)
                .border(1.dp, tokens.borderSubtle, RoundedCornerShape(20.dp))
                .padding(18.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (selectedNodes.size >= 2) {
                    val cellW = size.width / 3f
                    val cellH = size.height / 3f
                    for (i in 0 until selectedNodes.lastIndex) {
                        val a = selectedNodes[i]
                        val b = selectedNodes[i + 1]
                        val ax = (a % 3) * cellW + cellW / 2f
                        val ay = (a / 3) * cellH + cellH / 2f
                        val bx = (b % 3) * cellW + cellW / 2f
                        val by = (b / 3) * cellH + cellH / 2f
                        drawLine(
                            color = tokens.accent,
                            start = Offset(ax, ay),
                            end = Offset(bx, by),
                            strokeWidth = 4.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
            Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                for (r in 0..2) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        for (c in 0..2) {
                            val idx = r * 3 + c
                            val order = selectedNodes.indexOf(idx)
                            val active = order >= 0
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(if (active) tokens.accent else tokens.surfaceElevatedTop)
                                    .border(1.5.dp, if (active) tokens.accent2 else tokens.borderSubtle, CircleShape)
                                    .clickable { onNodeTap(idx) },
                                contentAlignment = Alignment.Center
                            ) {
                                JarvisText(
                                    text = if (active) "${order + 1}" else "${idx + 1}",
                                    style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                                    color = if (active) tokens.onAccent else tokens.textMuted
                                )
                            }
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        JarvisTertiaryButton(text = "Clear Pattern (${selectedNodes.size} nodes)", onClick = onClear)
    }
}
