package com.example.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import com.example.model.BackgroundStyle
import com.example.model.CosmicIntensity
import com.example.model.Role
import com.example.model.ThemeSpec

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

@Immutable
data class JarvisTokens(
    val themeId: String,
    val themeName: String,
    val isLight: Boolean,
    val bgTop: Color,
    val bgBottom: Color,
    val accent: Color,
    val accent2: Color,
    val onAccent: Color,
    val roleAccent: Color,
    val roleAccent2: Color,
    val backgroundStyle: BackgroundStyle,
    val surfaceCardTop: Color,
    val surfaceCardBottom: Color,
    val surfaceElevatedTop: Color,
    val surfaceElevatedBottom: Color,
    val borderTop: Color,
    val borderSubtle: Color,
    val shadowColor: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textMuted: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val info: Color,
    val reduceMotion: Boolean,
    val cosmicIntensity: CosmicIntensity = CosmicIntensity.BALANCED,
    val glassFrost: Float = 0.80f
)

val LocalJarvisTokens = staticCompositionLocalOf {
    buildJarvisTokens(
        theme = ThemeSpec(
            id = "iron_gold",
            name = "Iron Gold",
            bgTop = Color(0xFF000000),
            bgBottom = Color(0xFF1A1608),
            accent = Color(0xFFC9A227),
            accent2 = Color(0xFFE8C766),
            backgroundStyle = BackgroundStyle.AURORA_BLOBS,
            isLight = false
        ),
        role = null,
        bgOverride = null,
        reduceMotion = false
    )
}

fun buildJarvisTokens(
    theme: ThemeSpec,
    role: Role?,
    bgOverride: BackgroundStyle?,
    reduceMotion: Boolean,
    cosmicIntensity: CosmicIntensity = CosmicIntensity.BALANCED,
    glassFrost: Float = 0.80f
): JarvisTokens {
    val activeAccent = if (theme.followsRole && role != null) role.accent else theme.accent
    val activeAccent2 = if (theme.followsRole && role != null) role.accent2 else theme.accent2
    val activeBgTop = if (theme.followsRole && role != null) {
        blendColors(Color(0xFF05070E), role.accent, 0.08f)
    } else theme.bgTop
    val activeBgBottom = if (theme.followsRole && role != null) {
        blendColors(Color(0xFF0C101C), role.accent, 0.22f)
    } else theme.bgBottom

    val onAccent = if (activeAccent.luminance() > 0.44f) Color(0xFF0B0E14) else Color(0xFFFFFFFF)

    return if (theme.isLight) {
        JarvisTokens(
            themeId = theme.id,
            themeName = theme.name,
            isLight = true,
            bgTop = activeBgTop,
            bgBottom = activeBgBottom,
            accent = activeAccent,
            accent2 = activeAccent2,
            onAccent = onAccent,
            roleAccent = role?.accent ?: activeAccent,
            roleAccent2 = role?.accent2 ?: activeAccent2,
            backgroundStyle = bgOverride ?: theme.backgroundStyle,
            // Crisp white glass cards with soft colored shadows (zero grey washed-out overlays)
            surfaceCardTop = Color(0xFFFFFFFF).copy(alpha = 0.96f),
            surfaceCardBottom = Color(0xFFFAF8F5).copy(alpha = 0.92f),
            surfaceElevatedTop = Color(0xFFFFFFFF),
            surfaceElevatedBottom = Color(0xFFFDFBF8),
            borderTop = Color(0xFFFFFFFF),
            borderSubtle = activeAccent.copy(alpha = 0.18f),
            shadowColor = activeAccent.copy(alpha = 0.18f),
            textPrimary = Color(0xFF141722),
            textSecondary = Color(0xFF333B4F),
            textMuted = Color(0xFF535D75),
            success = Color(0xFF0B7A62),
            warning = Color(0xFF9C5400),
            error = Color(0xFFB71C3A),
            info = Color(0xFF1A58C8),
            reduceMotion = reduceMotion,
            cosmicIntensity = cosmicIntensity,
            glassFrost = glassFrost
        )
    } else {
        val tintedCardTop = blendColors(activeBgBottom, activeAccent, 0.12f)
        val tintedCardBottom = blendColors(activeBgTop, activeBgBottom, 0.55f)
        val topAlpha = glassFrost.coerceIn(0.45f, 0.96f)
        val botAlpha = (glassFrost - 0.08f).coerceIn(0.40f, 0.92f)
        JarvisTokens(
            themeId = theme.id,
            themeName = theme.name,
            isLight = false,
            bgTop = activeBgTop,
            bgBottom = activeBgBottom,
            accent = activeAccent,
            accent2 = activeAccent2,
            onAccent = onAccent,
            roleAccent = role?.accent ?: activeAccent,
            roleAccent2 = role?.accent2 ?: activeAccent2,
            backgroundStyle = bgOverride ?: theme.backgroundStyle,
            surfaceCardTop = tintedCardTop.copy(alpha = topAlpha),
            surfaceCardBottom = tintedCardBottom.copy(alpha = botAlpha),
            surfaceElevatedTop = blendColors(tintedCardTop, Color.White, 0.08f).copy(alpha = (topAlpha + 0.12f).coerceAtMost(0.98f)),
            surfaceElevatedBottom = tintedCardBottom.copy(alpha = (botAlpha + 0.12f).coerceAtMost(0.95f)),
            borderTop = Color.White.copy(alpha = 0.24f),
            borderSubtle = activeAccent.copy(alpha = 0.26f),
            shadowColor = Color.Black.copy(alpha = 0.55f),
            textPrimary = Color(0xFFF6F8FC),
            textSecondary = Color(0xFFD0D7E5),
            textMuted = Color(0xFF9AA4B8),
            success = Color(0xFF3DDBC0),
            warning = Color(0xFFFFB547),
            error = Color(0xFFFF647C),
            info = Color(0xFF63ADFF),
            reduceMotion = reduceMotion,
            cosmicIntensity = cosmicIntensity,
            glassFrost = glassFrost
        )
    }
}

fun blendColors(a: Color, b: Color, ratio: Float): Color {
    val t = ratio.coerceIn(0f, 1f)
    return Color(
        red = a.red + (b.red - a.red) * t,
        green = a.green + (b.green - a.green) * t,
        blue = a.blue + (b.blue - a.blue) * t,
        alpha = a.alpha + (b.alpha - a.alpha) * t
    )
}
