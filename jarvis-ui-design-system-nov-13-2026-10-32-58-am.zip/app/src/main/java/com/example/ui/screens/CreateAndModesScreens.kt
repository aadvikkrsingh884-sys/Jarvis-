package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MockData
import com.example.model.*
import com.example.ui.components.*
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.LocalJarvisTokens
import com.example.viewmodel.JarvisUiState
import com.example.viewmodel.JarvisViewModel
import kotlinx.coroutines.delay

@Composable
fun CreateHubScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    var activeType by remember { mutableStateOf<CreateProjectType?>(null) }
    var flowStage by remember { mutableIntStateOf(0) } // 0=form, 1=progress, 2=result
    var titleInput by remember { mutableStateOf("") }
    var detailsInput by remember { mutableStateOf("") }
    var styleChoice by remember { mutableStateOf("Modern Glass") }

    if (activeType != null) {
        BackHandler {
            activeType = null
            flowStage = 0
        }
    }

    LaunchedEffect(flowStage, activeType) {
        if (flowStage == 1 && activeType != null) {
            delay(1500L)
            viewModel.addCreatedArtifact(activeType!!, titleInput, styleChoice, detailsInput)
            flowStage = 2
        }
    }

    JarvisPullToRefreshBox(
        isRefreshing = uiState.isRefreshing,
        onRefresh = { viewModel.refreshPage("Create Hub") },
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(top = 12.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                JarvisText(text = "Create Hub", style = JarvisTypographyTokens.Title)
                JarvisText(text = "Build sites, PDFs, resumes & logs", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                JarvisChip(label = "Study", selected = false, icon = Icons.Rounded.School, onClick = { viewModel.openSubScreen(SubScreen.STUDY_MODE) })
                JarvisChip(label = "Journal", selected = false, icon = Icons.Rounded.Book, onClick = { viewModel.openSubScreen(SubScreen.JOURNAL_TIMELINE) })
            }
        }

        if (activeType == null) {
            // 6 Create Cards Grid
            val types = CreateProjectType.entries
            val icons = listOf(
                Icons.Rounded.Web,
                Icons.Rounded.Badge,
                Icons.Rounded.PersonPin,
                Icons.Rounded.MailOutline,
                Icons.Rounded.Summarize,
                Icons.Rounded.EditNote
            )
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                for (row in 0..2) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        for (col in 0..1) {
                            val idx = row * 2 + col
                            val t = types[idx]
                            JarvisGlassCard(
                                elevationLevel = 2,
                                cornerRadius = 22.dp,
                                onClick = {
                                    activeType = t
                                    flowStage = 0
                                    titleInput = ""
                                    detailsInput = ""
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(tokens.accent.copy(alpha = 0.16f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(icons[idx], contentDescription = t.title, tint = tokens.accent, modifier = Modifier.size(22.dp))
                                }
                                Spacer(Modifier.height(12.dp))
                                JarvisText(text = t.title, style = JarvisTypographyTokens.Subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                JarvisText(text = t.subtitle, style = JarvisTypographyTokens.Caption, color = tokens.textSecondary, maxLines = 2)
                            }
                        }
                    }
                }
            }

            // Recent Creations Horizontal Gallery
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                JarvisText(text = "Recent Creations", style = JarvisTypographyTokens.Subtitle)
                Box(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(end = 28.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        uiState.createdArtifacts.forEach { item ->
                            JarvisGlassCard(
                                elevationLevel = 1,
                                cornerRadius = 20.dp,
                                modifier = Modifier.width(230.dp),
                                onClick = { viewModel.showToast("Opened ${item.title}") }
                            ) {
                                Surface(shape = RoundedCornerShape(999.dp), color = tokens.accent.copy(alpha = 0.16f)) {
                                    JarvisText(
                                        text = item.type.title,
                                        style = JarvisTypographyTokens.Caption,
                                        color = tokens.accent,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                                Spacer(Modifier.height(8.dp))
                                JarvisText(text = item.title, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 15.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Spacer(Modifier.height(4.dp))
                                JarvisText(text = item.previewSummary, style = JarvisTypographyTokens.Caption, color = tokens.textSecondary, maxLines = 2)
                                Spacer(Modifier.height(8.dp))
                                JarvisText(text = "${item.style} • ${item.createdAt}", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                            }
                        }
                    }
                    ScrollFadeEdge(modifier = Modifier.align(Alignment.CenterEnd).height(140.dp))
                }
            }
        } else {
            // Interactive Form -> Live Progress -> Result Screen
            val type = activeType!!
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                JarvisIconButton(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back to Create Hub",
                    onClick = { activeType = null; flowStage = 0 }
                )
                JarvisText(text = type.title, style = JarvisTypographyTokens.Title)
            }

            when (flowStage) {
                0 -> {
                    JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp) {
                        JarvisText(text = "Project Details", style = JarvisTypographyTokens.Subtitle)
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = titleInput,
                            onValueChange = { titleInput = it },
                            label = { JarvisText("Title", style = JarvisTypographyTokens.Caption) },
                            placeholder = { JarvisText("e.g., Aadvik Portfolio / Leave Letter", style = JarvisTypographyTokens.Body, color = tokens.textMuted) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(
                            value = detailsInput,
                            onValueChange = { detailsInput = it },
                            label = { JarvisText("Key details", style = JarvisTypographyTokens.Caption) },
                            placeholder = { JarvisText("Sections, tone, or highlights to include...", style = JarvisTypographyTokens.Body, color = tokens.textMuted) },
                            minLines = 3,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(14.dp))
                        JarvisText(text = "Style Option", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Modern Glass", "Clean Minimal", "Academic Serif", "Executive Dark").forEach { s ->
                                JarvisChip(label = s, selected = styleChoice == s, onClick = { styleChoice = s })
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        JarvisPrimaryButton(
                            text = "Generate ${type.title}",
                            icon = Icons.Rounded.AutoAwesome,
                            onClick = { flowStage = 1 },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
                1 -> {
                    JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            CircularProgressIndicator(color = tokens.accent, modifier = Modifier.size(28.dp))
                            JarvisText(text = "Crafting your ${type.title}...", style = JarvisTypographyTokens.Subtitle)
                        }
                        Spacer(Modifier.height(16.dp))
                        listOf("Structuring outline & sections", "Applying $styleChoice typography", "Checking 4.5:1 readability & export").forEachIndexed { idx, step ->
                            Row(
                                modifier = Modifier.padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = if (idx < 2) Icons.Rounded.CheckCircle else Icons.Rounded.Autorenew,
                                    contentDescription = null,
                                    tint = if (idx < 2) tokens.success else tokens.accent,
                                    modifier = Modifier.size(18.dp)
                                )
                                JarvisText(text = step, style = JarvisTypographyTokens.Body)
                            }
                        }
                    }
                }
                else -> {
                    JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp, accentTint = tokens.accent) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            JarvisText(text = titleInput.ifBlank { type.title }, style = JarvisTypographyTokens.Subtitle)
                            Surface(shape = RoundedCornerShape(999.dp), color = tokens.success.copy(alpha = 0.2f)) {
                                JarvisText(text = "Ready", style = JarvisTypographyTokens.Caption, color = tokens.success, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp))
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(16.dp))
                                .background(tokens.surfaceCardBottom)
                                .border(1.dp, tokens.borderSubtle, RoundedCornerShape(16.dp))
                                .padding(14.dp)
                        ) {
                            JarvisText(
                                text = detailsInput.ifBlank { "Formatted in $styleChoice with clean margins, executive spacing, and ready-to-share layout." },
                                style = JarvisTypographyTokens.Body,
                                color = tokens.textSecondary
                            )
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            JarvisSecondaryButton(text = "Save", icon = Icons.Rounded.Save, onClick = { viewModel.showToast("Saved to Downloads/Jarvis") }, modifier = Modifier.weight(1f))
                            JarvisSecondaryButton(text = "Share", icon = Icons.Rounded.Share, onClick = { viewModel.showToast("Share sheet ready") }, modifier = Modifier.weight(1f))
                        }
                        Spacer(Modifier.height(8.dp))
                        JarvisPrimaryButton(
                            text = "Edit with Jarvis",
                            icon = Icons.Rounded.Chat,
                            onClick = {
                                activeType = null
                                flowStage = 0
                                viewModel.selectTab(MainTab.CHAT)
                            },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
    }
}

@Composable
fun JournalTimelineScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    BackHandler { viewModel.closeSubScreen() }

    JarvisPullToRefreshBox(
        isRefreshing = uiState.isRefreshing,
        onRefresh = { viewModel.refreshPage("Journal Timeline") },
        modifier = Modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .statusBarsPadding()
                .padding(horizontal = 20.dp)
                .padding(top = 12.dp, bottom = 112.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            JarvisIconButton(icon = Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", onClick = { viewModel.closeSubScreen() })
            Column {
                JarvisText(text = "Journal Timeline", style = JarvisTypographyTokens.Title)
                JarvisText(text = "${uiState.journalEntries.size} entries saved locally", style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            }
        }

        if (uiState.journalEntries.isEmpty()) {
            JarvisGlassCard(elevationLevel = 1, cornerRadius = 24.dp) {
                JarvisText(text = "No journal entries yet", style = JarvisTypographyTokens.Subtitle)
                Spacer(Modifier.height(6.dp))
                JarvisText(text = "Save any chat message or create a new journal entry in Create Hub.", style = JarvisTypographyTokens.Body, color = tokens.textSecondary)
            }
        } else {
            uiState.journalEntries.forEach { entry ->
                val role = MockData.roles.firstOrNull { it.id == entry.roleId } ?: uiState.activeRole
                JarvisGlassCard(elevationLevel = 1, cornerRadius = 22.dp, accentTint = role.accent) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        JarvisText(text = entry.dateLabel, style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
                        Surface(shape = RoundedCornerShape(999.dp), color = role.accent.copy(alpha = 0.2f)) {
                            JarvisText(text = entry.mood, style = JarvisTypographyTokens.Caption, color = role.accent, modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp))
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    JarvisText(text = entry.title, style = JarvisTypographyTokens.Subtitle)
                    Spacer(Modifier.height(4.dp))
                    JarvisText(text = entry.body, style = JarvisTypographyTokens.Body, color = tokens.textSecondary)
                }
            }
        }
    }
    }
}

@Composable
fun StudyModeScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    BackHandler { viewModel.closeSubScreen() }

    val totalSec = 25 * 60
    val mins = uiState.studySecondsLeft / 60
    val secs = uiState.studySecondsLeft % 60
    val progress = 1f - (uiState.studySecondsLeft.toFloat() / totalSec.toFloat())
    val quiz = MockData.studyQuizzes[uiState.quizIndex]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                JarvisIconButton(icon = Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", onClick = { viewModel.closeSubScreen() })
                JarvisText(text = "Study Focus", style = JarvisTypographyTokens.Title)
            }
            Surface(shape = RoundedCornerShape(999.dp), color = tokens.warning.copy(alpha = 0.18f)) {
                Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Icon(Icons.Rounded.LocalFireDepartment, contentDescription = "Streak", tint = tokens.warning, modifier = Modifier.size(16.dp))
                    JarvisText(text = "${uiState.studyStreakDays}-day streak", style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold), color = tokens.warning)
                }
            }
        }

        // 25-minute Focus Timer Ring
        JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp) {
            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                JarvisProgressRing(
                    progress = progress,
                    size = 148.dp,
                    strokeWidth = 10.dp,
                    centerLabel = "%02d:%02d".format(mins, secs)
                )
                Spacer(Modifier.height(16.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    JarvisPrimaryButton(
                        text = if (uiState.studyRunning) "Pause Focus" else "Start 25m",
                        icon = if (uiState.studyRunning) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        onClick = { viewModel.toggleStudyTimer() },
                        modifier = Modifier.weight(1f)
                    )
                    JarvisSecondaryButton(
                        text = "Reset",
                        icon = Icons.Rounded.Refresh,
                        onClick = { viewModel.resetStudyTimer() }
                    )
                }
            }
        }

        // Interactive Quiz Card
        JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                JarvisText(text = "Quick Recall • ${quiz.subject}", style = JarvisTypographyTokens.Caption, color = tokens.accent)
                JarvisTertiaryButton(text = "Next card", onClick = { viewModel.nextQuizCard() })
            }
            Spacer(Modifier.height(6.dp))
            JarvisText(text = quiz.question, style = JarvisTypographyTokens.Subtitle)
            Spacer(Modifier.height(12.dp))
            quiz.options.forEachIndexed { idx, opt ->
                val selected = uiState.quizSelectedOption == idx
                val isCorrect = idx == quiz.correctIndex
                val border = when {
                    uiState.quizSelectedOption == null -> tokens.borderSubtle
                    selected && isCorrect -> tokens.success
                    selected && !isCorrect -> tokens.error
                    isCorrect -> tokens.success.copy(alpha = 0.6f)
                    else -> tokens.borderSubtle
                }
                Surface(
                    onClick = { viewModel.selectQuizAnswer(idx) },
                    shape = RoundedCornerShape(14.dp),
                    color = if (selected) border.copy(alpha = 0.18f) else tokens.surfaceCardBottom,
                    border = BorderStroke(1.dp, border),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                    JarvisText(text = opt, style = JarvisTypographyTokens.Body, modifier = Modifier.padding(12.dp))
                }
            }
        }
    }
}

@Composable
fun MusicModeScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    BackHandler { viewModel.closeSubScreen() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
            .padding(top = 12.dp, bottom = 112.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            JarvisIconButton(icon = Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "Back", onClick = { viewModel.closeSubScreen() })
            JarvisText(text = "Music Mode", style = JarvisTypographyTokens.Title)
        }

        JarvisGlassCard(elevationLevel = 2, cornerRadius = 28.dp, accentTint = tokens.accent) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(RoundedCornerShape(18.dp))
                        .background(tokens.accent.copy(alpha = 0.22f))
                        .border(1.dp, tokens.accent, RoundedCornerShape(18.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Rounded.Album, contentDescription = "Album art", tint = tokens.accent, modifier = Modifier.size(38.dp))
                }
                Column(modifier = Modifier.weight(1f)) {
                    JarvisText(text = uiState.music.title, style = JarvisTypographyTokens.Title.copy(fontSize = 19.sp))
                    JarvisText(text = uiState.music.artist, style = JarvisTypographyTokens.Body, color = tokens.textSecondary)
                }
            }
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                progress = { uiState.music.progress },
                modifier = Modifier.fillMaxWidth().height(5.dp).clip(RoundedCornerShape(999.dp)),
                color = tokens.accent,
                trackColor = tokens.borderSubtle
            )
            Spacer(Modifier.height(16.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                JarvisIconButton(icon = Icons.Rounded.SkipPrevious, contentDescription = "Previous track", onClick = { viewModel.selectTrack(uiState.music.queue.last()) })
                JarvisIconButton(
                    icon = if (uiState.music.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                    contentDescription = if (uiState.music.isPlaying) "Pause" else "Play",
                    containerColor = tokens.accent,
                    tint = tokens.onAccent,
                    onClick = { viewModel.toggleMusicPlay() }
                )
                JarvisIconButton(icon = Icons.Rounded.SkipNext, contentDescription = "Next track", onClick = { viewModel.selectTrack(uiState.music.queue[1]) })
            }
        }

        JarvisText(text = "Up Next Queue", style = JarvisTypographyTokens.Subtitle)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            uiState.music.queue.forEach { track ->
                JarvisChip(
                    label = track,
                    selected = track == uiState.music.title,
                    icon = Icons.Rounded.MusicNote,
                    onClick = { viewModel.selectTrack(track) }
                )
            }
        }
    }
}
