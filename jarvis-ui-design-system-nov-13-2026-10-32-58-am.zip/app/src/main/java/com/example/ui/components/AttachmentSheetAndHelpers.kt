package com.example.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AttachmentKind
import com.example.model.ChatAttachment
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.LocalJarvisTokens

data class AttachmentLaunchers(
    val openSheet: () -> Unit
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun rememberAttachmentController(
    onAddAttachment: (ChatAttachment) -> Unit,
    onOpenCameraVision: () -> Unit
): AttachmentLaunchers {
    val context = LocalContext.current
    var showSheet by remember { mutableStateOf(false) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                val (name, size) = queryFileMeta(context, uri, fallbackName = "Gallery_Photo.jpg")
                val bmp = decodeScaledBitmap(context, uri)
                onAddAttachment(
                    ChatAttachment(
                        id = "att_${System.currentTimeMillis()}",
                        kind = AttachmentKind.PHOTO,
                        label = name,
                        detail = size,
                        previewBitmap = bmp
                    )
                )
            }
            showSheet = false
        }
    )

    val cameraPreviewLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview(),
        onResult = { bitmap ->
            if (bitmap != null) {
                val scaled = scaleBitmap(bitmap, 480)
                onAddAttachment(
                    ChatAttachment(
                        id = "cam_${System.currentTimeMillis()}",
                        kind = AttachmentKind.CAMERA,
                        label = "Camera_Snap.jpg",
                        detail = "${bitmap.width}×${bitmap.height}",
                        previewBitmap = scaled.asImageBitmap()
                    )
                )
            }
            showSheet = false
        }
    )

    val filePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument(),
        onResult = { uri ->
            if (uri != null) {
                val (name, size) = queryFileMeta(context, uri, fallbackName = "Document.pdf")
                val mime = context.contentResolver.getType(uri).orEmpty()
                val bmp = if (mime.startsWith("image/")) decodeScaledBitmap(context, uri) else null
                onAddAttachment(
                    ChatAttachment(
                        id = "file_${System.currentTimeMillis()}",
                        kind = if (bmp != null) AttachmentKind.PHOTO else AttachmentKind.FILE,
                        label = name,
                        detail = size,
                        previewBitmap = bmp
                    )
                )
            }
            showSheet = false
        }
    )

    if (showSheet) {
        val tokens = LocalJarvisTokens.current
        ModalBottomSheet(
            onDismissRequest = { showSheet = false },
            containerColor = tokens.surfaceElevatedTop,
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp)
                    .padding(bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                JarvisText(text = "Attach Context to Jarvis", style = JarvisTypographyTokens.Title.copy(fontSize = 19.sp))
                JarvisText(
                    text = "Zero-permission Photo Picker, Camera snap, Files/PDFs & Live Vision",
                    style = JarvisTypographyTokens.Caption,
                    color = tokens.textMuted
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AttachOptionTile(
                        title = "Camera Snap",
                        subtitle = "Take photo",
                        icon = Icons.Rounded.PhotoCamera,
                        tint = tokens.accent2,
                        onClick = { cameraPreviewLauncher.launch(null) },
                        modifier = Modifier.weight(1f)
                    )
                    AttachOptionTile(
                        title = "Photo Picker",
                        subtitle = "Gallery",
                        icon = Icons.Rounded.PhotoLibrary,
                        tint = tokens.accent,
                        onClick = {
                            photoPickerLauncher.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )
                    AttachOptionTile(
                        title = "File / PDF",
                        subtitle = "Any doc",
                        icon = Icons.Rounded.AttachFile,
                        tint = tokens.info,
                        onClick = { filePickerLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AttachOptionTile(
                        title = "Live Vision",
                        subtitle = "Rear lens",
                        icon = Icons.Rounded.Visibility,
                        tint = tokens.success,
                        onClick = {
                            showSheet = false
                            onOpenCameraVision()
                        },
                        modifier = Modifier.weight(1f)
                    )
                    AttachOptionTile(
                        title = "Screen OCR",
                        subtitle = "Scan UI",
                        icon = Icons.Rounded.Screenshot,
                        tint = tokens.warning,
                        onClick = {
                            onAddAttachment(
                                ChatAttachment(
                                    id = "scr_${System.currentTimeMillis()}",
                                    kind = AttachmentKind.SCREENSHOT,
                                    label = "Current_Screen_OCR.png",
                                    detail = "1080×2340"
                                )
                            )
                            showSheet = false
                        },
                        modifier = Modifier.weight(1f)
                    )
                    AttachOptionTile(
                        title = "Voice Clip",
                        subtitle = "0:08 note",
                        icon = Icons.Rounded.GraphicEq,
                        tint = tokens.accent2,
                        onClick = {
                            onAddAttachment(
                                ChatAttachment(
                                    id = "aud_${System.currentTimeMillis()}",
                                    kind = AttachmentKind.VOICE_NOTE,
                                    label = "Voice_Memo_08s.m4a",
                                    detail = "128 KB"
                                )
                            )
                            showSheet = false
                        },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }

    return AttachmentLaunchers(openSheet = { showSheet = true })
}

@Composable
private fun AttachOptionTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(18.dp),
        color = tokens.surfaceCardBottom,
        border = BorderStroke(1.dp, tint.copy(alpha = 0.40f)),
        modifier = modifier.height(92.dp)
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.16f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = title, tint = tint, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.height(6.dp))
            JarvisText(text = title, style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold), color = tokens.textPrimary, maxLines = 1)
            JarvisText(text = subtitle, style = JarvisTypographyTokens.Caption.copy(fontSize = 10.sp), color = tokens.textMuted, maxLines = 1)
        }
    }
}

@Composable
fun PendingAttachmentsStrip(
    attachments: List<ChatAttachment>,
    onRemove: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    if (attachments.isEmpty()) return
    val tokens = LocalJarvisTokens.current
    Row(
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        attachments.forEach { item ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = tokens.surfaceElevatedTop,
                border = BorderStroke(1.dp, tokens.accent.copy(alpha = 0.55f))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (item.previewBitmap != null) {
                        Image(
                            bitmap = item.previewBitmap,
                            contentDescription = item.label,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.size(34.dp).clip(RoundedCornerShape(8.dp))
                        )
                    } else {
                        Box(
                            modifier = Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(tokens.accent.copy(alpha = 0.16f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (item.kind) {
                                    AttachmentKind.CAMERA -> Icons.Rounded.PhotoCamera
                                    AttachmentKind.PHOTO -> Icons.Rounded.Photo
                                    AttachmentKind.FILE -> Icons.Rounded.Description
                                    AttachmentKind.VOICE_NOTE -> Icons.Rounded.GraphicEq
                                    AttachmentKind.SCREENSHOT -> Icons.Rounded.Screenshot
                                },
                                contentDescription = item.kind.label,
                                tint = tokens.accent2,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Column(modifier = Modifier.widthIn(max = 120.dp)) {
                        JarvisText(text = item.label, style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        JarvisText(text = "${item.kind.label} • ${item.detail}", style = JarvisTypographyTokens.Caption.copy(fontSize = 10.sp), color = tokens.textMuted, maxLines = 1)
                    }
                    Icon(
                        imageVector = Icons.Rounded.Close,
                        contentDescription = "Remove ${item.label}",
                        tint = tokens.textMuted,
                        modifier = Modifier
                            .size(18.dp)
                            .clip(CircleShape)
                            .clickable { onRemove(item.id) }
                    )
                }
            }
        }
    }
}

private fun queryFileMeta(context: Context, uri: Uri, fallbackName: String): Pair<String, String> {
    var name = fallbackName
    var sizeLabel = "Ready"
    runCatching {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
                if (nameIdx >= 0) name = cursor.getString(nameIdx) ?: fallbackName
                if (sizeIdx >= 0) {
                    val bytes = cursor.getLong(sizeIdx)
                    sizeLabel = when {
                        bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes / (1024f * 1024f))
                        bytes >= 1024 -> "${bytes / 1024} KB"
                        bytes > 0 -> "$bytes B"
                        else -> "Ready"
                    }
                }
            }
        }
    }
    return name to sizeLabel
}

private fun decodeScaledBitmap(context: Context, uri: Uri): ImageBitmap? {
    return runCatching {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val raw = BitmapFactory.decodeStream(stream) ?: return@use null
            scaleBitmap(raw, 480).asImageBitmap()
        }
    }.getOrNull()
}

private fun scaleBitmap(bmp: Bitmap, maxDim: Int): Bitmap {
    val w = bmp.width
    val h = bmp.height
    if (w <= maxDim && h <= maxDim) return bmp
    val ratio = maxDim.toFloat() / maxOf(w, h)
    return Bitmap.createScaledBitmap(bmp, (w * ratio).toInt().coerceAtLeast(1), (h * ratio).toInt().coerceAtLeast(1), true)
}
