package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshState
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalJarvisTokens

/**
 * Material 3 PullToRefreshBox styled with a J.A.R.V.I.S. holographic Arc-Reactor
 * spinning emblem indicator tuned for 60fps Mali-G72 performance.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JarvisPullToRefreshBox(
    isRefreshing: Boolean,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) {
    val state: PullToRefreshState = rememberPullToRefreshState()
    val tokens = LocalJarvisTokens.current

    PullToRefreshBox(
        isRefreshing = isRefreshing,
        onRefresh = onRefresh,
        state = state,
        modifier = modifier,
        indicator = {
            val fraction = state.distanceFraction.coerceIn(0f, 1.4f)
            if (isRefreshing || fraction > 0.05f) {
                val spin = rememberInfiniteTransition(label = "ptr_spin")
                val activeSpin = if (isRefreshing && !tokens.reduceMotion) {
                    spin.animateFloat(
                        initialValue = 0f,
                        targetValue = 360f,
                        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
                        label = "ptr_rot"
                    ).value
                } else {
                    fraction * 270f
                }

                Box(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .statusBarsPadding()
                        .padding(top = 12.dp)
                        .graphicsLayer {
                            val showFrac = if (isRefreshing) 1f else fraction.coerceIn(0f, 1f)
                            alpha = showFrac
                            scaleX = 0.72f + (0.28f * showFrac)
                            scaleY = 0.72f + (0.28f * showFrac)
                            translationY = if (isRefreshing) 10f else (fraction * 36f - 18f)
                        }
                ) {
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = Color(0xFF06131A).copy(alpha = 0.94f),
                        border = BorderStroke(1.2.dp, Color(0xFF00E5FF).copy(alpha = 0.8f)),
                        shadowElevation = 12.dp
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(modifier = Modifier.size(30.dp), contentAlignment = Alignment.Center) {
                                Canvas(modifier = Modifier.fillMaxSize()) {
                                    rotate(activeSpin) {
                                        drawArc(
                                            color = Color(0xFF00E5FF),
                                            startAngle = 0f,
                                            sweepAngle = 220f,
                                            useCenter = false,
                                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                                        )
                                    }
                                }
                                Image(
                                    painter = painterResource(id = R.drawable.img_jarvis_user_logo),
                                    contentDescription = "Refreshing J.A.R.V.I.S.",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .graphicsLayer { rotationZ = if (isRefreshing) -activeSpin * 0.4f else activeSpin * 0.3f }
                                )
                            }
                            JarvisText(
                                text = when {
                                    isRefreshing -> "J.A.R.V.I.S. SYNCING..."
                                    fraction >= 1f -> "RELEASE TO REFRESH"
                                    else -> "PULL TO REFRESH"
                                },
                                style = JarvisTypographyTokens.Caption.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                ),
                                color = Color(0xFF8EF5FF)
                            )
                        }
                    }
                }
            }
        },
        content = content
    )
}

/**
 * Reusable Fullscreen J.A.R.V.I.S. Loading Overlay showcasing the user's HUD logo
 * during manual syncs or preview mode.
 */
@Composable
fun JarvisLoadingOverlay(
    statusText: String,
    onDismiss: () -> Unit
) {
    val tokens = LocalJarvisTokens.current
    val transition = rememberInfiniteTransition(label = "overlay_load")
    val rot = if (tokens.reduceMotion) 0f else transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing)),
        label = "ol_rot"
    ).value
    val pulse = if (tokens.reduceMotion) 1f else transition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(1100), RepeatMode.Reverse),
        label = "ol_pulse"
    ).value

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03080B))
            .clickable(onClick = onDismiss),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_jarvis_user_hud_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.32f)
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        listOf(
                            Color(0x3300E5FF),
                            Color(0xDD03080B),
                            Color(0xF803080B)
                        )
                    )
                )
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.padding(32.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(210.dp)
                    .graphicsLayer {
                        scaleX = pulse
                        scaleY = pulse
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    rotate(rot) {
                        drawArc(
                            color = Color(0xFF00E5FF),
                            startAngle = 0f,
                            sweepAngle = 110f,
                            useCenter = false,
                            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = Color(0xFF8B5CF6),
                            startAngle = 180f,
                            sweepAngle = 95f,
                            useCenter = false,
                            style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                    rotate(-rot * 0.7f) {
                        drawArc(
                            color = Color(0xFFFFC107).copy(alpha = 0.85f),
                            startAngle = 60f,
                            sweepAngle = 70f,
                            useCenter = false,
                            topLeft = androidx.compose.ui.geometry.Offset(14.dp.toPx(), 14.dp.toPx()),
                            size = androidx.compose.ui.geometry.Size(size.width - 28.dp.toPx(), size.height - 28.dp.toPx()),
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
                Image(
                    painter = painterResource(id = R.drawable.img_jarvis_user_logo),
                    contentDescription = "J.A.R.V.I.S. Arc Core",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .size(164.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, Color(0xFF00E5FF).copy(alpha = 0.75f), CircleShape)
                )
            }

            JarvisText(
                text = statusText,
                style = JarvisTypographyTokens.Caption.copy(
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.4.sp
                ),
                color = Color(0xFF00E5FF)
            )
            LinearProgressIndicator(
                modifier = Modifier
                    .width(210.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(999.dp)),
                color = Color(0xFF00E5FF),
                trackColor = Color.White.copy(alpha = 0.14f)
            )
            JarvisText(
                text = "Tap anywhere to continue",
                style = JarvisTypographyTokens.Caption,
                color = Color(0xFF9AA4B8)
            )
        }
    }
}
