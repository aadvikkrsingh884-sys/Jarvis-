package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalJarvisTokens

@Composable
fun WeatherWidgetCard(
    data: WeatherWidgetData,
    activeRole: Role,
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    val isHudStyle = activeRole.id == RoleId.JARVIS || tokens.themeId == "cyber_tech" || tokens.themeId == "matrix"
    val isEditorial = activeRole.id == RoleId.MENTOR || activeRole.id == RoleId.LISTENER

    WidgetStateShell(
        title = if (isHudStyle) "ATMOSPHERE" else "Weather",
        icon = Icons.Rounded.WbSunny,
        state = data.state,
        onRetry = onRefresh,
        accentTint = if (isEditorial) activeRole.accent else null,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                JarvisText(
                    text = "${data.tempC}°C",
                    style = JarvisTypographyTokens.Title.copy(
                        fontFamily = if (isHudStyle) JetBrainsMonoFontFamily else JarvisTypographyTokens.Title.fontFamily
                    ),
                    color = tokens.textPrimary
                )
                JarvisText(
                    text = "${data.condition} • ${data.city}",
                    style = JarvisTypographyTokens.Caption,
                    color = tokens.textSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(if (isHudStyle) 10.dp else 999.dp))
                    .background(tokens.accent.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Rounded.NightsStay, contentDescription = "Sky condition", tint = tokens.accent, modifier = Modifier.size(22.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            JarvisText(
                text = "H:${data.highC}° L:${data.lowC}°",
                style = JarvisTypographyTokens.Caption.copy(
                    fontFamily = if (isHudStyle) JetBrainsMonoFontFamily else JarvisTypographyTokens.Caption.fontFamily
                ),
                color = tokens.textMuted
            )
            JarvisText(
                text = "Rain ${data.rainChancePct}%",
                style = JarvisTypographyTokens.Caption,
                color = tokens.accent2
            )
        }
    }
}

@Composable
fun TodayWidgetCard(
    data: TodayWidgetData,
    onTap: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    WidgetStateShell(
        title = "Today",
        icon = Icons.Rounded.CalendarToday,
        state = data.state,
        onRetry = onTap,
        modifier = modifier
    ) {
        JarvisText(
            text = data.dateLabel,
            style = JarvisTypographyTokens.Subtitle,
            color = tokens.textPrimary
        )
        Spacer(Modifier.height(4.dp))
        JarvisText(
            text = data.nextEvent,
            style = JarvisTypographyTokens.Caption,
            color = tokens.textSecondary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Icon(Icons.Rounded.Alarm, contentDescription = null, tint = tokens.accent, modifier = Modifier.size(14.dp))
            JarvisText(text = data.nextAlarm, style = JarvisTypographyTokens.Caption, color = tokens.accent)
        }
    }
}

@Composable
fun MoodWidgetCard(
    data: MoodWidgetData,
    onSwitchSuggestedRole: (RoleId) -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    WidgetStateShell(
        title = "Mood Read",
        icon = Icons.Rounded.Psychology,
        state = data.state,
        onRetry = { onSwitchSuggestedRole(data.suggestedRoleId) },
        modifier = modifier
    ) {
        JarvisText(
            text = data.label,
            style = JarvisTypographyTokens.Subtitle,
            color = tokens.accent
        )
        Spacer(Modifier.height(4.dp))
        JarvisText(
            text = data.summary,
            style = JarvisTypographyTokens.Caption,
            color = tokens.textSecondary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun BatteryWidgetCard(
    data: BatteryWidgetData,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    WidgetStateShell(
        title = "Battery",
        icon = Icons.Rounded.BatteryChargingFull,
        state = data.state,
        onRetry = {},
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            JarvisProgressRing(
                progress = data.percent / 100f,
                size = 44.dp,
                strokeWidth = 5.dp,
                color = if (data.percent <= 20) tokens.error else tokens.success,
                centerLabel = "${data.percent}%"
            )
            Column {
                JarvisText(
                    text = if (data.isCharging) "Charging" else "On Battery",
                    style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp),
                    color = tokens.textPrimary
                )
                JarvisText(
                    text = data.estimatedTime,
                    style = JarvisTypographyTokens.Caption,
                    color = tokens.textMuted
                )
            }
        }
    }
}

@Composable
fun RemindersWidgetCard(
    data: ReminderWidgetData,
    onToggleReminder: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    WidgetStateShell(
        title = "Reminders",
        icon = Icons.Rounded.Checklist,
        state = if (data.items.isEmpty() && data.state == WidgetModeState.READY) WidgetModeState.EMPTY else data.state,
        emptyText = "All clear for today.",
        onRetry = {},
        modifier = modifier
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            data.items.take(2).forEach { item ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { onToggleReminder(item.id) }
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = if (item.done) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                        contentDescription = "Toggle reminder",
                        tint = if (item.done) tokens.success else tokens.accent,
                        modifier = Modifier.size(16.dp)
                    )
                    JarvisText(
                        text = "${item.title} (${item.dueTime})",
                        style = JarvisTypographyTokens.Caption,
                        color = if (item.done) tokens.textMuted else tokens.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun MusicWidgetCard(
    data: MusicWidgetData,
    onTogglePlay: () -> Unit,
    onOpenMusicMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    WidgetStateShell(
        title = "Music",
        icon = Icons.Rounded.MusicNote,
        state = data.state,
        onRetry = onOpenMusicMode,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f).clickable { onOpenMusicMode() }) {
                JarvisText(
                    text = data.title,
                    style = JarvisTypographyTokens.Subtitle.copy(fontSize = 14.sp),
                    color = tokens.textPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                JarvisText(
                    text = data.artist,
                    style = JarvisTypographyTokens.Caption,
                    color = tokens.textMuted,
                    maxLines = 1
                )
            }
            Surface(
                onClick = onTogglePlay,
                shape = CircleShape,
                color = tokens.accent,
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (data.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                        contentDescription = if (data.isPlaying) "Pause music" else "Play music",
                        tint = tokens.onAccent,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { data.progress },
            modifier = Modifier.fillMaxWidth().height(4.dp).clip(RoundedCornerShape(999.dp)),
            color = tokens.accent,
            trackColor = tokens.borderSubtle
        )
    }
}

@Composable
fun DeviceStatusWidgetCard(
    data: DeviceStatusWidgetData,
    onToggleWifi: () -> Unit,
    onToggleMobile: () -> Unit,
    onToggleBluetooth: () -> Unit,
    modifier: Modifier = Modifier
) {
    WidgetStateShell(
        title = "Connectivity",
        icon = Icons.Rounded.Devices,
        state = data.state,
        onRetry = onToggleWifi,
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MiniTogglePill("Wi-Fi", Icons.Rounded.Wifi, data.wifiOn, onToggleWifi, Modifier.weight(1f))
            MiniTogglePill("5G", Icons.Rounded.SignalCellularAlt, data.mobileDataOn, onToggleMobile, Modifier.weight(1f))
            MiniTogglePill("BT", Icons.Rounded.Bluetooth, data.bluetoothOn, onToggleBluetooth, Modifier.weight(1f))
        }
    }
}

@Composable
fun QuickTogglesWidgetCard(
    data: QuickTogglesData,
    onToggleFlash: () -> Unit,
    onToggleVolume: () -> Unit,
    onToggleDnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    WidgetStateShell(
        title = "Quick Toggles",
        icon = Icons.Rounded.Tune,
        state = data.state,
        onRetry = {},
        modifier = modifier
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MiniTogglePill("Torch", Icons.Rounded.FlashlightOn, data.flashlightOn, onToggleFlash, Modifier.weight(1f))
            MiniTogglePill("Sound", Icons.Rounded.VolumeUp, data.volumeHigh, onToggleVolume, Modifier.weight(1f))
            MiniTogglePill("DND", Icons.Rounded.DoNotDisturbOn, data.dndOn, onToggleDnd, Modifier.weight(1f))
        }
    }
}

@Composable
private fun MiniTogglePill(
    label: String,
    icon: ImageVector,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val tokens = LocalJarvisTokens.current
    Surface(
        onClick = onClick,
        modifier = modifier.heightIn(min = 48.dp),
        shape = RoundedCornerShape(12.dp),
        color = if (active) tokens.accent.copy(alpha = 0.20f) else tokens.surfaceCardBottom,
        border = BorderStroke(1.dp, if (active) tokens.accent else tokens.borderSubtle)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(icon, contentDescription = label, tint = if (active) tokens.accent else tokens.textMuted, modifier = Modifier.size(16.dp))
            Spacer(Modifier.height(2.dp))
            JarvisText(
                text = label,
                style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp),
                color = if (active) tokens.textPrimary else tokens.textMuted,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun WidgetStateShell(
    title: String,
    icon: ImageVector,
    state: WidgetModeState,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
    accentTint: Color? = null,
    emptyText: String = "Nothing to show yet.",
    content: @Composable ColumnScope.() -> Unit
) {
    val tokens = LocalJarvisTokens.current
    JarvisGlassCard(
        modifier = modifier.fillMaxWidth(),
        elevationLevel = 1,
        cornerRadius = 22.dp,
        accentTint = accentTint,
        contentPadding = PaddingValues(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(icon, contentDescription = null, tint = tokens.accent, modifier = Modifier.size(16.dp))
                JarvisText(
                    text = title,
                    style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.SemiBold),
                    color = tokens.textMuted,
                    maxLines = 1
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        when (state) {
            WidgetModeState.READY -> content()
            WidgetModeState.LOADING -> {
                JarvisSkeletonBox(modifier = Modifier.fillMaxWidth(0.75f).height(18.dp))
                Spacer(Modifier.height(8.dp))
                JarvisSkeletonBox(modifier = Modifier.fillMaxWidth(0.55f).height(12.dp))
            }
            WidgetModeState.EMPTY -> {
                JarvisText(text = emptyText, style = JarvisTypographyTokens.Caption, color = tokens.textMuted)
            }
            WidgetModeState.ERROR -> {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    JarvisText(text = "Widget failed", style = JarvisTypographyTokens.Caption, color = tokens.error)
                    JarvisTertiaryButton(text = "Retry", onClick = onRetry, color = tokens.error)
                }
            }
            WidgetModeState.OFFLINE -> {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Rounded.CloudOff, contentDescription = "Offline", tint = tokens.warning, modifier = Modifier.size(16.dp))
                    JarvisText(text = "Offline — cached", style = JarvisTypographyTokens.Caption, color = tokens.warning)
                }
            }
        }
    }
}
