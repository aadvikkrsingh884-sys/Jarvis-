package com.example.ui.theme

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.example.model.BackgroundStyle
import com.example.model.Role
import com.example.model.ThemeSpec
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun JarvisTheme(
    theme: ThemeSpec,
    activeRole: Role?,
    bgOverride: BackgroundStyle? = null,
    fontScaleMultiplier: Float = 1.0f,
    reduceMotion: Boolean = false,
    cosmicIntensity: com.example.model.CosmicIntensity = com.example.model.CosmicIntensity.BALANCED,
    glassFrost: Float = 0.80f,
    content: @Composable () -> Unit
) {
    val tokens = buildJarvisTokens(
        theme = theme,
        role = activeRole,
        bgOverride = bgOverride,
        reduceMotion = reduceMotion,
        cosmicIntensity = cosmicIntensity,
        glassFrost = glassFrost
    )

    val colorScheme = if (tokens.isLight) {
        lightColorScheme(
            primary = tokens.accent,
            onPrimary = tokens.onAccent,
            secondary = tokens.accent2,
            background = tokens.bgTop,
            onBackground = tokens.textPrimary,
            surface = tokens.surfaceCardTop,
            onSurface = tokens.textPrimary,
            surfaceVariant = tokens.surfaceCardBottom,
            onSurfaceVariant = tokens.textSecondary,
            error = tokens.error
        )
    } else {
        darkColorScheme(
            primary = tokens.accent,
            onPrimary = tokens.onAccent,
            secondary = tokens.accent2,
            background = tokens.bgTop,
            onBackground = tokens.textPrimary,
            surface = tokens.surfaceCardTop,
            onSurface = tokens.textPrimary,
            surfaceVariant = tokens.surfaceCardBottom,
            onSurfaceVariant = tokens.textSecondary,
            error = tokens.error
        )
    }

    val currentDensity = LocalDensity.current
    val scaledDensity = Density(
        density = currentDensity.density,
        fontScale = currentDensity.fontScale * fontScaleMultiplier
    )

    CompositionLocalProvider(
        LocalJarvisTokens provides tokens,
        LocalDensity provides scaledDensity
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val defaultTheme = ThemeSpec(
        id = "iron_gold",
        name = "Iron Gold",
        bgTop = Color(0xFF000000),
        bgBottom = Color(0xFF1A1608),
        accent = Color(0xFFC9A227),
        accent2 = Color(0xFFE8C766),
        backgroundStyle = BackgroundStyle.AURORA_BLOBS,
        isLight = !darkTheme
    )
    JarvisTheme(theme = defaultTheme, activeRole = null, content = content)
}

@Composable
fun ThemedBackground(
    modifier: Modifier = Modifier,
    tokens: JarvisTokens = LocalJarvisTokens.current
) {
    val transition = rememberInfiniteTransition(label = "bg_ambient")
    val animPhase = if (tokens.reduceMotion) {
        0.25f
    } else {
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 7200, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "bg_phase"
        ).value
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(tokens.bgTop, tokens.bgBottom)
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            when (tokens.backgroundStyle) {
                BackgroundStyle.COSMIC_NEBULA -> {
                    val angle = animPhase * 6.28318f
                    val dx1 = cos(angle) * w * 0.09f
                    val dy1 = sin(angle) * h * 0.06f
                    val nebAlpha = tokens.cosmicIntensity.nebulaAlpha
                    // Dual cosmic nebula clouds
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                tokens.accent.copy(alpha = nebAlpha),
                                tokens.accent.copy(alpha = nebAlpha * 0.3f),
                                Color.Transparent
                            ),
                            center = Offset(w * 0.22f + dx1, h * 0.18f + dy1),
                            radius = w * 0.78f
                        ),
                        radius = w * 0.78f,
                        center = Offset(w * 0.22f + dx1, h * 0.18f + dy1)
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                tokens.accent2.copy(alpha = nebAlpha * 0.8f),
                                Color.Transparent
                            ),
                            center = Offset(w * 0.84f - dx1, h * 0.46f - dy1),
                            radius = w * 0.66f
                        ),
                        radius = w * 0.66f,
                        center = Offset(w * 0.84f - dx1, h * 0.46f - dy1)
                    )
                    // 3D tilted orbital ellipses
                    drawOval(
                        color = tokens.accent2.copy(alpha = 0.12f),
                        topLeft = Offset(w * 0.06f, h * 0.14f),
                        size = Size(w * 0.88f, w * 0.34f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.4f)
                    )
                    drawOval(
                        color = tokens.accent.copy(alpha = 0.10f),
                        topLeft = Offset(w * 0.12f, h * 0.20f),
                        size = Size(w * 0.76f, w * 0.26f),
                        style = androidx.compose.ui.graphics.drawscope.Stroke(width = 1.0f)
                    )
                    // Dynamic twinkling cosmic stars (max 38 <= 40 Mali-G72 limit)
                    val count = tokens.cosmicIntensity.starCount.coerceAtMost(38)
                    for (i in 0 until count) {
                        val sx = ((i * 137 + 41) % 100) / 100f * w
                        val sy = ((i * 251 + 19) % 100) / 100f * h
                        val twinkle = 0.25f + 0.72f * ((sin(angle * 2f + i * 0.9f) + 1f) / 2f)
                        val starColor = if (i % 3 == 0) tokens.accent2 else Color.White
                        drawCircle(
                            color = starColor.copy(alpha = twinkle),
                            radius = if (i % 5 == 0) 2.5f else 1.4f,
                            center = Offset(sx, sy)
                        )
                    }
                }
                BackgroundStyle.AURORA_BLOBS -> {
                    val angle = animPhase * 6.28318f
                    val dx1 = cos(angle) * w * 0.08f
                    val dy1 = sin(angle) * h * 0.05f
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                tokens.accent.copy(alpha = if (tokens.isLight) 0.14f else 0.24f),
                                Color.Transparent
                            ),
                            center = Offset(w * 0.28f + dx1, h * 0.20f + dy1),
                            radius = w * 0.65f
                        ),
                        radius = w * 0.65f,
                        center = Offset(w * 0.28f + dx1, h * 0.20f + dy1)
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                tokens.accent2.copy(alpha = if (tokens.isLight) 0.12f else 0.18f),
                                Color.Transparent
                            ),
                            center = Offset(w * 0.80f - dx1, h * 0.56f - dy1),
                            radius = w * 0.58f
                        ),
                        radius = w * 0.58f,
                        center = Offset(w * 0.80f - dx1, h * 0.56f - dy1)
                    )
                }
                BackgroundStyle.CYBER_GRID -> {
                    val step = w / 10f
                    val lineAlpha = if (tokens.isLight) 0.08f else 0.09f
                    var x = 0f
                    while (x <= w) {
                        drawLine(
                            color = tokens.accent.copy(alpha = lineAlpha),
                            start = Offset(x, 0f),
                            end = Offset(x, h),
                            strokeWidth = 1f
                        )
                        x += step
                    }
                    var y = 0f
                    while (y <= h) {
                        drawLine(
                            color = tokens.accent.copy(alpha = lineAlpha),
                            start = Offset(0f, y),
                            end = Offset(w, y),
                            strokeWidth = 1f
                        )
                        y += step
                    }
                    // Single 60fps scanline
                    val scanY = animPhase * h
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                tokens.accent.copy(alpha = 0.20f),
                                Color.Transparent
                            ),
                            startY = scanY - 40f,
                            endY = scanY + 40f
                        ),
                        topLeft = Offset(0f, scanY - 40f),
                        size = Size(w, 80f)
                    )
                }
                BackgroundStyle.MATRIX_RAIN -> {
                    // Capped at 22 columns (well below 40 particle limit for Mali-G72)
                    val cols = 22
                    val colW = w / cols
                    for (i in 0 until cols) {
                        val speed = 1f + (i % 3) * 0.45f
                        val offsetY = ((animPhase * speed + (i * 0.17f)) % 1f) * h
                        val streamLen = h * 0.22f
                        drawLine(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    tokens.accent.copy(alpha = 0.12f),
                                    tokens.accent.copy(alpha = 0.45f)
                                ),
                                startY = offsetY - streamLen,
                                endY = offsetY
                            ),
                            start = Offset(i * colW + colW * 0.5f, offsetY - streamLen),
                            end = Offset(i * colW + colW * 0.5f, offsetY),
                            strokeWidth = 3f
                        )
                        drawCircle(
                            color = tokens.accent2.copy(alpha = 0.55f),
                            radius = 2.5f,
                            center = Offset(i * colW + colW * 0.5f, offsetY)
                        )
                    }
                }
                BackgroundStyle.PLAIN_GRADIENT -> {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                tokens.accent.copy(alpha = if (tokens.isLight) 0.10f else 0.14f),
                                Color.Transparent
                            ),
                            center = Offset(w * 0.5f, h * 0.16f),
                            radius = w * 0.72f
                        ),
                        radius = w * 0.72f,
                        center = Offset(w * 0.5f, h * 0.16f)
                    )
                }
            }
        }
    }
}
