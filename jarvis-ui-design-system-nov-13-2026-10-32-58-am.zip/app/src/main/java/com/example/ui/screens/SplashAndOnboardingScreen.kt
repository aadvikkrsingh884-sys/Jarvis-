package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.MockData
import com.example.model.LanguageMode
import com.example.ui.components.*
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalJarvisTokens
import com.example.viewmodel.JarvisUiState
import com.example.viewmodel.JarvisViewModel

@Composable
fun SplashScreen(language: LanguageMode) {
    val transition = rememberInfiniteTransition(label = "splash_ring")
    val angle = transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "ring_rot"
    ).value

    val pulse = transition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(1200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "ring_pulse"
    ).value

    val bootProgress = remember { Animatable(0.08f) }
    LaunchedEffect(Unit) {
        bootProgress.animateTo(1.0f, animationSpec = tween(2000, easing = FastOutSlowInEasing))
    }
    val pct = (bootProgress.value * 100).toInt().coerceIn(8, 100)
    val stageLabel = when {
        pct < 38 -> "INITIALIZING NEURAL CORE..."
        pct < 74 -> "CALIBRATING 3D COSMIC ENGINE..."
        else -> "OS AUTOMATION BRIDGES ONLINE"
    }

    val hudCyan = Color(0xFF00E5FF)
    val cosmicViolet = Color(0xFF8B5CF6)
    val arcGold = Color(0xFFFFC107)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF03080B)),
        contentAlignment = Alignment.Center
    ) {
        // User's J.A.R.V.I.S. blueprint HUD background
        Image(
            painter = painterResource(id = R.drawable.img_jarvis_user_hud_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.36f)
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xD803080B), Color(0x70051620), Color(0xF003080B))
                    )
                )
        )

        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(28.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(216.dp)
                    .graphicsLayer {
                        scaleX = pulse
                        scaleY = pulse
                    },
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    rotate(angle) {
                        drawArc(
                            color = hudCyan,
                            startAngle = 0f,
                            sweepAngle = 140f,
                            useCenter = false,
                            style = Stroke(width = 4.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = cosmicViolet,
                            startAngle = 180f,
                            sweepAngle = 120f,
                            useCenter = false,
                            style = Stroke(width = 4.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                    rotate(-angle * 0.72f) {
                        drawArc(
                            color = arcGold.copy(alpha = 0.9f),
                            startAngle = 45f,
                            sweepAngle = 85f,
                            useCenter = false,
                            topLeft = Offset(14.dp.toPx(), 14.dp.toPx()),
                            size = Size(size.width - 28.dp.toPx(), size.height - 28.dp.toPx()),
                            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }
                }
                Image(
                    painter = painterResource(id = R.drawable.img_jarvis_user_logo),
                    contentDescription = "J.A.R.V.I.S. Initializing Logo",
                    contentScale = ContentScale.Crop,
                    alignment = Alignment.Center,
                    modifier = Modifier
                        .size(168.dp)
                        .clip(CircleShape)
                        .border(1.5.dp, hudCyan.copy(alpha = 0.85f), CircleShape)
                )
            }
            Spacer(Modifier.height(26.dp))
            JarvisText(
                text = "J.A.R.V.I.S.",
                style = JarvisTypographyTokens.Display.copy(letterSpacing = 5.sp),
                color = Color(0xFFF6F8FC)
            )
            Spacer(Modifier.height(6.dp))
            JarvisText(
                text = MockData.copy("tagline", language),
                style = JarvisTypographyTokens.Body,
                color = Color(0xFFC5F4FF)
            )
            Spacer(Modifier.height(22.dp))
            JarvisText(
                text = "$stageLabel  $pct%",
                style = JarvisTypographyTokens.Caption.copy(
                    fontFamily = JetBrainsMonoFontFamily,
                    fontWeight = FontWeight.Bold
                ),
                color = hudCyan
            )
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { bootProgress.value },
                modifier = Modifier
                    .width(210.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(999.dp)),
                color = hudCyan,
                trackColor = Color.White.copy(alpha = 0.14f)
            )
        }
    }
}

@Composable
fun WelcomeOpeningScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    var dragAccum by remember { mutableFloatStateOf(0f) }

    val transition = rememberInfiniteTransition(label = "welcome_pulse")
    val glowPulse = if (tokens.reduceMotion) 1f else transition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(2400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "welcome_glow"
    ).value

    val welcomeTitle = when (uiState.language) {
        LanguageMode.HI -> "स्वागत है, अद्विक"
        LanguageMode.HINGLISH -> "Welcome back, Aadvik"
        LanguageMode.EN -> "Welcome back, Aadvik"
    }
    val welcomeSubtitle = when (uiState.language) {
        LanguageMode.HI -> "आपका J.A.R.V.I.S. कॉस्मिक असिस्टेंट तैयार है—वॉइस, गेमिंग और फ़ोन ऑटोमेशन के लिए।"
        LanguageMode.HINGLISH -> "Aapka J.A.R.V.I.S. AI companion ready hai—3D roles, BGMI/Minecraft aur hands-free control ke saath."
        LanguageMode.EN -> "Your cosmic AI companion is online—ready for live voice, 3D personalities, and full phone automation."
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = { dragAccum = 0f },
                    onDragCancel = { dragAccum = 0f },
                    onVerticalDrag = { _, dragAmount ->
                        dragAccum += dragAmount
                        if (dragAccum < -110f) {
                            dragAccum = 0f
                            viewModel.dismissWelcomeScreen(startOnboarding = false)
                        }
                    }
                )
            }
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Brand Pill + Language Switcher
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_jarvis_user_logo),
                        contentDescription = "J.A.R.V.I.S. Logo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Color(0xFF00E5FF), CircleShape)
                    )
                    Column {
                        JarvisText(
                            text = "J.A.R.V.I.S. OS",
                            style = JarvisTypographyTokens.Subtitle.copy(fontSize = 15.sp),
                            color = tokens.textPrimary
                        )
                        JarvisText(
                            text = "ONLINE • MALI-G72 60FPS",
                            style = JarvisTypographyTokens.Caption.copy(
                                fontFamily = JetBrainsMonoFontFamily,
                                fontSize = 10.sp
                            ),
                            color = Color(0xFF00E5FF)
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    LanguageMode.entries.forEach { lang ->
                        val active = uiState.language == lang
                        Surface(
                            onClick = { viewModel.setLanguage(lang) },
                            shape = RoundedCornerShape(999.dp),
                            color = if (active) tokens.accent else tokens.surfaceElevatedTop,
                            border = BorderStroke(1.dp, if (active) tokens.accent2 else tokens.borderSubtle)
                        ) {
                            JarvisText(
                                text = when (lang) {
                                    LanguageMode.EN -> "EN"
                                    LanguageMode.HI -> "हि"
                                    LanguageMode.HINGLISH -> "HIN"
                                },
                                style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp, fontWeight = FontWeight.Bold),
                                color = if (active) tokens.onAccent else tokens.textSecondary,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Welcoming Centerpiece Card: 3D Character + J.A.R.V.I.S. Arc Emblem
            JarvisGlassCard(
                elevationLevel = 2,
                cornerRadius = 30.dp,
                accentTint = Color(0xFF00E5FF),
                contentPadding = PaddingValues(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(215.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF040D14), Color(0xFF150B38))
                            )
                        )
                        .border(1.dp, Color(0xFF00E5FF).copy(alpha = 0.45f), RoundedCornerShape(22.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_jarvis_3d),
                        contentDescription = "Jarvis 3D Companion",
                        contentScale = ContentScale.Crop,
                        alignment = Alignment.TopCenter,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = glowPulse
                                scaleY = glowPulse
                            }
                    )
                    // Subtle bottom gradient for badge legibility
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .height(74.dp)
                            .background(
                                Brush.verticalGradient(listOf(Color.Transparent, Color(0xE6040B12)))
                            )
                    )
                    // J.A.R.V.I.S. Arc Emblem Pill
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Image(
                            painter = painterResource(id = R.drawable.img_jarvis_user_logo),
                            contentDescription = "J.A.R.V.I.S. Emblem",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, Color(0xFF00E5FF), CircleShape)
                        )
                        Column {
                            JarvisText(
                                text = "ALL SYSTEMS VERIFIED",
                                style = JarvisTypographyTokens.Caption.copy(
                                    fontFamily = JetBrainsMonoFontFamily,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                color = Color(0xFF00E5FF)
                            )
                            JarvisText(
                                text = "${uiState.systemBridges.count { it.connected }}/6 Bridges • ${MockData.themes.size} Cosmic Themes",
                                style = JarvisTypographyTokens.Caption,
                                color = Color.White
                            )
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                JarvisText(
                    text = welcomeTitle,
                    style = JarvisTypographyTokens.Display.copy(fontSize = 27.sp, lineHeight = 32.sp),
                    color = tokens.textPrimary
                )
                Spacer(Modifier.height(8.dp))
                JarvisText(
                    text = welcomeSubtitle,
                    style = JarvisTypographyTokens.Body,
                    color = tokens.textSecondary
                )
                Spacer(Modifier.height(14.dp))

                // Quick Highlights
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    WelcomeHighlightRow(
                        icon = Icons.Rounded.SportsEsports,
                        title = "System-Level Automation",
                        subtitle = "Open BGMI & Minecraft, lock screen, & manage notifications"
                    )
                    WelcomeHighlightRow(
                        icon = Icons.Rounded.SwipeVertical,
                        title = "Smart Gestures & Pull-to-Refresh",
                        subtitle = "Drag down to sync pages • Swipe HUD to switch 8 roles • Double-tap 3D"
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            // Interactive Swipe-Up Hint + Primary CTAs
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = tokens.surfaceElevatedTop.copy(alpha = 0.85f),
                    border = BorderStroke(1.dp, Color(0xFF00E5FF).copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Rounded.KeyboardDoubleArrowUp, contentDescription = null, tint = Color(0xFF00E5FF), modifier = Modifier.size(16.dp))
                        JarvisText(
                            text = "Swipe up or tap below to launch Jarvis",
                            style = JarvisTypographyTokens.Caption,
                            color = tokens.textSecondary
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    JarvisSecondaryButton(
                        text = "Tour",
                        icon = Icons.Rounded.Explore,
                        onClick = { viewModel.dismissWelcomeScreen(startOnboarding = true) },
                        modifier = Modifier.weight(0.42f)
                    )
                    JarvisPrimaryButton(
                        text = "Enter Command Hub",
                        icon = Icons.Rounded.RocketLaunch,
                        onClick = { viewModel.dismissWelcomeScreen(startOnboarding = false) },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun WelcomeHighlightRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String
) {
    val tokens = LocalJarvisTokens.current
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(tokens.surfaceCardBottom)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(tokens.accent2.copy(alpha = 0.16f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = title, tint = tokens.accent2, modifier = Modifier.size(18.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            JarvisText(text = title, style = JarvisTypographyTokens.Subtitle.copy(fontSize = 13.sp))
            JarvisText(text = subtitle, style = JarvisTypographyTokens.Caption.copy(fontSize = 11.sp), color = tokens.textMuted)
        }
    }
}

@Composable
fun OnboardingScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
        val cards = listOf(
        Triple("Meet Jarvis", "Your calm, hands-free companion living right inside your phone—fluent in English, Hindi, and Hinglish.", Icons.Rounded.RecordVoiceOver),
        Triple("Choose your role and look", "Switch between 8 anime-realistic personalities—from Jarvis and Mentor to Companion and Best Friend—and ${MockData.themes.size} cosmic & curated themes.", Icons.Rounded.Palette),
        Triple("Give permissions step by step", "Only allow what you want. Every permission has a plain-English reason and a live status indicator.", Icons.Rounded.VerifiedUser),
        Triple("Say your first command", "Tap TALK to launch live voice, read WhatsApp aloud without echo, launch BGMI/Minecraft autopilots, or build apps and PDFs in seconds.", Icons.Rounded.Mic)
    )
    val current = cards[uiState.onboardingPage]

    var horizDrag by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .pointerInput(uiState.onboardingPage) {
                detectHorizontalDragGestures(
                    onDragEnd = { horizDrag = 0f },
                    onDragCancel = { horizDrag = 0f },
                    onHorizontalDrag = { _, dragAmount ->
                        horizDrag += dragAmount
                        if (horizDrag < -110f && uiState.onboardingPage < 3) {
                            horizDrag = 0f
                            viewModel.setOnboardingPage(uiState.onboardingPage + 1)
                        } else if (horizDrag > 110f && uiState.onboardingPage > 0) {
                            horizDrag = 0f
                            viewModel.setOnboardingPage(uiState.onboardingPage - 1)
                        }
                    }
                )
            }
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(20.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            JarvisText(
                text = "${uiState.onboardingPage + 1} / ${cards.size} • Swipe cards",
                style = JarvisTypographyTokens.Caption,
                color = tokens.textMuted
            )
            JarvisTertiaryButton(
                text = "Skip",
                onClick = { viewModel.dismissOnboarding(startWizard = false) }
            )
        }

        JarvisGlassCard(
            elevationLevel = 2,
            cornerRadius = 32.dp,
            contentPadding = PaddingValues(24.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            if (uiState.onboardingPage == 0) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(152.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .border(1.5.dp, tokens.accent2.copy(alpha = 0.55f), RoundedCornerShape(22.dp))
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.img_jarvis_3d),
                        contentDescription = "Jarvis Cosmic Character",
                        contentScale = ContentScale.Crop,
                        alignment = Alignment.TopCenter,
                        modifier = Modifier.fillMaxSize()
                    )
                    Image(
                        painter = painterResource(id = R.drawable.img_jarvis_user_logo),
                        contentDescription = "J.A.R.V.I.S. Logo",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(10.dp)
                            .size(46.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Color(0xFF00E5FF), CircleShape)
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(tokens.accent.copy(alpha = 0.18f))
                        .border(1.dp, tokens.accent.copy(alpha = 0.5f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(current.third, contentDescription = null, tint = tokens.accent, modifier = Modifier.size(34.dp))
                }
            }
            Spacer(Modifier.height(20.dp))
            JarvisText(
                text = current.first,
                style = JarvisTypographyTokens.Display.copy(fontSize = 26.sp, lineHeight = 32.sp),
                color = tokens.textPrimary
            )
            Spacer(Modifier.height(12.dp))
            JarvisText(
                text = current.second,
                style = JarvisTypographyTokens.Body,
                color = tokens.textSecondary
            )
            Spacer(Modifier.height(24.dp))
            // Step dots
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(cards.size) { idx ->
                    Box(
                        modifier = Modifier
                            .height(6.dp)
                            .width(if (idx == uiState.onboardingPage) 28.dp else 8.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(if (idx == uiState.onboardingPage) tokens.accent else tokens.borderSubtle)
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (uiState.onboardingPage > 0) {
                JarvisSecondaryButton(
                    text = "Back",
                    onClick = { viewModel.setOnboardingPage(uiState.onboardingPage - 1) },
                    modifier = Modifier.weight(0.4f)
                )
            }
            JarvisPrimaryButton(
                text = if (uiState.onboardingPage == 3) "Start Setup" else "Next",
                onClick = {
                    if (uiState.onboardingPage < 3) {
                        viewModel.setOnboardingPage(uiState.onboardingPage + 1)
                    } else {
                        viewModel.dismissOnboarding(startWizard = true)
                    }
                },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun SetupWizardScreen(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current
    BackHandler { viewModel.closeSubScreen() }

    val permissions = uiState.permissions
    val currentStep = permissions.getOrNull(uiState.wizardStepIndex) ?: permissions.first()
    val grantedCount = permissions.count { it.granted }
    val readiness = grantedCount.toFloat() / permissions.size.toFloat()
    var keyDraft by remember { mutableStateOf("AIzaSy-demo-configured-key") }
    var keyTestStatus by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                JarvisIconButton(
                    icon = Icons.AutoMirrored.Rounded.ArrowBack,
                    contentDescription = "Back",
                    onClick = { viewModel.closeSubScreen() }
                )
                Column {
                    JarvisText(text = "Setup Wizard", style = JarvisTypographyTokens.Title)
                    JarvisText(
                        text = if (uiState.wizardFinished) "Readiness Summary" else "Step ${uiState.wizardStepIndex + 1} of ${permissions.size}",
                        style = JarvisTypographyTokens.Caption,
                        color = tokens.textMuted
                    )
                }
            }
            JarvisTertiaryButton(
                text = if (uiState.wizardFinished) "Done" else "Summary",
                onClick = {
                    if (uiState.wizardFinished) viewModel.closeSubScreen() else viewModel.finishWizard()
                }
            )
        }

        // Progress Step Pills
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            permissions.forEachIndexed { idx, p ->
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(6.dp)
                        .clip(RoundedCornerShape(999.dp))
                        .background(
                            when {
                                !uiState.wizardFinished && idx == uiState.wizardStepIndex -> tokens.accent
                                p.granted -> tokens.success
                                else -> tokens.borderSubtle
                            }
                        )
                        .clickable { viewModel.setWizardStep(idx) }
                )
            }
        }

        if (!uiState.wizardFinished) {
            JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    JarvisText(
                        text = currentStep.label,
                        style = JarvisTypographyTokens.Title.copy(fontSize = 20.sp),
                        modifier = Modifier.weight(1f)
                    )
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = if (currentStep.granted) tokens.success.copy(alpha = 0.2f) else tokens.warning.copy(alpha = 0.2f)
                    ) {
                        JarvisText(
                            text = if (currentStep.granted) "Done" else "Not yet",
                            style = JarvisTypographyTokens.Caption.copy(fontWeight = FontWeight.Bold),
                            color = if (currentStep.granted) tokens.success else tokens.warning,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                JarvisText(
                    text = currentStep.why,
                    style = JarvisTypographyTokens.Body,
                    color = tokens.textSecondary
                )

                if (currentStep.key == "ai_key") {
                    Spacer(Modifier.height(16.dp))
                    OutlinedTextField(
                        value = keyDraft,
                        onValueChange = { keyDraft = it },
                        label = { JarvisText("Paste free AI key", style = JarvisTypographyTokens.Caption) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp)
                    )
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        JarvisSecondaryButton(
                            text = "Get free key",
                            icon = Icons.Rounded.OpenInNew,
                            onClick = { viewModel.showToast("Opening aistudio.google.com/apikey") },
                            modifier = Modifier.weight(1f)
                        )
                        JarvisSecondaryButton(
                            text = "Test key",
                            icon = Icons.Rounded.Verified,
                            onClick = {
                                val ok = keyDraft.trim().length >= 8
                                keyTestStatus = if (ok) "Key verified! Gemini Flash ready." else "Key too short. Paste a valid key."
                                viewModel.togglePermission("ai_key", forceValue = ok)
                            },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    keyTestStatus?.let { msg ->
                        Spacer(Modifier.height(8.dp))
                        JarvisText(
                            text = msg,
                            style = JarvisTypographyTokens.Caption,
                            color = if (currentStep.granted) tokens.success else tokens.error
                        )
                    }
                }

                if (currentStep.key == "battery") {
                    Spacer(Modifier.height(12.dp))
                    JarvisGlassCard(
                        cornerRadius = 16.dp,
                        accentTint = tokens.info,
                        contentPadding = PaddingValues(12.dp)
                    ) {
                        JarvisText(
                            text = "Galaxy A50s Tip: Settings → Battery → Background usage limits → Never sleeping apps → Add Jarvis.",
                            style = JarvisTypographyTokens.Caption,
                            color = tokens.textSecondary
                        )
                    }
                }

                Spacer(Modifier.height(20.dp))
                JarvisPrimaryButton(
                    text = if (currentStep.granted) "Granted ✓ (Tap to toggle)" else currentStep.fixAction,
                    onClick = { viewModel.togglePermission(currentStep.key) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    JarvisTertiaryButton(
                        text = if (currentStep.optional) "Skip optional step" else "Skip for now",
                        onClick = {
                            if (uiState.wizardStepIndex < permissions.lastIndex) {
                                viewModel.setWizardStep(uiState.wizardStepIndex + 1)
                            } else {
                                viewModel.finishWizard()
                            }
                        }
                    )
                    JarvisSecondaryButton(
                        text = if (uiState.wizardStepIndex == permissions.lastIndex) "Readiness" else "Next Step",
                        onClick = {
                            if (uiState.wizardStepIndex < permissions.lastIndex) {
                                viewModel.setWizardStep(uiState.wizardStepIndex + 1)
                            } else {
                                viewModel.finishWizard()
                            }
                        }
                    )
                }
            }
        } else {
            // Final Readiness Score Ring + Checklist
            JarvisGlassCard(elevationLevel = 2, cornerRadius = 24.dp) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    JarvisProgressRing(
                        progress = readiness,
                        size = 96.dp,
                        strokeWidth = 9.dp,
                        color = if (readiness >= 0.75f) tokens.success else tokens.warning,
                        centerLabel = "${(readiness * 100).toInt()}%"
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        JarvisText(text = "Galaxy A50s Readiness", style = JarvisTypographyTokens.Title.copy(fontSize = 18.sp))
                        Spacer(Modifier.height(4.dp))
                        JarvisText(
                            text = "$grantedCount of ${permissions.size} capabilities ready for hands-free voice.",
                            style = JarvisTypographyTokens.Body,
                            color = tokens.textSecondary
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                permissions.forEachIndexed { idx, p ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { viewModel.togglePermission(p.key) }
                            .padding(vertical = 8.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Icon(
                                imageVector = if (p.granted) Icons.Rounded.CheckCircle else Icons.Rounded.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (p.granted) tokens.success else tokens.warning,
                                modifier = Modifier.size(20.dp)
                            )
                            JarvisText(text = p.label, style = JarvisTypographyTokens.Body.copy(fontSize = 14.sp))
                        }
                        JarvisTertiaryButton(
                            text = if (p.granted) "Done" else "Fix",
                            onClick = { viewModel.setWizardStep(idx) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                JarvisPrimaryButton(
                    text = "Launch Jarvis Home",
                    onClick = { viewModel.closeSubScreen() },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}
