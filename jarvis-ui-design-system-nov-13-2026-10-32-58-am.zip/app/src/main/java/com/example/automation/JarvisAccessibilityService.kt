package com.example.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference

/**
 * Real Android AccessibilityService enabling Jarvis to execute user-triggered
 * global system actions (screen lock, notification shade, screenshot) and
 * gesture-based pattern unlock swipes.
 */
class JarvisAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instanceRef = WeakReference(this)
        _isConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Window state observation stays lightweight on-device; no remote telemetry.
    }

    override fun onInterrupt() {
        // No continuous feedback stream to cancel.
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        _isConnected.value = false
        instanceRef = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        _isConnected.value = false
        instanceRef = null
        super.onDestroy()
    }

    companion object {
        private var instanceRef: WeakReference<JarvisAccessibilityService>? = null

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private fun activeService(): JarvisAccessibilityService? = instanceRef?.get()

        fun lockScreen(): Boolean {
            val service = activeService() ?: return false
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                service.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            } else {
                false
            }
        }

        fun openNotificationShade(): Boolean {
            val service = activeService() ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        }

        fun openQuickSettings(): Boolean {
            val service = activeService() ?: return false
            return service.performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        }

        fun takeScreenshot(): Boolean {
            val service = activeService() ?: return false
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                service.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            } else {
                false
            }
        }

        fun performPatternSwipe(
            nodes: List<Int>,
            durationMs: Long,
            padScale: Float,
            onCompleted: (Boolean) -> Unit
        ): Boolean {
            val service = activeService() ?: return false
            if (nodes.size < 4) return false

            val metrics = service.resources.displayMetrics
            val screenW = metrics.widthPixels.toFloat()
            val screenH = metrics.heightPixels.toFloat()

            // Standard Android pattern grid occupies lower-center half of lock screen
            val gridSize = minOf(screenW, screenH) * 0.62f * padScale.coerceIn(0.75f, 1.25f)
            val left = (screenW - gridSize) / 2f
            val top = screenH * 0.46f
            val step = gridSize / 2f

            val path = Path()
            nodes.forEachIndexed { idx, node ->
                val clamped = node.coerceIn(0, 8)
                val col = clamped % 3
                val row = clamped / 3
                val x = left + col * step
                val y = top + row * step
                if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }

            val stroke = GestureDescription.StrokeDescription(
                path,
                0L,
                durationMs.coerceIn(180L, 1200L)
            )
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            return service.dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        onCompleted(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        onCompleted(false)
                    }
                },
                null
            )
        }
    }
}
