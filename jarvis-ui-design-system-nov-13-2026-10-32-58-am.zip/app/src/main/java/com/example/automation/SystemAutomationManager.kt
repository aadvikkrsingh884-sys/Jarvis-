package com.example.automation

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Central Android system-level automation orchestrator.
 * Executes real app launches (BGMI, Minecraft, Free Fire, YouTube, etc.),
 * AccessibilityService screen-lock / unlock gesture / notification shade actions,
 * and NotificationListenerService / NotificationManager notification & DND management.
 */
class SystemAutomationManager(context: Context) {

    private val appContext: Context = context.applicationContext
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val defaultCatalog = listOf(
        AutomationTargetApp(
            id = "app_bgmi",
            name = "BGMI",
            category = "Gaming",
            primaryPackage = "com.pubg.imobile",
            fallbackPackages = listOf("com.tencent.ig")
        ),
        AutomationTargetApp(
            id = "app_minecraft",
            name = "Minecraft",
            category = "Gaming",
            primaryPackage = "com.mojang.minecraftpe",
            fallbackPackages = listOf("com.mojang.minecrafttrialpe")
        ),
        AutomationTargetApp(
            id = "app_freefire",
            name = "Free Fire MAX",
            category = "Gaming",
            primaryPackage = "com.dts.freefiremax",
            fallbackPackages = listOf("com.dts.freefireth")
        ),
        AutomationTargetApp(
            id = "app_youtube",
            name = "YouTube",
            category = "Media",
            primaryPackage = "com.google.android.youtube"
        ),
        AutomationTargetApp(
            id = "app_whatsapp",
            name = "WhatsApp",
            category = "Social",
            primaryPackage = "com.whatsapp"
        ),
        AutomationTargetApp(
            id = "app_telegram",
            name = "Telegram",
            category = "Social",
            primaryPackage = "org.telegram.messenger"
        )
    )

    private val _runtimeState = MutableStateFlow(
        AutomationRuntimeState(
            targetApps = defaultCatalog,
            executionLog = listOf(
                AutomationExecutionRecord(
                    id = "init_auto",
                    timestamp = nowLabel(),
                    title = "Automation Engine Initialized",
                    detail = "Target app queries & OS service bridges ready.",
                    category = AutomationActionCategory.SYSTEM_CONTROL,
                    success = true,
                    executedVia = "Android OS"
                )
            )
        )
    )
    val runtimeState: StateFlow<AutomationRuntimeState> = _runtimeState.asStateFlow()

    init {
        refreshStatus()
        scope.launch {
            JarvisAccessibilityService.isConnected.collect {
                refreshStatus()
            }
        }
        scope.launch {
            JarvisNotificationListenerService.isConnected.collect {
                refreshStatus()
            }
        }
        scope.launch {
            JarvisNotificationListenerService.activeItems.collect { liveList ->
                _runtimeState.update { it.copy(liveNotifications = liveList) }
            }
        }
    }

    fun refreshStatus() {
        val accEnabled = isAccessibilityServiceEnabled()
        val notifListenerEnabled = isNotificationListenerEnabled()
        val notifManager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        val dndGranted = notifManager?.isNotificationPolicyAccessGranted == true
        val dndActive = notifManager?.currentInterruptionFilter?.let {
            it != NotificationManager.INTERRUPTION_FILTER_ALL
        } ?: false

        val resolvedCatalog = defaultCatalog.map { app ->
            val candidates = listOf(app.primaryPackage) + app.fallbackPackages
            val installedPkg = candidates.firstOrNull { pkg ->
                appContext.packageManager.getLaunchIntentForPackage(pkg) != null
            }
            app.copy(
                installed = installedPkg != null,
                resolvedPackage = installedPkg
            )
        }

        if (notifListenerEnabled) {
            JarvisNotificationListenerService.refreshNow()
        }

        _runtimeState.update {
            it.copy(
                accessibilityEnabled = accEnabled,
                notificationListenerEnabled = notifListenerEnabled,
                dndPolicyGranted = dndGranted,
                dndActive = dndActive,
                targetApps = resolvedCatalog
            )
        }
    }

    fun launchTargetApp(appId: String, openStoreIfMissing: Boolean = true): AutomationResult {
        refreshStatus()
        val app = _runtimeState.value.targetApps.firstOrNull { it.id == appId }
            ?: return AutomationResult(false, "Unknown target application.")

        val pkg = app.resolvedPackage
        if (pkg != null) {
            val launchIntent = appContext.packageManager.getLaunchIntentForPackage(pkg)?.apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            }
            if (launchIntent != null && safeStartActivity(launchIntent)) {
                val msg = "Launched ${app.name} ($pkg)."
                recordLog("Launch ${app.name}", msg, AutomationActionCategory.APP_LAUNCH, true, "PackageManager")
                return AutomationResult(true, msg)
            }
        }

        return if (openStoreIfMissing) {
            val storeIntent = Intent(
                Intent.ACTION_VIEW,
                Uri.parse("https://play.google.com/store/apps/details?id=${app.primaryPackage}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val openedStore = safeStartActivity(storeIntent)
            val msg = if (openedStore) {
                "${app.name} is not installed here — opened Play Store listing."
            } else {
                "${app.name} (${app.primaryPackage}) is not installed on this device."
            }
            recordLog("Launch ${app.name}", msg, AutomationActionCategory.APP_LAUNCH, false, "Play Store Intent")
            AutomationResult(false, msg)
        } else {
            val msg = "${app.name} (${app.primaryPackage}) is not installed on this device."
            recordLog("Launch ${app.name}", msg, AutomationActionCategory.APP_LAUNCH, false, "PackageManager")
            AutomationResult(false, msg)
        }
    }

    fun lockScreen(): AutomationResult {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) {
            val msg = "Accessibility screen lock requires Android 9 (API 28) or newer."
            recordLog("Lock Screen", msg, AutomationActionCategory.SCREEN_LOCK, false, "OS Version")
            return AutomationResult(false, msg)
        }
        val locked = JarvisAccessibilityService.lockScreen()
        if (locked) {
            val msg = "Device screen locked cleanly via Accessibility Engine."
            recordLog("Lock Screen", msg, AutomationActionCategory.SCREEN_LOCK, true, "AccessibilityService")
            return AutomationResult(true, msg)
        }

        openSystemSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        val msg = "Enable 'Jarvis System Automation' in Accessibility Settings to lock the screen."
        recordLog("Lock Screen", msg, AutomationActionCategory.SCREEN_LOCK, false, "Settings Prompt")
        return AutomationResult(false, msg, Settings.ACTION_ACCESSIBILITY_SETTINGS)
    }

    fun runPatternUnlockGesture(nodes: List<Int>, speedMs: Float, padScale: Float): AutomationResult {
        if (nodes.size < 4) {
            val msg = "Select at least 4 pattern dots before executing unlock gesture."
            recordLog("Unlock Gesture", msg, AutomationActionCategory.SCREEN_LOCK, false, "Validation")
            return AutomationResult(false, msg)
        }
        val dispatched = JarvisAccessibilityService.performPatternSwipe(
            nodes = nodes,
            durationMs = speedMs.toLong(),
            padScale = padScale,
            onCompleted = { completed ->
                recordLog(
                    "Unlock Gesture Callback",
                    if (completed) "Pattern gesture stroke finished (${nodes.size} nodes)." else "Gesture interrupted by system.",
                    AutomationActionCategory.SCREEN_LOCK,
                    completed,
                    "GestureDescription"
                )
            }
        )
        if (dispatched) {
            val msg = "Dispatched ${nodes.size}-node unlock gesture (${speedMs.toInt()} ms)."
            recordLog("Unlock Gesture", msg, AutomationActionCategory.SCREEN_LOCK, true, "AccessibilityService")
            return AutomationResult(true, msg)
        }

        openSystemSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        val msg = "Enable 'Jarvis System Automation' in Accessibility Settings to dispatch gestures."
        recordLog("Unlock Gesture", msg, AutomationActionCategory.SCREEN_LOCK, false, "Settings Prompt")
        return AutomationResult(false, msg, Settings.ACTION_ACCESSIBILITY_SETTINGS)
    }

    fun openNotificationShade(): AutomationResult {
        if (JarvisAccessibilityService.openNotificationShade()) {
            val msg = "Expanded Android notification shade."
            recordLog("Open Notifications", msg, AutomationActionCategory.NOTIFICATION_MGMT, true, "AccessibilityService")
            return AutomationResult(true, msg)
        }
        openSystemSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        val msg = "Enable 'Jarvis System Automation' in Accessibility Settings to open the notification shade."
        recordLog("Open Notifications", msg, AutomationActionCategory.NOTIFICATION_MGMT, false, "Settings Prompt")
        return AutomationResult(false, msg, Settings.ACTION_ACCESSIBILITY_SETTINGS)
    }

    fun takeScreenshot(): AutomationResult {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P && JarvisAccessibilityService.takeScreenshot()) {
            val msg = "System screenshot captured via Accessibility Engine."
            recordLog("Take Screenshot", msg, AutomationActionCategory.SYSTEM_CONTROL, true, "AccessibilityService")
            return AutomationResult(true, msg)
        }
        openSystemSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        val msg = "Enable 'Jarvis System Automation' in Accessibility Settings to capture system screenshots."
        recordLog("Take Screenshot", msg, AutomationActionCategory.SYSTEM_CONTROL, false, "Settings Prompt")
        return AutomationResult(false, msg, Settings.ACTION_ACCESSIBILITY_SETTINGS)
    }

    fun dismissNotification(key: String): AutomationResult {
        val removed = JarvisNotificationListenerService.dismissNotification(key)
        if (removed) {
            val msg = "Dismissed notification from Android tray."
            recordLog("Dismiss Notification", msg, AutomationActionCategory.NOTIFICATION_MGMT, true, "NotificationListener")
            return AutomationResult(true, msg)
        }
        openSystemSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        val msg = "Grant 'Jarvis Notification Manager' access to dismiss OS notifications."
        recordLog("Dismiss Notification", msg, AutomationActionCategory.NOTIFICATION_MGMT, false, "Settings Prompt")
        return AutomationResult(false, msg, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
    }

    fun clearAllNotifications(): AutomationResult {
        val cleared = JarvisNotificationListenerService.clearAllNotifications()
        if (cleared != null) {
            val msg = "Cleared $cleared clearable notification(s) from Android tray."
            recordLog("Clear Notifications", msg, AutomationActionCategory.NOTIFICATION_MGMT, true, "NotificationListener")
            return AutomationResult(true, msg)
        }
        openSystemSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
        val msg = "Enable Notification Access for Jarvis to clear device notifications."
        recordLog("Clear Notifications", msg, AutomationActionCategory.NOTIFICATION_MGMT, false, "Settings Prompt")
        return AutomationResult(false, msg, Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
    }

    fun setDoNotDisturb(enabled: Boolean): AutomationResult {
        val notifManager = appContext.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        if (notifManager?.isNotificationPolicyAccessGranted == true) {
            notifManager.setInterruptionFilter(
                if (enabled) NotificationManager.INTERRUPTION_FILTER_PRIORITY
                else NotificationManager.INTERRUPTION_FILTER_ALL
            )
            refreshStatus()
            val msg = if (enabled) "Do Not Disturb (Priority) enabled." else "Do Not Disturb turned off."
            recordLog("DND Toggle", msg, AutomationActionCategory.NOTIFICATION_MGMT, true, "NotificationManager")
            return AutomationResult(true, msg)
        }

        if (JarvisNotificationListenerService.setInterruptionDnd(enabled)) {
            refreshStatus()
            val msg = if (enabled) "Priority DND requested via Notification Listener." else "Normal notifications restored."
            recordLog("DND Toggle", msg, AutomationActionCategory.NOTIFICATION_MGMT, true, "NotificationListener")
            return AutomationResult(true, msg)
        }

        openSystemSettings(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
        val msg = "Grant Do Not Disturb Access in Settings to toggle system DND."
        recordLog("DND Toggle", msg, AutomationActionCategory.NOTIFICATION_MGMT, false, "Settings Prompt")
        return AutomationResult(false, msg, Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS)
    }

    fun openSystemSettings(action: String): Boolean {
        val intent = Intent(action).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val opened = safeStartActivity(intent)
        recordLog(
            "Open OS Settings",
            action.substringAfterLast('.'),
            AutomationActionCategory.SYSTEM_CONTROL,
            opened,
            "Settings Intent"
        )
        return opened
    }

    private fun safeStartActivity(intent: Intent): Boolean {
        return runCatching {
            appContext.startActivity(intent)
            true
        }.getOrDefault(false)
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        if (JarvisAccessibilityService.isConnected.value) return true
        val expected = ComponentName(appContext, JarvisAccessibilityService::class.java).flattenToString()
        val enabledServices = Settings.Secure.getString(
            appContext.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ).orEmpty()
        return enabledServices.split(':').any { it.equals(expected, ignoreCase = true) }
    }

    private fun isNotificationListenerEnabled(): Boolean {
        if (JarvisNotificationListenerService.isConnected.value) return true
        return NotificationManagerCompat.getEnabledListenerPackages(appContext)
            .contains(appContext.packageName)
    }

    private fun recordLog(
        title: String,
        detail: String,
        category: AutomationActionCategory,
        success: Boolean,
        via: String
    ) {
        val record = AutomationExecutionRecord(
            id = "log_${System.currentTimeMillis()}",
            timestamp = nowLabel(),
            title = title,
            detail = detail,
            category = category,
            success = success,
            executedVia = via
        )
        _runtimeState.update {
            it.copy(executionLog = (listOf(record) + it.executionLog).take(20))
        }
    }

    private fun nowLabel(): String {
        return SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())
    }
}
