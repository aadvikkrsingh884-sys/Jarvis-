package com.example.automation

enum class AutomationActionCategory(val label: String) {
    APP_LAUNCH("App Launch"),
    SCREEN_LOCK("Screen & Lock"),
    NOTIFICATION_MGMT("Notifications"),
    SYSTEM_CONTROL("System")
}

data class AutomationTargetApp(
    val id: String,
    val name: String,
    val category: String,
    val primaryPackage: String,
    val fallbackPackages: List<String> = emptyList(),
    val installed: Boolean = false,
    val resolvedPackage: String? = null
)

data class LiveNotificationItem(
    val key: String,
    val packageName: String,
    val appLabel: String,
    val sender: String,
    val text: String,
    val time: String,
    val clearable: Boolean
)

data class AutomationExecutionRecord(
    val id: String,
    val timestamp: String,
    val title: String,
    val detail: String,
    val category: AutomationActionCategory,
    val success: Boolean,
    val executedVia: String
)

data class AutomationResult(
    val success: Boolean,
    val message: String,
    val openedSettingsAction: String? = null
)

data class AutomationRuntimeState(
    val accessibilityEnabled: Boolean = false,
    val notificationListenerEnabled: Boolean = false,
    val dndPolicyGranted: Boolean = false,
    val dndActive: Boolean = false,
    val targetApps: List<AutomationTargetApp> = emptyList(),
    val liveNotifications: List<LiveNotificationItem> = emptyList(),
    val executionLog: List<AutomationExecutionRecord> = emptyList()
)
