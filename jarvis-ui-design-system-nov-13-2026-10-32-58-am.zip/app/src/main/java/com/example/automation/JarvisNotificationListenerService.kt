package com.example.automation

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.lang.ref.WeakReference
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Real NotificationListenerService allowing Jarvis to read active device
 * notifications, dismiss individual alerts, clear clearable trays, and
 * control DND interruption filters when authorized by the user.
 */
class JarvisNotificationListenerService : NotificationListenerService() {

    override fun onListenerConnected() {
        super.onListenerConnected()
        instanceRef = WeakReference(this)
        _isConnected.value = true
        refreshActiveList()
    }

    override fun onListenerDisconnected() {
        _isConnected.value = false
        instanceRef = null
        super.onListenerDisconnected()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        refreshActiveList()
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        refreshActiveList()
    }

    private fun refreshActiveList() {
        val items = runCatching {
            val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
            activeNotifications
                ?.filter { it.packageName != packageName }
                ?.sortedByDescending { it.postTime }
                ?.take(20)
                ?.mapNotNull { sbn ->
                    val extras = sbn.notification?.extras ?: return@mapNotNull null
                    val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty().trim()
                    val body = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                        ?: extras.getCharSequence(Notification.EXTRA_TEXT))
                        ?.toString().orEmpty().trim()
                    if (title.isEmpty() && body.isEmpty()) return@mapNotNull null
                    LiveNotificationItem(
                        key = sbn.key,
                        packageName = sbn.packageName,
                        appLabel = friendlyAppLabel(sbn.packageName),
                        sender = title.ifEmpty { friendlyAppLabel(sbn.packageName) },
                        text = body.ifEmpty { "Active notification" },
                        time = sdf.format(Date(sbn.postTime)),
                        clearable = sbn.isClearable
                    )
                }.orEmpty()
        }.getOrDefault(emptyList())
        _activeItems.value = items
    }

    companion object {
        private var instanceRef: WeakReference<JarvisNotificationListenerService>? = null

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _activeItems = MutableStateFlow<List<LiveNotificationItem>>(emptyList())
        val activeItems: StateFlow<List<LiveNotificationItem>> = _activeItems.asStateFlow()

        fun refreshNow() {
            instanceRef?.get()?.refreshActiveList()
        }

        fun dismissNotification(key: String): Boolean {
            val service = instanceRef?.get() ?: return false
            return runCatching {
                service.cancelNotification(key)
                service.refreshActiveList()
                true
            }.getOrDefault(false)
        }

        fun clearAllNotifications(): Int? {
            val service = instanceRef?.get() ?: return null
            return runCatching {
                val count = _activeItems.value.count { it.clearable }
                service.cancelAllNotifications()
                service.refreshActiveList()
                count
            }.getOrNull()
        }

        fun setInterruptionDnd(enabled: Boolean): Boolean {
            val service = instanceRef?.get() ?: return false
            return runCatching {
                service.requestInterruptionFilter(
                    if (enabled) INTERRUPTION_FILTER_PRIORITY else INTERRUPTION_FILTER_ALL
                )
                true
            }.getOrDefault(false)
        }

        private fun friendlyAppLabel(pkg: String): String = when (pkg) {
            "com.whatsapp" -> "WhatsApp"
            "org.telegram.messenger" -> "Telegram"
            "com.instagram.android" -> "Instagram"
            "com.google.android.gm" -> "Gmail"
            "com.google.android.youtube" -> "YouTube"
            "com.pubg.imobile" -> "BGMI"
            "com.mojang.minecraftpe" -> "Minecraft"
            "com.dts.freefiremax", "com.dts.freefireth" -> "Free Fire"
            else -> pkg.substringAfterLast('.').replaceFirstChar { it.uppercase() }
        }
    }
}
