package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.R
import com.example.model.*

object MockData {

    val roles: List<Role> = listOf(
        Role(
            id = RoleId.JARVIS,
            name = "Jarvis",
            tagline = "Calm, precise, cosmic HUD",
            personalityLine = "Stylish futuristic assistant with expressive eyes, cosmic headphones option, and Iron Man precision.",
            accent = Color(0xFF8B5CF6),
            accent2 = Color(0xFF00F5D4),
            voiceName = "Aarav Neural",
            characterAssets = CharacterAssets(
                basePortraitKey = "char_jarvis_hoodie",
                portraitResId = R.drawable.char_jarvis_hoodie,
                altPortraitResId = R.drawable.char_jarvis_cosmic_banner,
                portrait3dResId = R.drawable.img_jarvis_3d,
                eyesOpenKey = "char_jarvis_eyes_open",
                eyesClosedKey = "char_jarvis_eyes_closed",
                mouthVisemeSetKey = "char_jarvis_mouth",
                hairStyle = "sleek_parted",
                attireStyle = "futuristic_hoodie",
                hasHeadset = true,
                rimHue = Color(0xFF00F5D4)
            ),
            backgroundMood = "Cosmic HUD & Starlight",
            defaultExpression = Expression.NEUTRAL
        ),
        Role(
            id = RoleId.COMPANION,
            name = "Companion",
            tagline = "Warm, caring close friend (platonic)",
            personalityLine = "Kind, golden-hour friend who checks in on your energy and keeps things light.",
            accent = Color(0xFFFF6FA5),
            accent2 = Color(0xFFFFB3D1),
            voiceName = "Ananya Warm",
            characterAssets = CharacterAssets(
                basePortraitKey = "char_companion",
                portraitResId = R.drawable.char_companion,
                eyesOpenKey = "char_companion_eyes_open",
                eyesClosedKey = "char_companion_eyes_closed",
                mouthVisemeSetKey = "char_companion_mouth",
                hairStyle = "soft_wavy",
                attireStyle = "cozy_knit",
                rimHue = Color(0xFFFFB547)
            ),
            backgroundMood = "Golden Friendship Warmth",
            defaultExpression = Expression.LOVE_WARM
        ),
        Role(
            id = RoleId.BIG_BROTHER,
            name = "Big Brother",
            tagline = "Strong, protective, steady",
            personalityLine = "Older brother energy—grounded, reliable, always guards your focus and device.",
            accent = Color(0xFF4FA3FF),
            accent2 = Color(0xFF8FB8FF),
            voiceName = "Vikram Deep",
            characterAssets = CharacterAssets(
                basePortraitKey = "char_big_brother",
                portraitResId = R.drawable.char_big_brother,
                eyesOpenKey = "char_big_brother_eyes_open",
                eyesClosedKey = "char_big_brother_eyes_closed",
                mouthVisemeSetKey = "char_big_brother_mouth",
                hairStyle = "short_textured",
                attireStyle = "bomber_jacket",
                rimHue = Color(0xFF4FA3FF)
            ),
            backgroundMood = "Steady Steel Horizon",
            defaultExpression = Expression.NEUTRAL
        ),
        Role(
            id = RoleId.LITTLE_BROTHER,
            name = "Little Brother",
            tagline = "Playful, energetic, bright",
            personalityLine = "High-energy younger brother with a bright grin, fast gaming callouts, and fun ideas.",
            accent = Color(0xFFFF8A3D),
            accent2 = Color(0xFFFFD166),
            voiceName = "Rohan Spark",
            characterAssets = CharacterAssets(
                basePortraitKey = "char_little_brother",
                portraitResId = R.drawable.char_little_brother,
                eyesOpenKey = "char_little_brother_eyes_open",
                eyesClosedKey = "char_little_brother_eyes_closed",
                mouthVisemeSetKey = "char_little_brother_mouth",
                hairStyle = "spiky_messy",
                attireStyle = "sport_tee",
                rimHue = Color(0xFFFF8A3D)
            ),
            backgroundMood = "Bright Amber Spark",
            defaultExpression = Expression.HAPPY
        ),
        Role(
            id = RoleId.SISTER,
            name = "Sister",
            tagline = "Caring, observant, calm teal",
            personalityLine = "Thoughtful sister who spots every detail, organizes your deadlines, and keeps you calm.",
            accent = Color(0xFF3DDBC0),
            accent2 = Color(0xFF8EF5E3),
            voiceName = "Meera Clear",
            characterAssets = CharacterAssets(
                basePortraitKey = "char_sister",
                portraitResId = R.drawable.char_sister,
                eyesOpenKey = "char_sister_eyes_open",
                eyesClosedKey = "char_sister_eyes_closed",
                mouthVisemeSetKey = "char_sister_mouth",
                hairStyle = "shoulder_bob",
                attireStyle = "layered_cardigan",
                rimHue = Color(0xFF3DDBC0)
            ),
            backgroundMood = "Calm Teal Breeze",
            defaultExpression = Expression.LISTENING
        ),
        Role(
            id = RoleId.BEST_FRIEND,
            name = "Best Friend",
            tagline = "Witty, playful, headset ready",
            personalityLine = "Orange hoodie & gaming headset—down for BGMI, Free Fire, Minecraft, or late-night coding.",
            accent = Color(0xFF7CFF6B),
            accent2 = Color(0xFFB6FF6B),
            voiceName = "Kabir Vibe",
            characterAssets = CharacterAssets(
                basePortraitKey = "char_best_friend",
                portraitResId = R.drawable.char_best_friend,
                portrait3dResId = R.drawable.img_best_friend_3d,
                eyesOpenKey = "char_best_friend_eyes_open",
                eyesClosedKey = "char_best_friend_eyes_closed",
                mouthVisemeSetKey = "char_best_friend_mouth",
                hairStyle = "swept_fringe",
                attireStyle = "orange_hoodie",
                hasHeadset = true,
                rimHue = Color(0xFF7CFF6B)
            ),
            backgroundMood = "Arcade Neon Glow",
            defaultExpression = Expression.HAPPY
        ),
        Role(
            id = RoleId.MENTOR,
            name = "Mentor",
            tagline = "Intelligent, composed, focused",
            personalityLine = "Sharp glasses, dark blazer, sunlit library calm—breaks tough DSA & physics problems down.",
            accent = Color(0xFFB388FF),
            accent2 = Color(0xFFD8C2FF),
            voiceName = "Dr. Sen Sage",
            characterAssets = CharacterAssets(
                basePortraitKey = "char_mentor",
                portraitResId = R.drawable.char_mentor,
                portrait3dResId = R.drawable.img_mentor_3d,
                eyesOpenKey = "char_mentor_eyes_open",
                eyesClosedKey = "char_mentor_eyes_closed",
                mouthVisemeSetKey = "char_mentor_mouth",
                hairStyle = "neatly_styled",
                attireStyle = "blazer_tie",
                hasGlasses = true,
                rimHue = Color(0xFFB388FF)
            ),
            backgroundMood = "Editorial Library Violet",
            defaultExpression = Expression.THINKING
        ),
        Role(
            id = RoleId.LISTENER,
            name = "Listener",
            tagline = "Gentle, patient, supportive",
            personalityLine = "Futuristic soft purple visor glow, calm eyes—gives you space to talk without judgement.",
            accent = Color(0xFF8FB8FF),
            accent2 = Color(0xFFC4B5FD),
            voiceName = "Tara Soft",
            characterAssets = CharacterAssets(
                basePortraitKey = "char_listener",
                portraitResId = R.drawable.char_listener,
                portrait3dResId = R.drawable.img_listener_3d,
                eyesOpenKey = "char_listener_eyes_open",
                eyesClosedKey = "char_listener_eyes_closed",
                mouthVisemeSetKey = "char_listener_mouth",
                hairStyle = "long_gentle",
                attireStyle = "soft_shawl",
                rimHue = Color(0xFFB388FF)
            ),
            backgroundMood = "Twilight Lavender Mist",
            defaultExpression = Expression.LISTENING
        )
    )

    val themes: List<ThemeSpec> = listOf(
        // Trending Gen-Z / Gen-Alpha Flagship Cosmic Theme first!
        ThemeSpec("cosmic_nebula", "Cosmic Nebula", Color(0xFF050314), Color(0xFF170B3B), Color(0xFF8B5CF6), Color(0xFF00F5D4), BackgroundStyle.COSMIC_NEBULA, false),
        ThemeSpec("starlight_cyber", "Starlight Cyber", Color(0xFF06071A), Color(0xFF16123E), Color(0xFF38BDF8), Color(0xFFF472B6), BackgroundStyle.COSMIC_NEBULA, false),
        ThemeSpec("hyper_acid", "Hyper Volt", Color(0xFF060A07), Color(0xFF102214), Color(0xFFCCFF00), Color(0xFF00F5D4), BackgroundStyle.CYBER_GRID, false),
        ThemeSpec("iron_gold", "Iron Gold", Color(0xFF000000), Color(0xFF1A1608), Color(0xFFC9A227), Color(0xFFE8C766), BackgroundStyle.AURORA_BLOBS, false),
        ThemeSpec("cyber_tech", "Cyber Tech", Color(0xFF02060E), Color(0xFF0A1F33), Color(0xFF00E5FF), Color(0xFF7C4DFF), BackgroundStyle.CYBER_GRID, false),
        ThemeSpec("matrix", "Matrix", Color(0xFF000000), Color(0xFF001A06), Color(0xFF00FF41), Color(0xFF00B82E), BackgroundStyle.MATRIX_RAIN, false),
        ThemeSpec("neon_future", "Neon Future", Color(0xFF0A0014), Color(0xFF1A0033), Color(0xFFFF2BD6), Color(0xFF00E5FF), BackgroundStyle.CYBER_GRID, false),
        ThemeSpec("dark_luxury", "Dark Luxury", Color(0xFF0B0B0B), Color(0xFF1C1712), Color(0xFFD4AF37), Color(0xFF8B6B23), BackgroundStyle.PLAIN_GRADIENT, false),
        ThemeSpec("midnight_blue", "Midnight Blue", Color(0xFF050B1F), Color(0xFF0B1E4A), Color(0xFF4F8CFF), Color(0xFF8FB8FF), BackgroundStyle.AURORA_BLOBS, false),
        ThemeSpec("anime_gaming", "Anime Gaming", Color(0xFF0D0221), Color(0xFF2A0A5E), Color(0xFFB388FF), Color(0xFFFF4FD8), BackgroundStyle.COSMIC_NEBULA, false),
        ThemeSpec("ocean", "Ocean", Color(0xFF021A24), Color(0xFF04485E), Color(0xFF21D4FD), Color(0xFF2AF598), BackgroundStyle.AURORA_BLOBS, false),
        ThemeSpec("sunset", "Sunset", Color(0xFF1A0510), Color(0xFF4A1A12), Color(0xFFFF7A3D), Color(0xFFFF3D6E), BackgroundStyle.AURORA_BLOBS, false),
        ThemeSpec("carbon_red", "Carbon Red", Color(0xFF0A0A0A), Color(0xFF1A0505), Color(0xFFFF1744), Color(0xFFFF8A80), BackgroundStyle.CYBER_GRID, false),
        ThemeSpec("aurora", "Aurora", Color(0xFF04121A), Color(0xFF0A2A2A), Color(0xFF5CFFB5), Color(0xFF7C9CFF), BackgroundStyle.AURORA_BLOBS, false),
        ThemeSpec("stealth", "Stealth", Color(0xFF0D0D0D), Color(0xFF151515), Color(0xFFE0E0E0), Color(0xFF9E9E9E), BackgroundStyle.PLAIN_GRADIENT, false),
        ThemeSpec("forest", "Forest", Color(0xFF06150A), Color(0xFF0F2E17), Color(0xFF6BFF8A), Color(0xFFB6FF6B), BackgroundStyle.AURORA_BLOBS, false),
        ThemeSpec("glassmorphism", "Glassmorphism", Color(0xFF0E1424), Color(0xFF1B2A4A), Color(0xFF9CC9FF), Color(0xFFB388FF), BackgroundStyle.AURORA_BLOBS, false),
        ThemeSpec("purple_fantasy", "Purple Fantasy", Color(0xFF120626), Color(0xFF2B0F55), Color(0xFFB26BFF), Color(0xFFFF6BD6), BackgroundStyle.COSMIC_NEBULA, false),
        ThemeSpec("rose", "Rose", Color(0xFF1A0A12), Color(0xFF3A1226), Color(0xFFFF6FA5), Color(0xFFFFB3D1), BackgroundStyle.PLAIN_GRADIENT, false),
        ThemeSpec("light_mode", "Light Mode", Color(0xFFF6F3EE), Color(0xFFE8E2D8), Color(0xFF6A4AFF), Color(0xFFB05A2A), BackgroundStyle.PLAIN_GRADIENT, true),
        ThemeSpec("follow_role", "Follow Role", Color(0xFF05070E), Color(0xFF141926), Color(0xFF8B5CF6), Color(0xFF00F5D4), BackgroundStyle.COSMIC_NEBULA, false, followsRole = true)
    )

    val voices: List<VoiceSpec> = listOf(
        VoiceSpec("v01", "Aarav Neural", "Indian English", "Calm & crisp", true),
        VoiceSpec("v02", "Ananya Warm", "Indian English", "Friendly platonic", true),
        VoiceSpec("v03", "Vikram Deep", "Indian English", "Steady baritone", true),
        VoiceSpec("v04", "Rohan Spark", "Hinglish", "Upbeat & fast", true),
        VoiceSpec("v05", "Meera Clear", "Hindi / EN", "Balanced & warm", true),
        VoiceSpec("v06", "Kabir Vibe", "Hinglish", "Casual & witty", true),
        VoiceSpec("v07", "Dr. Sen Sage", "Indian English", "Composed mentor", true),
        VoiceSpec("v08", "Tara Soft", "Hindi / EN", "Gentle & calm", true),
        VoiceSpec("v09", "Vivaan Studio", "Hindi (IN)", "Natural broadcast", true),
        VoiceSpec("v10", "Diya Breeze", "Hindi (IN)", "Bright conversational", true),
        VoiceSpec("v11", "Karan Pro", "Indian English", "Direct & fast", true),
        VoiceSpec("v12", "Neha Lyric", "Hindi / EN", "Expressive", true),
        VoiceSpec("v13", "Arjun Focus", "Indian English", "Study narrator", true),
        VoiceSpec("v14", "Priya Calm", "Indian English", "Mindful & slow", true),
        VoiceSpec("v15", "Siddharth", "Hindi (IN)", "Warm evening", true),
        VoiceSpec("v16", "Isha Spark", "Hinglish", "Cheerful", true),
        VoiceSpec("v17", "Orion Nova", "Global EN", "Precision HUD", false),
        VoiceSpec("v18", "Lyra Velvet", "Global EN", "Warm storyteller", false),
        VoiceSpec("v19", "Atlas Core", "Global EN", "Deep command", false),
        VoiceSpec("v20", "Zephyr Air", "Global EN", "Light & quick", false),
        VoiceSpec("v21", "Echo Pulse", "Global EN", "Crisp assistant", false),
        VoiceSpec("v22", "Sora Dawn", "Global EN", "Soft clarity", false),
        VoiceSpec("v23", "Kael Synth", "Global EN", "Cyber tech", false),
        VoiceSpec("v24", "Mira Glow", "Global EN", "Warm friend", false),
        VoiceSpec("v25", "Devansh", "Hindi (IN)", "Clear Devanagari", true),
        VoiceSpec("v26", "Kavya", "Hindi (IN)", "Soft Devanagari", true),
        VoiceSpec("v27", "Reyansh", "Hinglish", "Youthful tone", true),
        VoiceSpec("v28", "Aanya", "Indian English", "Clear tutor", true),
        VoiceSpec("v29", "Nikhil", "Indian English", "Crisp concise", true),
        VoiceSpec("v30", "Aditi", "Hindi / EN", "Balanced natural", true)
    )

    val providers: List<AiProviderSpec> = listOf(
        AiProviderSpec("gemini", "Gemini", true, listOf("gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.0-flash-live"), "gemini-2.5-flash", "AIzaSy-demo-configured-key", true, "aistudio.google.com"),
        AiProviderSpec("groq", "Groq", true, listOf("llama-3.3-70b-versatile", "mixtral-8x7b", "whisper-large-v3"), "llama-3.3-70b-versatile", "", null, "console.groq.com"),
        AiProviderSpec("openrouter", "OpenRouter", true, listOf("google/gemini-2.0-flash:free", "deepseek/deepseek-r1:free", "anthropic/claude-3.7-sonnet"), "google/gemini-2.0-flash:free", "", null, "openrouter.ai/keys"),
        AiProviderSpec("cerebras", "Cerebras", true, listOf("llama-3.3-70b", "qwen-3-32b"), "llama-3.3-70b", "", null, "cloud.cerebras.ai"),
        AiProviderSpec("mistral", "Mistral", true, listOf("mistral-small-latest", "codestral-latest"), "mistral-small-latest", "", null, "console.mistral.ai"),
        AiProviderSpec("openai", "OpenAI", false, listOf("gpt-4o-mini", "gpt-4o", "gpt-4o-realtime"), "gpt-4o-mini", "", null, "platform.openai.com")
    )

    val initialPermissions: List<PermissionStatus> = listOf(
        PermissionStatus("ai_key", "AI Provider Key", "Connects Jarvis to fast voice & reasoning.", true, "Verify Key"),
        PermissionStatus("mic", "Microphone", "Lets Jarvis hear your voice in English, Hindi, or Hinglish.", true, "Allow Mic"),
        PermissionStatus("accessibility", "Accessibility (Phone Control)", "Needed to unlock, tap, scroll, and automate games hands-free.", true, "Enable Accessibility"),
        PermissionStatus("overlay", "Display Over Other Apps", "Shows the floating orb, live captions, and game mini-HUD.", true, "Allow Overlay"),
        PermissionStatus("notifications", "Notification Access", "Reads WhatsApp & message alerts aloud cleanly.", true, "Grant Access"),
        PermissionStatus("battery", "Battery Unrestricted (Never Sleeping)", "Prevents Galaxy A50s OneUI from killing Jarvis in background.", false, "Set Never Sleeping"),
        PermissionStatus("device_extras", "Contacts, Phone, Camera, Location & Media", "Powers calls, WhatsApp lookup, Vision, and weather.", true, "Review Permissions"),
        PermissionStatus("lock_voice", "Screen-Lock Pattern & Voice Enrolment", "Optional hands-free unlock and speaker verification.", false, "Configure Pattern", optional = true)
    )

    val initialMessages: List<ChatMessage> = listOf(
        ChatMessage("m1", MessageKind.SYSTEM, "New WhatsApp message from Rahul: \"Bro BGMI squad ready?\"", "06:41 PM", RoleId.JARVIS, LanguageMode.HINGLISH),
        ChatMessage("m2", MessageKind.USER, "Jarvis, Rahul ko bol do 10 minute mein aa raha hoon, pehle physics notes bhej de.", "06:42 PM", RoleId.JARVIS, LanguageMode.HINGLISH),
        ChatMessage("m3", MessageKind.ASSISTANT, "Done. Rahul got your message on WhatsApp. Want me to launch BGMI Game Copilot or start your 25m focus sprint first?", "06:42 PM", RoleId.JARVIS, LanguageMode.EN),
        ChatMessage("m4", MessageKind.SYSTEM, "Task finished: Physics Revision Quiz prepared (5 questions)", "06:45 PM", RoleId.MENTOR, LanguageMode.EN),
        ChatMessage("m5", MessageKind.USER, "Pehle 25 minute ka study timer laga de, phir BGMI.", "06:46 PM", RoleId.MENTOR, LanguageMode.HINGLISH),
        ChatMessage("m6", MessageKind.ASSISTANT, "Ek second, check kar raha hoon. Study timer 25:00 ke liye ready hai—BGMI thermal boost queued after focus.", "06:46 PM", RoleId.MENTOR, LanguageMode.HINGLISH)
    )

    val sampleTasks: List<TaskItem> = listOf(
        TaskItem(
            id = "task_bgmi",
            title = "BGMI: Tactical Drop & 60fps Copilot",
            kind = TaskKind.GAME,
            steps = listOf(
                TaskStep("b1", "Clear RAM & lock 60fps Game Booster", TaskStepStatus.DONE),
                TaskStep("b2", "Enable floating tactical ping & DND", TaskStepStatus.DONE),
                TaskStep("b3", "Track Pochinki drop & footstep audio cues", TaskStepStatus.ACTIVE),
                TaskStep("b4", "Auto-clip chicken dinner highlight", TaskStepStatus.PENDING)
            ),
            status = TaskRunStatus.RUNNING,
            liveLine = "Erangel Zone 2 • Ping 24 ms • Squad 110m East",
            progress = 0.65f,
            startedAt = "06:40 PM",
            elapsedSeconds = 185,
            health = 100,
            hunger = 88,
            threat = "Squad East",
            gameBadge = "BGMI 60FPS"
        ),
        TaskItem(
            id = "task_ff",
            title = "Free Fire: Clash Squad & Sensitivity Assist",
            kind = TaskKind.GAME,
            steps = listOf(
                TaskStep("f1", "Apply custom headshot DPI & touch curve", TaskStepStatus.DONE),
                TaskStep("f2", "Silence WhatsApp popups via mini-HUD", TaskStepStatus.DONE),
                TaskStep("f3", "Monitor Gloo-Wall & Alok skill cooldown", TaskStepStatus.ACTIVE)
            ),
            status = TaskRunStatus.RUNNING,
            liveLine = "Bermuda CS Round 3 • Ping 19 ms • Shield 100%",
            progress = 0.72f,
            startedAt = "06:36 PM",
            elapsedSeconds = 112,
            health = 200,
            hunger = 100,
            threat = "Rush Left",
            gameBadge = "FREE FIRE"
        ),
        TaskItem(
            id = "task_mc",
            title = "Minecraft: Auto-Mine Diamonds",
            kind = TaskKind.GAME,
            steps = listOf(
                TaskStep("s1", "Equip iron pickaxe & torches", TaskStepStatus.DONE),
                TaskStep("s2", "Descend safely to Y -58", TaskStepStatus.DONE),
                TaskStep("s3", "Strip-mine 2x1 tunnel & scan ore", TaskStepStatus.ACTIVE),
                TaskStep("s4", "Return to chest & store loot", TaskStepStatus.PENDING)
            ),
            status = TaskRunStatus.RUNNING,
            liveLine = "Mining at Y -58 • Found 3 Redstone, scanning ahead",
            progress = 0.62f,
            startedAt = "06:38 PM",
            elapsedSeconds = 214,
            health = 18,
            hunger = 16,
            threat = "Low",
            gameBadge = "MINECRAFT"
        ),
        TaskItem(
            id = "task_unlock",
            title = "Hands-Free Unlock & Launch Workflow",
            kind = TaskKind.CREATE,
            steps = listOf(
                TaskStep("u1", "Verify Aadvik voice print", TaskStepStatus.DONE),
                TaskStep("u2", "Wake screen & execute 5-node swipe", TaskStepStatus.DONE),
                TaskStep("u3", "Open YouTube Music & set volume 70%", TaskStepStatus.DONE)
            ),
            status = TaskRunStatus.SUCCESS,
            liveLine = "Unlocked cleanly in 420 ms • Apps launched",
            progress = 1f,
            startedAt = "06:30 PM",
            elapsedSeconds = 4
        ),
        TaskItem(
            id = "task_wa",
            title = "WhatsApp: Share Lab PDF to Study Group",
            kind = TaskKind.MEDIA,
            steps = listOf(
                TaskStep("w1", "Locate Physics_Optics_Notes.pdf", TaskStepStatus.DONE),
                TaskStep("w2", "Open B.Tech CSE Sem 4 group", TaskStepStatus.DONE),
                TaskStep("w3", "Await user confirmation before send", TaskStepStatus.ACTIVE)
            ),
            status = TaskRunStatus.RUNNING,
            liveLine = "Ready to send 2.4 MB PDF to 42 members",
            progress = 0.80f,
            startedAt = "06:44 PM",
            elapsedSeconds = 28
        ),
        TaskItem(
            id = "task_ig",
            title = "Instagram: Post Evening Study Story",
            kind = TaskKind.SOCIAL,
            steps = listOf(
                TaskStep("i1", "Format 9:16 study desk card", TaskStepStatus.DONE),
                TaskStep("i2", "Apply Cosmic Nebula frame & caption", TaskStepStatus.DONE),
                TaskStep("i3", "Publish story to close friends", TaskStepStatus.DONE)
            ),
            status = TaskRunStatus.SUCCESS,
            liveLine = "Story posted cleanly • 14 views",
            progress = 1f,
            startedAt = "06:10 PM",
            elapsedSeconds = 42
        )
    )

    val initialInsights = InsightsData(
        syncScore = 98.4f,
        deltaLabel = "+4.2% this week",
        deepWorkLabel = "4h 32m",
        efficiencyPct = 85,
        streakDays = 9,
        sparkline = listOf(0.45f, 0.58f, 0.52f, 0.71f, 0.68f, 0.84f, 0.96f)
    )

    val initialWeather = WeatherWidgetData(
        tempC = 24,
        condition = "Clear Evening",
        highC = 29,
        lowC = 19,
        rainChancePct = 10,
        city = "New Delhi"
    )

    val initialToday = TodayWidgetData(
        dateLabel = "Thu, 12 Nov",
        nextEvent = "Data Structures Lab • 9:00 AM",
        nextAlarm = "Alarm 6:30 AM"
    )

    val initialMood = MoodWidgetData(
        label = "Focused & Calm",
        summary = "Steady study energy detected in chat",
        suggestedRoleId = RoleId.MENTOR
    )

    val initialBattery = BatteryWidgetData(
        percent = 78,
        isCharging = false,
        estimatedTime = "6h 40m left"
    )

    val initialReminders = ReminderWidgetData(
        items = listOf(
            ReminderItem("r1", "Send Physics Optics notes to Rahul", "7:15 PM"),
            ReminderItem("r2", "Submit DBMS assignment PDF", "10:00 PM")
        )
    )

    val initialMusic = MusicWidgetData(
        title = "Cosmic Lo-Fi Drift",
        artist = "Kairo Beats",
        isPlaying = true,
        progress = 0.42f,
        queue = listOf("Cosmic Lo-Fi Drift", "Starlight Hostel Vibes", "Monsoon Chai Acoustic", "Late Night Code Flow")
    )

    val initialDeviceStatus = DeviceStatusWidgetData(
        wifiOn = true,
        mobileDataOn = true,
        bluetoothOn = false
    )

    val initialQuickToggles = QuickTogglesData(
        flashlightOn = false,
        volumeHigh = true,
        dndOn = false
    )

    val initialJournalEntries = listOf(
        JournalEntry("j1", "Today • 6:30 PM", "Focused", "Cracked Graph Traversal", "Solved 4 BFS/DFS problems in 40 mins with Mentor mode. Need to revise Dijkstra tomorrow morning.", RoleId.MENTOR),
        JournalEntry("j2", "Yesterday • 9:15 PM", "Warm", "Late night chai with hostel wing", "Good break after lab submission. Kept phone on DND and slept by 11:30.", RoleId.COMPANION),
        JournalEntry("j3", "10 Nov • 4:20 PM", "Energized", "Squad win in BGMI + Portfolio build", "Used Jarvis Coding tab for portfolio and tested BGMI 60fps boost.", RoleId.BEST_FRIEND)
    )

    val studyQuizzes = listOf(
        StudyQuizCard(
            id = "q1",
            subject = "Algorithms",
            question = "What is the worst-case time complexity of Dijkstra's algorithm with a binary heap?",
            options = listOf("O(V + E)", "O((V + E) log V)", "O(V² log E)", "O(E²)"),
            correctIndex = 1
        ),
        StudyQuizCard(
            id = "q2",
            subject = "Operating Systems",
            question = "Which page replacement algorithm can suffer from Belady's anomaly?",
            options = listOf("LRU", "Optimal", "FIFO", "LFU"),
            correctIndex = 2
        )
    )

    val initialBuildHistory = listOf(
        BuildHistoryItem("b1", "Build a clean student Pomodoro & exam countdown web app", "FocusPulse Timer", "6:12 PM", "Single-page responsive timer with cosmic glass theme & task list", Color(0xFF8B5CF6)),
        BuildHistoryItem("b2", "Make a retro 2D snake arcade game with neon grid", "NeonSnake Mini", "Yesterday", "Canvas arcade loop with swipe controls & high-score storage", Color(0xFF00F5D4))
    )

    val initialCreatedArtifacts = listOf(
        CreatedArtifact("c1", CreateProjectType.RESUME, "Aadvik Kumar — B.Tech CSE Resume", "Clean Minimal", "1-page ATS layout with Android, Kotlin & DSA projects", "Today, 5:40 PM"),
        CreatedArtifact("c2", CreateProjectType.WEBSITE_GAME, "FocusPulse Study Timer", "Cosmic Nebula", "Interactive 25/5 Pomodoro web app with sound cues", "Today, 6:12 PM"),
        CreatedArtifact("c3", CreateProjectType.REPORT, "CN Lab: TCP Congestion Control", "Academic Serif", "6-section lab report with Reno vs Cubic summary", "Yesterday")
    )

    val initialDiagnostics = DiagnosticsData(
        connection = "Connected • 42 ms",
        modelName = "gemini-2.5-flash-live",
        lastError = "No recent errors. Last session ended cleanly.",
        micLevel = 0.28f,
        route = AudioRoute.SPEAKER,
        echoSuspected = false,
        halfDuplexMode = true,
        reconnectLog = listOf(
            "18:40:12 — Session ready (Speaker half-duplex guard active)",
            "18:22:05 — Resumed after Wi-Fi handoff (1.2s)",
            "17:58:44 — Voice engine warmed up on Galaxy A50s"
        )
    )

    val initialNotifications = listOf(
        AppNotificationItem("n1", "WhatsApp", "Rahul Sharma", "Bro BGMI squad ready?", "Just now"),
        AppNotificationItem("n2", "Telegram", "CSE Sem 4 Updates", "Lab viva moved to 10:30 AM tomorrow.", "4m ago"),
        AppNotificationItem("n3", "Instagram", "arjun.dev", "Mentioned you in a story", "12m ago")
    )

    val trendingSearches = listOf(
        TrendingSearchItem("tr1", "AI Agents 2026", "Tech Pulse", "Explain top autonomous AI agent workflows I can run on Android", "HOT #1"),
        TrendingSearchItem("tr2", "BGMI 3.6 Pro HUD", "Gaming", "Set optimal BGMI 60fps gyroscope & tactical drop callouts", "TRENDING"),
        TrendingSearchItem("tr3", "Free Fire One-Tap", "Gaming", "Optimize Free Fire sensitivity & clash squad callouts", "94K"),
        TrendingSearchItem("tr4", "DSA Graph Sprint", "Study", "Prepare 5-minute Graph Traversal & Dijkstra cheat sheet", "EXAM"),
        TrendingSearchItem("tr5", "Cosmic Reels Ideas", "Creator", "Generate 3 viral 9:16 tech reel scripts with hooks", "VIRAL"),
        TrendingSearchItem("tr6", "Zero-Lag Phone Boost", "System", "Scan background apps and tune Galaxy A50s battery + RAM", "A50s")
    )

    val initialSystemBridges = listOf(
        SystemBridgeNode("br_acc", "Accessibility Engine", "Tap, scroll, swipe & screen-unlock automation", 14, true),
        SystemBridgeNode("br_notif", "Notification Listener", "Reads WhatsApp, Telegram & Instagram aloud", 18, true),
        SystemBridgeNode("br_ocr", "Screen Vision OCR", "Reads screen context, PDFs & game HUD live", 32, true),
        SystemBridgeNode("br_wake", "Hands-Free Wake Core", "Hey Jarvis / Hinglish wake detection", 21, true),
        SystemBridgeNode("br_intents", "App Intents Router", "Deep links YouTube, Phone, Spotify & Camera", 11, true),
        SystemBridgeNode("br_gpu", "Mali-G72 60fps Lock", "Keeps thermals cool in BGMI & Free Fire", 8, true)
    )

    val humanWorkflows = listOf(
        HumanAutopilotWorkflow("hw1", "Morning & Evening Routine", "Reads unread WhatsApp, checks calendar & starts music", "Daily Life", "task_wa", "12s"),
        HumanAutopilotWorkflow("hw2", "BGMI 60fps Squad Copilot", "Locks 60fps, enables DND & calls out zone rotations", "Gaming", "task_bgmi", "LIVE"),
        HumanAutopilotWorkflow("hw3", "Free Fire Headshot HUD", "Applies touch sensitivity & silences popup alerts", "Gaming", "task_ff", "LIVE"),
        HumanAutopilotWorkflow("hw4", "Minecraft Auto-Miner", "Strips Y -58 safely & monitors HP / Lava threats", "Gaming", "task_mc", "AUTO"),
        HumanAutopilotWorkflow("hw5", "Hands-Free Unlock & App", "Voice-verifies Aadvik, swipes pattern & launches app", "System", "task_unlock", "0.4s"),
        HumanAutopilotWorkflow("hw6", "Instagram Cosmic Story", "Creates 9:16 study desk card & publishes after confirmation", "Social", "task_ig", "20s")
    )

    fun copy(key: String, lang: LanguageMode): String {
        val entry = strings[key] ?: return key
        return when (lang) {
            LanguageMode.EN -> entry.en
            LanguageMode.HI -> entry.hi
            LanguageMode.HINGLISH -> entry.hinglish
        }
    }

    private data class LocalizedTriple(val en: String, val hi: String, val hinglish: String)

    private val strings: Map<String, LocalizedTriple> = mapOf(
        "tagline" to LocalizedTriple("Think. Talk. Get things done.", "सोचो। बोलो। काम पूरा करो।", "Socho. Bolo. Kaam poora karo."),
        "greeting" to LocalizedTriple("Good evening, Aadvik", "शुभ संध्या, अद्विक", "Good evening, Aadvik"),
        "ready" to LocalizedTriple("Ready when you are.", "जब आप तैयार हों।", "Ready hoon, bolo."),
        "connecting" to LocalizedTriple("Connecting...", "जोड़ रहा हूँ...", "Connect kar raha hoon..."),
        "listening" to LocalizedTriple("I'm listening.", "मैं सुन रहा हूँ।", "Haan, sun raha hoon."),
        "thinking" to LocalizedTriple("One moment, thinking.", "एक पल, सोच रहा हूँ।", "Ek second, check kar raha hoon."),
        "speaking" to LocalizedTriple("Speaking", "बोल रहा हूँ", "Bol raha hoon"),
        "interrupted" to LocalizedTriple("Interrupted", "आपने रोका", "Ruk gaya, bolo"),
        "muted" to LocalizedTriple("Muted", "माइक म्यूट है", "Mic muted hai"),
        "error" to LocalizedTriple("Needs attention", "ध्यान दें", "Dikkat aayi hai"),
        "offline" to LocalizedTriple("Offline", "ऑफ़लाइन", "Internet band hai"),
        "mic_paused_banner" to LocalizedTriple("Mic paused while I talk", "मेरे बोलते समय माइक रुका है", "Bolte waqt mic paused hai"),
        "mic_paused_user" to LocalizedTriple("(mic paused)", "(माइक रुका है)", "(mic paused)"),
        "headphones_banner" to LocalizedTriple("Headphones: you can interrupt me", "हेडफ़ोन जुड़े हैं: आप रोक सकते हैं", "Headphones on: aap beech mein bol sakte ho"),
        "ask_placeholder" to LocalizedTriple("Ask Jarvis anything...", "जार्विस से कुछ भी पूछें...", "Bol, kya karna hai?"),
        "nav_home" to LocalizedTriple("Home", "होम", "Home"),
        "nav_chat" to LocalizedTriple("Chat", "चैट", "Chat"),
        "nav_talk" to LocalizedTriple("TALK", "बोलें", "TALK"),
        "nav_create" to LocalizedTriple("Create", "बनाएँ", "Create"),
        "nav_settings" to LocalizedTriple("Settings", "सेटिंग्स", "Settings"),
        "camera_empty" to LocalizedTriple("Press TALK first so I can see and answer live.", "पहले TALK दबाएँ ताकि मैं देखकर लाइव बता सकूँ।", "Pehle TALK dabao taaki main dekh ke bata sakoon."),
        "confirm_send" to LocalizedTriple("Want me to send it?", "क्या मैं इसे भेज दूँ?", "Bhej doon kya?")
    )
}
