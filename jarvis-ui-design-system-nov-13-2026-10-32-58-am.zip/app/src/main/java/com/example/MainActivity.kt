package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.MainTab
import com.example.model.SubScreen
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.JarvisTheme
import com.example.ui.theme.JarvisTypographyTokens
import com.example.ui.theme.LocalJarvisTokens
import com.example.ui.theme.ThemedBackground
import com.example.viewmodel.JarvisUiState
import com.example.viewmodel.JarvisViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: JarvisViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()
            val appContext = LocalContext.current.applicationContext
            val lifecycleOwner = LocalLifecycleOwner.current

            LaunchedEffect(appContext) {
                viewModel.bindSystemAutomation(appContext)
            }
            DisposableEffect(lifecycleOwner) {
                val observer = LifecycleEventObserver { _, event ->
                    if (event == Lifecycle.Event.ON_RESUME) {
                        viewModel.refreshSystemAutomation()
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)
                onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
            }

            JarvisTheme(
                theme = uiState.activeTheme,
                activeRole = uiState.activeRole,
                bgOverride = uiState.bgStyleOverride,
                cosmicIntensity = uiState.cosmicIntensity,
                glassFrost = uiState.glassFrost,
                fontScaleMultiplier = uiState.fontScaleMultiplier,
                reduceMotion = uiState.reduceMotion
            ) {
                ViewportFrameWrapper(
                    deviceFrameEnabled = uiState.deviceFrameEnabled,
                    viewportWidthDp = uiState.viewportWidthDp,
                    onToggleFrame = { viewModel.setDeviceFrameEnabled(!uiState.deviceFrameEnabled) },
                    onSelectWidth = { viewModel.setViewportWidth(it) }
                ) {
                    JarvisAppRoot(uiState = uiState, viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun JarvisAppRoot(
    uiState: JarvisUiState,
    viewModel: JarvisViewModel
) {
    val tokens = LocalJarvisTokens.current

    Box(modifier = Modifier.fillMaxSize()) {
        ThemedBackground()

        when {
            uiState.showSplash -> {
                SplashScreen(language = uiState.language)
            }
            uiState.showWelcomeScreen -> {
                WelcomeOpeningScreen(uiState = uiState, viewModel = viewModel)
            }
            uiState.showOnboarding -> {
                OnboardingScreen(uiState = uiState, viewModel = viewModel)
            }
            uiState.showCameraVision -> {
                CameraVisionScreen(uiState = uiState, viewModel = viewModel)
            }
            uiState.showLiveVoiceFullScreen -> {
                LiveVoiceFullScreen(uiState = uiState, viewModel = viewModel)
            }
            uiState.activeSubScreen != SubScreen.NONE -> {
                when (uiState.activeSubScreen) {
                    SubScreen.SETUP_WIZARD -> SetupWizardScreen(uiState = uiState, viewModel = viewModel)
                    SubScreen.DESIGN_SYSTEM -> DesignSystemScreen(uiState = uiState, viewModel = viewModel)
                    SubScreen.OVERLAY_ARTBOARD -> OverlayArtboardScreen(uiState = uiState, viewModel = viewModel)
                    SubScreen.JOURNAL_TIMELINE -> JournalTimelineScreen(uiState = uiState, viewModel = viewModel)
                    SubScreen.STUDY_MODE -> StudyModeScreen(uiState = uiState, viewModel = viewModel)
                    SubScreen.MUSIC_MODE -> MusicModeScreen(uiState = uiState, viewModel = viewModel)
                    SubScreen.COMMAND_CENTER -> CommandCenterScreen(uiState = uiState, viewModel = viewModel)
                    SubScreen.NONE -> Unit
                }
            }
            else -> {
                Crossfade(
                    targetState = uiState.selectedTab,
                    animationSpec = tween(if (uiState.reduceMotion) 0 else 220),
                    label = "tab_crossfade"
                ) { tab ->
                    when (tab) {
                        MainTab.HOME -> HomeScreen(uiState = uiState, viewModel = viewModel)
                        MainTab.CHAT -> ChatAndCodingScreen(uiState = uiState, viewModel = viewModel)
                        MainTab.CREATE -> CreateHubScreen(uiState = uiState, viewModel = viewModel)
                        MainTab.SETTINGS -> SettingsScreen(uiState = uiState, viewModel = viewModel)
                    }
                }
            }
        }

        // Persistent 5-slot Bottom Navigation on main tabs and non-fullscreen sub-screens
        val showBottomBar = !uiState.showSplash &&
            !uiState.showWelcomeScreen &&
            !uiState.showOnboarding &&
            !uiState.showLiveVoiceFullScreen &&
            !uiState.showCameraVision &&
            uiState.activeSubScreen != SubScreen.SETUP_WIZARD &&
            uiState.activeSubScreen != SubScreen.OVERLAY_ARTBOARD

        if (showBottomBar) {
            JarvisBottomNavigationBar(
                selectedTab = uiState.selectedTab,
                assistantState = uiState.assistantState,
                language = uiState.language,
                onSelectTab = { viewModel.selectTab(it) },
                onTalkPress = { viewModel.onTalkPressed() },
                onSwipeUpTalk = { viewModel.setLiveVoiceOpen(true) },
                modifier = Modifier.align(Alignment.BottomCenter)
            )
        }

        // Mission HUD Overlay
        if (uiState.showMissionHud) {
            MissionHudOverlay(uiState = uiState, viewModel = viewModel)
        }

        // Confirmation Sheet Overlay (30s countdown + No default focus)
        uiState.confirmationRequest?.let { req ->
            ConfirmationSheetOverlay(
                req = req,
                countdownSec = uiState.confirmCountdownSec,
                onResolve = { approved, skipFiveMin ->
                    viewModel.resolveConfirmation(approved, skipFiveMin)
                }
            )
        }

        // Role & Theme Bottom Sheets
        if (uiState.showRoleSheet) {
            RoleSelectionBottomSheet(uiState = uiState, viewModel = viewModel)
        }
        if (uiState.showThemeSheet) {
            ThemeSelectionBottomSheet(uiState = uiState, viewModel = viewModel)
        }

        // Hidden Debug Panel
        if (uiState.showDebugPanel) {
            DebugPanelDialog(uiState = uiState, viewModel = viewModel)
        }

        // Reusable J.A.R.V.I.S. Loading Screen Overlay
        uiState.loadingOverlayMessage?.let { statusText ->
            JarvisLoadingOverlay(
                statusText = statusText,
                onDismiss = { viewModel.dismissLoadingOverlay() }
            )
        }

        // Toast / Snackbar with Undo support for Mood Auto-Switch
        AnimatedVisibility(
            visible = uiState.toastMessage != null,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(180)),
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            uiState.toastMessage?.let { msg ->
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = tokens.surfaceElevatedTop,
                    border = BorderStroke(1.dp, tokens.accent.copy(alpha = 0.65f)),
                    shadowElevation = 14.dp
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        JarvisText(
                            text = msg,
                            style = JarvisTypographyTokens.Caption.copy(fontSize = 13.sp),
                            color = tokens.textPrimary,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        if (uiState.toastUndoRole != null) {
                            JarvisTertiaryButton(
                                text = "Undo",
                                onClick = { viewModel.undoRoleSwitch() }
                            )
                        }
                    }
                }
            }
        }
    }
}
