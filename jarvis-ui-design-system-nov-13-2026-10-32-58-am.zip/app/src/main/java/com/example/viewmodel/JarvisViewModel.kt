package com.example.viewmodel

import android.content.Context
import android.provider.Settings
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.automation.*
import com.example.data.MockData
import com.example.model.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class JarvisUiState(
    val showSplash: Boolean = true,
    val showWelcomeScreen: Boolean = true,
    val showOnboarding: Boolean = false,
    val isRefreshing: Boolean = false,
    val loadingOverlayMessage: String? = null,
    val onboardingPage: Int = 0,
    val selectedTab: MainTab = MainTab.HOME,
    val activeSubScreen: SubScreen = SubScreen.NONE,
    val showLiveVoiceFullScreen: Boolean = false,
    val showCameraVision: Boolean = false,
    val showRoleSheet: Boolean = false,
    val showThemeSheet: Boolean = false,
    val showDebugPanel: Boolean = false,
    val showMissionHud: Boolean = false,
    val confirmationRequest: ConfirmationRequest? = null,
    val confirmCountdownSec: Int = 30,
    val dontAskFiveMinLowRisk: Boolean = false,
    val toastMessage: String? = null,
    val toastUndoRole: RoleId? = null,

    // Core theme, role, accessibility & localization
    val activeRole: Role = MockData.roles.first(),
    val activeTheme: ThemeSpec = MockData.themes.first(),
    val bgStyleOverride: BackgroundStyle? = null,
    val cosmicIntensity: CosmicIntensity = CosmicIntensity.BALANCED,
    val glassFrost: Float = 0.80f,
    val language: LanguageMode = LanguageMode.EN,
    val fontScaleMultiplier: Float = 1.0f,
    val reduceMotion: Boolean = false,
    val deviceFrameEnabled: Boolean = false,
    val viewportWidthDp: Int = 412,

    // Voice & feedback-loop protection
    val assistantState: AssistantState = AssistantState.IDLE,
    val lastCaptionUser: String = "Hey Jarvis, check my physics notes and remind Rahul.",
    val lastCaptionJarvis: String = "Ready when you are. Everything is synced for your evening study.",
    val isMuted: Boolean = false,
    val quickMode: QuickMode = QuickMode.OFF,
    val autoSwitchRole: Boolean = true,
    val emotionStyle: String = "Balanced Natural",
    val replyPauseSec: Float = 1.2f,
    val selectedVoiceId: String = "v01",
    val perRoleVoices: Map<RoleId, String> = MockData.roles.associate { it.id to it.voiceName },

    // Edge / Error banner state (7.15)
    val edgeBanner: EdgeErrorBanner = EdgeErrorBanner.NONE,
    val reconnectCountdownSec: Int = 5,

    // Setup Wizard (8 steps)
    val wizardStepIndex: Int = 0,
    val wizardFinished: Boolean = false,
    val permissions: List<PermissionStatus> = MockData.initialPermissions,

    // Widgets (7.14) + Insights + Deep System Bridges
    val insights: InsightsData = MockData.initialInsights,
    val useCosmicJarvisPortrait: Boolean = true,
    val use3dCharacter: Boolean = true,
    val systemBridges: List<SystemBridgeNode> = MockData.initialSystemBridges,
    val weather: WeatherWidgetData = MockData.initialWeather,
    val today: TodayWidgetData = MockData.initialToday,
    val mood: MoodWidgetData = MockData.initialMood,
    val battery: BatteryWidgetData = MockData.initialBattery,
    val reminders: ReminderWidgetData = MockData.initialReminders,
    val music: MusicWidgetData = MockData.initialMusic,
    val deviceStatus: DeviceStatusWidgetData = MockData.initialDeviceStatus,
    val quickToggles: QuickTogglesData = MockData.initialQuickToggles,

    // Chat & Coding (7.5) + Real Attachments
    val chatMessages: List<ChatMessage> = MockData.initialMessages,
    val pendingAttachments: List<ChatAttachment> = emptyList(),
    val isAssistantTyping: Boolean = false,
    val chatTabMode: Int = 0, // 0 = Chat, 1 = Coding
    val codingPrompt: String = "",
    val isBuildingCode: Boolean = false,
    val buildHistory: List<BuildHistoryItem> = MockData.initialBuildHistory,
    val activePreviewBuild: BuildHistoryItem? = MockData.initialBuildHistory.firstOrNull(),

    // Create Hub & Modes (7.6, 7.13)
    val createdArtifacts: List<CreatedArtifact> = MockData.initialCreatedArtifacts,
    val journalEntries: List<JournalEntry> = MockData.initialJournalEntries,
    val studySecondsLeft: Int = 25 * 60,
    val studyRunning: Boolean = false,
    val studyStreakDays: Int = 9,
    val quizIndex: Int = 0,
    val quizSelectedOption: Int? = null,

    // Missions (7.7)
    val activeMission: TaskItem = MockData.sampleTasks.first(),

    // Camera Vision (7.9)
    val cameraFacingBack: Boolean = true,
    val cameraCaption: String = "Tap 'Describe what you see' while a voice session is active.",

    // Settings (7.11)
    val providers: List<AiProviderSpec> = MockData.providers,
    val selectedProviderId: String = "gemini",
    val diagnostics: DiagnosticsData = MockData.initialDiagnostics,
    val customAvatarSlots: List<String?> = listOf("Portrait Crop", null, null, null),
    val avatarRemoveBg: Boolean = true,
    val savedPattern: List<Int> = listOf(0, 1, 2, 5, 8),
    val patternSpeedMs: Float = 420f,
    val patternScale: Float = 1.0f,
    val patternTestResult: String? = null,
    val notificationsEnabled: Boolean = true,
    val appNotificationToggles: Map<String, Boolean> = mapOf(
        "WhatsApp" to true,
        "Telegram" to true,
        "Instagram" to false,
        "Messages" to true,
        "Gmail" to false
    ),
    val savedAccounts: Map<String, Boolean> = mapOf(
        "YouTube" to true,
        "Instagram" to true,
        "Facebook" to false,
        "Telegram" to true
    ),
    val saveConversations: Boolean = true,
    val voiceLockEnrolled: Boolean = false,
    val overlayNotifications: List<AppNotificationItem> = MockData.initialNotifications,

    // Real System-Level Automation Runtime State
    val automation: AutomationRuntimeState = AutomationRuntimeState()
) {
    val micState: MicState
        get() = when {
            isMuted || assistantState == AssistantState.MUTED -> MicState.MUTED
            edgeBanner == EdgeErrorBanner.MIC_BUSY || edgeBanner == EdgeErrorBanner.PERMISSION_DENIED -> MicState.BLOCKED
            assistantState == AssistantState.SPEAKING &&
                diagnostics.route == AudioRoute.SPEAKER &&
                diagnostics.halfDuplexMode -> MicState.PAUSED
            else -> MicState.LIVE
        }
}

class JarvisViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(JarvisUiState())
    val uiState: StateFlow<JarvisUiState> = _uiState.asStateFlow()

    private var voiceCycleJob: Job? = null
    private var confirmJob: Job? = null
    private var missionJob: Job? = null
    private var studyJob: Job? = null
    private var reconnectJob: Job? = null
    private var toastJob: Job? = null
    private var automationObserveJob: Job? = null
    private var automationManager: SystemAutomationManager? = null

    init {
        viewModelScope.launch {
            delay(2200L)
            _uiState.update { it.copy(showSplash = false) }
        }
        // Subtle simulated mic level oscillation
        viewModelScope.launch {
            var tick = 0
            while (true) {
                delay(450L)
                tick++
                _uiState.update { st ->
                    val targetMic = when (st.micState) {
                        MicState.MUTED, MicState.PAUSED, MicState.BLOCKED -> 0.04f
                        MicState.LIVE -> if (st.assistantState == AssistantState.LISTENING) {
                            0.38f + ((tick % 5) * 0.12f)
                        } else {
                            0.14f + ((tick % 3) * 0.06f)
                        }
                    }
                    st.copy(diagnostics = st.diagnostics.copy(micLevel = targetMic))
                }
            }
        }
    }

    fun bindSystemAutomation(context: Context) {
        val existing = automationManager
        if (existing != null) {
            existing.refreshStatus()
            return
        }
        val manager = SystemAutomationManager(context.applicationContext)
        automationManager = manager
        automationObserveJob?.cancel()
        automationObserveJob = viewModelScope.launch {
            manager.runtimeState.collect { autoState ->
                _uiState.update { st ->
                    val syncedPerms = st.permissions.map { p ->
                        when (p.key) {
                            "accessibility" -> p.copy(granted = autoState.accessibilityEnabled)
                            "notifications" -> p.copy(granted = autoState.notificationListenerEnabled)
                            else -> p
                        }
                    }
                    val syncedBridges = st.systemBridges.map { br ->
                        when (br.id) {
                            "br_acc" -> br.copy(connected = autoState.accessibilityEnabled)
                            "br_notif" -> br.copy(connected = autoState.notificationListenerEnabled)
                            else -> br
                        }
                    }
                    val mergedNotifications = if (autoState.liveNotifications.isNotEmpty()) {
                        autoState.liveNotifications.map { n ->
                            AppNotificationItem(
                                id = n.key,
                                appName = n.appLabel,
                                sender = n.sender,
                                text = n.text,
                                time = n.time
                            )
                        }
                    } else {
                        st.overlayNotifications
                    }
                    st.copy(
                        automation = autoState,
                        permissions = syncedPerms,
                        systemBridges = syncedBridges,
                        overlayNotifications = mergedNotifications,
                        quickToggles = if (autoState.dndPolicyGranted) {
                            st.quickToggles.copy(dndOn = autoState.dndActive)
                        } else {
                            st.quickToggles
                        }
                    )
                }
            }
        }
    }

    fun refreshSystemAutomation() {
        automationManager?.refreshStatus()
    }

    fun launchSystemApp(appId: String) {
        val mgr = automationManager
        if (mgr == null) {
            showToast("Automation engine initializing...")
            return
        }
        val result = mgr.launchTargetApp(appId, openStoreIfMissing = true)
        showToast(result.message)
    }

    fun executeScreenLock() {
        val mgr = automationManager
        if (mgr == null) {
            showToast("Automation engine initializing...")
            return
        }
        val result = mgr.lockScreen()
        showToast(result.message)
    }

    fun executeUnlockGesture() {
        val mgr = automationManager ?: return
        val st = _uiState.value
        val result = mgr.runPatternUnlockGesture(
            nodes = st.savedPattern,
            speedMs = st.patternSpeedMs,
            padScale = st.patternScale
        )
        showToast(result.message)
    }

    fun openSystemNotificationShade() {
        val mgr = automationManager ?: return
        val result = mgr.openNotificationShade()
        showToast(result.message)
    }

    fun clearAllSystemNotifications() {
        val mgr = automationManager ?: return
        val result = mgr.clearAllNotifications()
        showToast(result.message)
    }

    fun dismissLiveNotification(key: String) {
        val mgr = automationManager
        if (mgr != null && mgr.runtimeState.value.notificationListenerEnabled) {
            val result = mgr.dismissNotification(key)
            showToast(result.message)
        } else {
            dismissOverlayNotification(key)
        }
    }

    fun openAutomationSettings(action: String) {
        automationManager?.openSystemSettings(action)
    }

    fun dismissWelcomeScreen(startOnboarding: Boolean = false) {
        _uiState.update {
            it.copy(
                showWelcomeScreen = false,
                showOnboarding = startOnboarding,
                onboardingPage = 0
            )
        }
    }

    fun openWelcomeScreen() {
        _uiState.update { it.copy(showWelcomeScreen = true, showDebugPanel = false) }
    }

    fun triggerLoadingPreview() {
        _uiState.update {
            it.copy(
                showDebugPanel = false,
                loadingOverlayMessage = "J.A.R.V.I.S. NEURAL CORE • SYNCING MODULES..."
            )
        }
        viewModelScope.launch {
            delay(1900L)
            automationManager?.refreshStatus()
            _uiState.update { it.copy(loadingOverlayMessage = null) }
            showToast("J.A.R.V.I.S. systems calibrated cleanly!")
        }
    }

    fun dismissLoadingOverlay() {
        _uiState.update { it.copy(loadingOverlayMessage = null) }
    }

    fun refreshPage(sourceLabel: String = "Workspace") {
        if (_uiState.value.isRefreshing) return
        _uiState.update { it.copy(isRefreshing = true) }
        viewModelScope.launch {
            automationManager?.refreshStatus()
            delay(850L)
            _uiState.update { st ->
                val boostedSync = (st.insights.syncScore + 0.1f).coerceAtMost(99.9f)
                st.copy(
                    isRefreshing = false,
                    insights = st.insights.copy(syncScore = (boostedSync * 10).toInt() / 10f),
                    diagnostics = st.diagnostics.copy(connection = "Synced just now • 24 ms")
                )
            }
            showToast("$sourceLabel refreshed cleanly.")
        }
    }

    fun dismissOnboarding(startWizard: Boolean) {
        _uiState.update {
            it.copy(
                showOnboarding = false,
                activeSubScreen = if (startWizard) SubScreen.SETUP_WIZARD else SubScreen.NONE
            )
        }
    }

    fun setOnboardingPage(page: Int) {
        _uiState.update { it.copy(onboardingPage = page.coerceIn(0, 3)) }
    }

    fun openOnboarding() {
        _uiState.update { it.copy(showOnboarding = true, onboardingPage = 0, showDebugPanel = false) }
    }

    fun selectTab(tab: MainTab) {
        _uiState.update {
            it.copy(
                selectedTab = tab,
                activeSubScreen = SubScreen.NONE,
                showLiveVoiceFullScreen = false,
                showCameraVision = false
            )
        }
    }

    fun openSubScreen(subScreen: SubScreen) {
        _uiState.update {
            it.copy(
                activeSubScreen = subScreen,
                showLiveVoiceFullScreen = false,
                showCameraVision = false,
                showDebugPanel = false
            )
        }
    }

    fun closeSubScreen() {
        _uiState.update { it.copy(activeSubScreen = SubScreen.NONE) }
    }

    fun onTalkPressed() {
        val current = _uiState.value
        when (current.assistantState) {
            AssistantState.SPEAKING, AssistantState.THINKING, AssistantState.LISTENING, AssistantState.CONNECTING -> {
                stopVoiceSession()
            }
            else -> startVoiceSession(openFullScreen = true)
        }
    }

    fun startVoiceSession(openFullScreen: Boolean = true) {
        voiceCycleJob?.cancel()
        if (_uiState.value.edgeBanner == EdgeErrorBanner.NO_INTERNET) {
            _uiState.update { it.copy(assistantState = AssistantState.OFFLINE) }
            showToast("Offline — check Wi-Fi or 5G.")
            return
        }
        voiceCycleJob = viewModelScope.launch {
            _uiState.update {
                it.copy(
                    assistantState = AssistantState.CONNECTING,
                    showLiveVoiceFullScreen = openFullScreen,
                    isMuted = false
                )
            }
            delay(500L)
            _uiState.update {
                it.copy(
                    assistantState = AssistantState.LISTENING,
                    lastCaptionUser = when (it.language) {
                        LanguageMode.HI -> "जार्विस, आज की फिजिक्स क्लास के नोट्स और टाइमर सेट करो।"
                        LanguageMode.HINGLISH -> "Jarvis, Rahul ko notes bhej do aur 25 min study timer lagao."
                        LanguageMode.EN -> "Jarvis, summarize today's schedule and check WhatsApp."
                    }
                )
            }
            delay(2600L)
            _uiState.update { it.copy(assistantState = AssistantState.THINKING) }
            delay(1400L)
            _uiState.update {
                it.copy(
                    assistantState = AssistantState.SPEAKING,
                    lastCaptionJarvis = when (it.language) {
                        LanguageMode.HI -> "हो गया। आपका स्टडी टाइमर तैयार है और राहुल को संदेश भेजने के लिए पूछ रहा हूँ।"
                        LanguageMode.HINGLISH -> "Ek second—25 min study timer ready hai. Rahul ko WhatsApp bhejne se pehle confirm kar loon?"
                        LanguageMode.EN -> "All set. Your 25-minute focus timer is ready, and Rahul's WhatsApp draft awaits your tap."
                    }
                )
            }
            delay(3600L)
            _uiState.update { it.copy(assistantState = AssistantState.IDLE) }
        }
    }

    fun stopVoiceSession() {
        voiceCycleJob?.cancel()
        _uiState.update {
            it.copy(
                assistantState = AssistantState.IDLE,
                showLiveVoiceFullScreen = false
            )
        }
    }

    fun simulateUserInterrupt() {
        val st = _uiState.value
        if (st.assistantState != AssistantState.SPEAKING) return
        if (st.diagnostics.route == AudioRoute.SPEAKER && st.diagnostics.halfDuplexMode) {
            showToast("Half-duplex active on speaker. Connect headphones to interrupt.")
            return
        }
        voiceCycleJob?.cancel()
        voiceCycleJob = viewModelScope.launch {
            // Stops within 150ms per Section 8
            _uiState.update {
                it.copy(
                    assistantState = AssistantState.INTERRUPTED,
                    lastCaptionUser = "Wait—just open Study mode first.",
                    lastCaptionJarvis = "Got it, switching right away."
                )
            }
            delay(900L)
            _uiState.update { it.copy(assistantState = AssistantState.LISTENING) }
        }
    }

    fun toggleMute() {
        _uiState.update {
            val nextMuted = !it.isMuted
            it.copy(
                isMuted = nextMuted,
                assistantState = if (nextMuted) AssistantState.MUTED else AssistantState.IDLE
            )
        }
    }

    fun setLiveVoiceOpen(open: Boolean) {
        _uiState.update { it.copy(showLiveVoiceFullScreen = open) }
    }

    fun setCameraVisionOpen(open: Boolean) {
        _uiState.update { it.copy(showCameraVision = open) }
    }

    fun flipCamera() {
        _uiState.update { it.copy(cameraFacingBack = !it.cameraFacingBack) }
    }

    fun describeCameraScene() {
        if (_uiState.value.assistantState == AssistantState.IDLE) {
            showToast(MockData.copy("camera_empty", _uiState.value.language))
            return
        }
        _uiState.update {
            it.copy(
                cameraCaption = "I see a physics textbook open to Wave Optics (Young's double-slit diagram) beside a mechanical keyboard and water bottle."
            )
        }
    }

    fun selectRole(roleId: RoleId, isAutoSwitch: Boolean = false) {
        val previous = _uiState.value.activeRole.id
        val next = MockData.roles.firstOrNull { it.id == roleId } ?: return
        _uiState.update {
            it.copy(
                activeRole = next,
                showRoleSheet = false
            )
        }
        if (isAutoSwitch && previous != roleId) {
            showToast("Switched to ${next.name}", undoRole = previous)
        }
    }

    fun swipeRole(delta: Int) {
        val list = MockData.roles
        val idx = list.indexOfFirst { it.id == _uiState.value.activeRole.id }
        val nextIdx = (idx + delta + list.size) % list.size
        selectRole(list[nextIdx].id, isAutoSwitch = false)
    }

    fun toggleCosmicJarvisPortrait() {
        _uiState.update { it.copy(useCosmicJarvisPortrait = !it.useCosmicJarvisPortrait) }
    }

    fun toggle3dCharacter() {
        _uiState.update { it.copy(use3dCharacter = !it.use3dCharacter) }
        showToast(if (_uiState.value.use3dCharacter) "3D Holographic Character active" else "Anime Portrait look active")
    }

    fun setCosmicIntensity(intensity: CosmicIntensity) {
        _uiState.update { it.copy(cosmicIntensity = intensity) }
    }

    fun setGlassFrost(alpha: Float) {
        _uiState.update { it.copy(glassFrost = alpha.coerceIn(0.45f, 0.96f)) }
    }

    fun toggleSystemBridge(id: String) {
        val mgr = automationManager
        if (mgr != null) {
            when (id) {
                "br_acc" -> {
                    mgr.openSystemSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    showToast("Manage Accessibility in Android Settings.")
                    return
                }
                "br_notif" -> {
                    mgr.openSystemSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    showToast("Manage Notification Listener in Android Settings.")
                    return
                }
            }
        }
        _uiState.update { st ->
            st.copy(
                systemBridges = st.systemBridges.map { node ->
                    if (node.id == id) node.copy(connected = !node.connected) else node
                }
            )
        }
    }

    fun launchTrendingSearch(item: TrendingSearchItem) {
        selectTab(MainTab.CHAT)
        setChatTabMode(0)
        sendChatMessage("[${item.category}] ${item.query}")
    }

    fun addAttachment(attachment: ChatAttachment) {
        _uiState.update { it.copy(pendingAttachments = (it.pendingAttachments + attachment).take(4)) }
        showToast("Attached ${attachment.kind.label}: ${attachment.label}")
    }

    fun removeAttachment(id: String) {
        _uiState.update { st ->
            st.copy(pendingAttachments = st.pendingAttachments.filterNot { it.id == id })
        }
    }

    fun launchTaskById(taskId: String) {
        val task = MockData.sampleTasks.firstOrNull { it.id == taskId } ?: MockData.sampleTasks.first()
        openMissionHud(task)
    }

    fun selectTheme(themeId: String) {
        val next = MockData.themes.firstOrNull { it.id == themeId } ?: return
        _uiState.update { it.copy(activeTheme = next, bgStyleOverride = null, showThemeSheet = false) }
    }

    fun setBackgroundOverride(style: BackgroundStyle?) {
        _uiState.update { it.copy(bgStyleOverride = style) }
    }

    fun setRoleSheetVisible(visible: Boolean) {
        _uiState.update { it.copy(showRoleSheet = visible) }
    }

    fun setThemeSheetVisible(visible: Boolean) {
        _uiState.update { it.copy(showThemeSheet = visible) }
    }

    fun setDebugPanelVisible(visible: Boolean) {
        _uiState.update { it.copy(showDebugPanel = visible) }
    }

    fun setAssistantStateDirect(state: AssistantState) {
        voiceCycleJob?.cancel()
        _uiState.update {
            it.copy(
                assistantState = state,
                isMuted = state == AssistantState.MUTED
            )
        }
    }

    fun setLanguage(language: LanguageMode) {
        _uiState.update { it.copy(language = language) }
    }

    fun setFontScale(scale: Float) {
        _uiState.update { it.copy(fontScaleMultiplier = scale.coerceIn(0.95f, 1.35f)) }
    }

    fun setReduceMotion(reduce: Boolean) {
        _uiState.update { it.copy(reduceMotion = reduce) }
    }

    fun setDeviceFrameEnabled(enabled: Boolean) {
        _uiState.update { it.copy(deviceFrameEnabled = enabled) }
    }

    fun setViewportWidth(widthDp: Int) {
        _uiState.update { it.copy(viewportWidthDp = widthDp) }
    }

    fun selectQuickMode(mode: QuickMode) {
        _uiState.update { it.copy(quickMode = mode) }
        when (mode) {
            QuickMode.MUSIC -> openSubScreen(SubScreen.MUSIC_MODE)
            QuickMode.STUDY -> openSubScreen(SubScreen.STUDY_MODE)
            QuickMode.JOURNAL -> openSubScreen(SubScreen.JOURNAL_TIMELINE)
            QuickMode.DOCUMENTS -> selectTab(MainTab.CREATE)
            QuickMode.OFF -> Unit
        }
    }

    fun triggerQuickAction(action: String) {
        val mgr = automationManager
        when (action) {
            "Unlock" -> {
                if (mgr != null) {
                    val res = mgr.runPatternUnlockGesture(
                        nodes = _uiState.value.savedPattern,
                        speedMs = _uiState.value.patternSpeedMs,
                        padScale = _uiState.value.patternScale
                    )
                    if (!res.success && res.openedSettingsAction != null) {
                        setEdgeBanner(EdgeErrorBanner.ACCESSIBILITY_OFF)
                    }
                    showToast(res.message)
                } else {
                    val accOk = _uiState.value.permissions.firstOrNull { it.key == "accessibility" }?.granted == true
                    if (!accOk) setEdgeBanner(EdgeErrorBanner.ACCESSIBILITY_OFF)
                    else showToast("Screen unlock gesture verified cleanly.")
                }
            }
            "Lock" -> executeScreenLock()
            "Call" -> requestConfirmation("Call Mom (Mobile)", "+91 98XXX XX412 • Speaker off", false, "call")
            "WhatsApp" -> requestConfirmation("Send WhatsApp message to Rahul", "\"Hey, sending Physics Optics PDF in 2 mins!\"", true, "send")
            "YouTube" -> {
                if (mgr != null) {
                    val res = mgr.launchTargetApp("app_youtube")
                    showToast(res.message)
                } else {
                    showToast("Opening YouTube • DSA Revision Playlist")
                }
            }
            "Camera" -> setCameraVisionOpen(true)
            "Flashlight" -> toggleFlashlight()
            "Timer" -> {
                openSubScreen(SubScreen.STUDY_MODE)
                toggleStudyTimer(forceStart = true)
            }
            "Screenshot" -> {
                if (mgr != null) {
                    val res = mgr.takeScreenshot()
                    showToast(res.message)
                } else {
                    showToast("Screenshot saved to Pictures/Jarvis")
                }
            }
        }
    }

    fun requestConfirmation(title: String, target: String, isLowRisk: Boolean, type: String) {
        if (isLowRisk && _uiState.value.dontAskFiveMinLowRisk) {
            showToast("Done. $title completed (5-min skip active).")
            return
        }
        confirmJob?.cancel()
        _uiState.update {
            it.copy(
                confirmationRequest = ConfirmationRequest(
                    id = "conf_${System.currentTimeMillis()}",
                    actionTitle = title,
                    targetDescription = target,
                    isLowRisk = isLowRisk,
                    actionType = type
                ),
                confirmCountdownSec = 30
            )
        }
        confirmJob = viewModelScope.launch {
            for (sec in 29 downTo 0) {
                delay(1000L)
                _uiState.update { it.copy(confirmCountdownSec = sec) }
            }
            _uiState.update { it.copy(confirmationRequest = null) }
            showToast("Timed out safely — action cancelled.")
        }
    }

    fun resolveConfirmation(approved: Boolean, skipFiveMin: Boolean) {
        confirmJob?.cancel()
        val req = _uiState.value.confirmationRequest
        _uiState.update {
            it.copy(
                confirmationRequest = null,
                dontAskFiveMinLowRisk = if (approved && skipFiveMin) true else it.dontAskFiveMinLowRisk
            )
        }
        if (approved && req != null) {
            showToast("Done. ${req.actionTitle} completed.")
        } else {
            showToast("Cancelled. Nothing was sent.")
        }
    }

    fun sendChatMessage(rawText: String) {
        val text = rawText.trim()
        val attached = _uiState.value.pendingAttachments
        if (text.isEmpty() && attached.isEmpty()) return
        val displayPrompt = text.ifEmpty { "Analyze attached ${attached.joinToString(", ") { it.kind.label.lowercase() }}" }
        val role = _uiState.value.activeRole
        val userMsg = ChatMessage(
            id = "u_${System.currentTimeMillis()}",
            kind = MessageKind.USER,
            text = displayPrompt,
            time = "Now",
            roleId = role.id,
            language = _uiState.value.language,
            attachments = attached
        )
        _uiState.update {
            it.copy(
                chatMessages = it.chatMessages + userMsg,
                pendingAttachments = emptyList(),
                isAssistantTyping = true
            )
        }

        // Mood auto-switch demonstration (Section 6)
        val lower = displayPrompt.lowercase()
        val autoTarget: RoleId? = if (_uiState.value.autoSwitchRole) {
            when {
                "stress" in lower || "angry" in lower || "exam" in lower -> RoleId.MENTOR
                "sad" in lower || "tired" in lower || "down" in lower -> RoleId.LISTENER
                "joke" in lower || "meme" in lower || "game" in lower || "bgmi" in lower || "free fire" in lower -> RoleId.BEST_FRIEND
                "thank" in lower || "miss" in lower -> RoleId.COMPANION
                else -> null
            }
        } else null

        val executedAutomationNote = handleNaturalLanguageAutomation(lower)

        viewModelScope.launch {
            delay(800L)
            if (autoTarget != null && autoTarget != _uiState.value.activeRole.id) {
                selectRole(autoTarget, isAutoSwitch = true)
            }
            val currentRole = _uiState.value.activeRole
            val attachmentSummary = if (attached.isNotEmpty()) {
                val names = attached.joinToString(", ") { "${it.kind.label} (${it.label})" }
                "I inspected $names directly on-device. "
            } else ""
            val autoPrefix = if (executedAutomationNote != null) "[$executedAutomationNote] " else ""
            val replyText = when (_uiState.value.language) {
                LanguageMode.HI -> "${autoPrefix}${attachmentSummary}समझ गया। ${currentRole.name} मोड में काम पूरा कर रहा हूँ।"
                LanguageMode.HINGLISH -> "${autoPrefix}${attachmentSummary}Samajh gaya! ${currentRole.name} style mein check kar liya—sab ready hai."
                LanguageMode.EN -> "${autoPrefix}${attachmentSummary}Got it. Handling \"$displayPrompt\" cleanly with system automation in ${currentRole.name} mode."
            }
            val aiMsg = ChatMessage(
                id = "a_${System.currentTimeMillis()}",
                kind = MessageKind.ASSISTANT,
                text = replyText,
                time = "Now",
                roleId = currentRole.id,
                language = _uiState.value.language
            )
            _uiState.update {
                it.copy(
                    chatMessages = it.chatMessages + aiMsg,
                    isAssistantTyping = false,
                    lastCaptionUser = displayPrompt,
                    lastCaptionJarvis = replyText
                )
            }
        }
    }

    private fun handleNaturalLanguageAutomation(lower: String): String? {
        val mgr = automationManager ?: return null
        val wantsOpen = listOf("open", "launch", "start", "play", "kholo", "chalao").any { it in lower }
        return when {
            wantsOpen && ("bgmi" in lower || "pubg" in lower) -> mgr.launchTargetApp("app_bgmi").message
            wantsOpen && "minecraft" in lower -> mgr.launchTargetApp("app_minecraft").message
            wantsOpen && "free fire" in lower -> mgr.launchTargetApp("app_freefire").message
            wantsOpen && "youtube" in lower -> mgr.launchTargetApp("app_youtube").message
            wantsOpen && "whatsapp" in lower -> mgr.launchTargetApp("app_whatsapp").message
            wantsOpen && "telegram" in lower -> mgr.launchTargetApp("app_telegram").message
            "lock screen" in lower || "lock my screen" in lower || "lock phone" in lower -> mgr.lockScreen().message
            "unlock" in lower && ("screen" in lower || "phone" in lower || "pattern" in lower) -> {
                val st = _uiState.value
                mgr.runPatternUnlockGesture(st.savedPattern, st.patternSpeedMs, st.patternScale).message
            }
            "clear notification" in lower || "clear all notification" in lower -> mgr.clearAllNotifications().message
            "open notification" in lower || "show notification" in lower || "notification shade" in lower -> mgr.openNotificationShade().message
            "turn on dnd" in lower || "enable dnd" in lower || "dnd on" in lower -> mgr.setDoNotDisturb(true).message
            "turn off dnd" in lower || "disable dnd" in lower || "dnd off" in lower -> mgr.setDoNotDisturb(false).message
            "screenshot" in lower && ("take" in lower || "capture" in lower) -> mgr.takeScreenshot().message
            else -> null
        }
    }

    fun saveMessageToJournal(msgId: String) {
        val msg = _uiState.value.chatMessages.firstOrNull { it.id == msgId } ?: return
        val newEntry = JournalEntry(
            id = "j_${System.currentTimeMillis()}",
            dateLabel = "Today • Just now",
            mood = _uiState.value.activeRole.name,
            title = "Saved Note from Chat",
            body = msg.text,
            roleId = msg.roleId
        )
        _uiState.update { st ->
            st.copy(
                chatMessages = st.chatMessages.map { if (it.id == msgId) it.copy(savedToJournal = true) else it },
                journalEntries = listOf(newEntry) + st.journalEntries
            )
        }
        showToast("Saved to Journal timeline.")
    }

    fun clearConversation() {
        _uiState.update { it.copy(chatMessages = emptyList()) }
        showToast("Conversation cleared.")
    }

    fun eraseEverything() {
        _uiState.update {
            it.copy(
                chatMessages = emptyList(),
                journalEntries = emptyList(),
                createdArtifacts = emptyList(),
                voiceLockEnrolled = false,
                saveConversations = true
            )
        }
        showToast("All local memory and creations erased.")
    }

    fun setChatTabMode(mode: Int) {
        _uiState.update { it.copy(chatTabMode = mode) }
    }

    fun runCodingBuild(promptText: String) {
        val clean = promptText.trim().ifEmpty { "Interactive Student Flashcard App" }
        _uiState.update { it.copy(codingPrompt = clean, isBuildingCode = true) }
        viewModelScope.launch {
            delay(1300L)
            val newItem = BuildHistoryItem(
                id = "b_${System.currentTimeMillis()}",
                prompt = clean,
                title = clean.take(28),
                timestamp = "Just now",
                summary = "Compiled HTML/CSS/JS bundle • Responsive 412dp viewport",
                accent = _uiState.value.activeTheme.accent
            )
            _uiState.update {
                it.copy(
                    isBuildingCode = false,
                    buildHistory = listOf(newItem) + it.buildHistory,
                    activePreviewBuild = newItem
                )
            }
            showToast("Build ready! Tap Save ZIP or Share.")
        }
    }

    fun addCreatedArtifact(type: CreateProjectType, title: String, style: String, details: String) {
        val item = CreatedArtifact(
            id = "art_${System.currentTimeMillis()}",
            type = type,
            title = title.ifBlank { type.title },
            style = style,
            previewSummary = details.ifBlank { "Generated cleanly with ${_uiState.value.activeRole.name} formatting." },
            createdAt = "Just now"
        )
        _uiState.update { it.copy(createdArtifacts = listOf(item) + it.createdArtifacts) }
        if (type == CreateProjectType.JOURNAL_ENTRY) {
            _uiState.update {
                it.copy(
                    journalEntries = listOf(
                        JournalEntry(
                            id = "j_${System.currentTimeMillis()}",
                            dateLabel = "Today • Just now",
                            mood = style,
                            title = title.ifBlank { "Evening Reflection" },
                            body = details,
                            roleId = it.activeRole.id
                        )
                    ) + it.journalEntries
                )
            }
        }
    }

    fun openMissionHud(task: TaskItem? = null) {
        missionJob?.cancel()
        val chosen = task ?: MockData.sampleTasks.first()
        _uiState.update { it.copy(activeMission = chosen, showMissionHud = true) }
        if (chosen.status == TaskRunStatus.RUNNING) {
            missionJob = viewModelScope.launch {
                while (true) {
                    delay(1000L)
                    _uiState.update { st ->
                        val m = st.activeMission
                        if (m.status != TaskRunStatus.RUNNING) return@update st
                        val nextProgress = (m.progress + 0.04f).coerceAtMost(1f)
                        val nextStatus = if (nextProgress >= 1f) TaskRunStatus.SUCCESS else TaskRunStatus.RUNNING
                        st.copy(
                            activeMission = m.copy(
                                elapsedSeconds = m.elapsedSeconds + 1,
                                progress = nextProgress,
                                status = nextStatus,
                                liveLine = if (nextStatus == TaskRunStatus.SUCCESS) {
                                    "Mission completed cleanly!"
                                } else m.liveLine,
                                steps = if (nextStatus == TaskRunStatus.SUCCESS) {
                                    m.steps.map { it.copy(status = TaskStepStatus.DONE) }
                                } else m.steps
                            )
                        )
                    }
                }
            }
        }
    }

    fun stopMission() {
        missionJob?.cancel()
        _uiState.update {
            it.copy(
                activeMission = it.activeMission.copy(
                    status = TaskRunStatus.STOPPED,
                    liveLine = "Stopped safely by user."
                )
            )
        }
    }

    fun failMissionDemo() {
        missionJob?.cancel()
        _uiState.update {
            it.copy(
                activeMission = it.activeMission.copy(
                    status = TaskRunStatus.FAILED,
                    liveLine = "Lava pocket detected at Y -58. Retreated safely."
                )
            )
        }
    }

    fun closeMissionHud() {
        missionJob?.cancel()
        _uiState.update { it.copy(showMissionHud = false) }
    }

    // Study timer
    fun toggleStudyTimer(forceStart: Boolean = false) {
        val next = if (forceStart) true else !_uiState.value.studyRunning
        _uiState.update { it.copy(studyRunning = next) }
        studyJob?.cancel()
        if (next) {
            studyJob = viewModelScope.launch {
                while (_uiState.value.studyRunning && _uiState.value.studySecondsLeft > 0) {
                    delay(1000L)
                    _uiState.update { it.copy(studySecondsLeft = (it.studySecondsLeft - 1).coerceAtLeast(0)) }
                }
            }
        }
    }

    fun resetStudyTimer() {
        studyJob?.cancel()
        _uiState.update { it.copy(studyRunning = false, studySecondsLeft = 25 * 60) }
    }

    fun selectQuizAnswer(optionIdx: Int) {
        _uiState.update { it.copy(quizSelectedOption = optionIdx) }
    }

    fun nextQuizCard() {
        _uiState.update {
            it.copy(
                quizIndex = (it.quizIndex + 1) % MockData.studyQuizzes.size,
                quizSelectedOption = null
            )
        }
    }

    // Widgets mutations
    fun toggleMusicPlay() {
        _uiState.update { it.copy(music = it.music.copy(isPlaying = !it.music.isPlaying)) }
    }

    fun selectTrack(title: String) {
        _uiState.update { it.copy(music = it.music.copy(title = title, isPlaying = true, progress = 0.15f)) }
    }

    fun toggleReminder(id: String) {
        _uiState.update { st ->
            st.copy(
                reminders = st.reminders.copy(
                    items = st.reminders.items.map { if (it.id == id) it.copy(done = !it.done) else it }
                )
            )
        }
    }

    fun toggleWifi() {
        _uiState.update { it.copy(deviceStatus = it.deviceStatus.copy(wifiOn = !it.deviceStatus.wifiOn)) }
    }

    fun toggleMobileData() {
        _uiState.update { it.copy(deviceStatus = it.deviceStatus.copy(mobileDataOn = !it.deviceStatus.mobileDataOn)) }
    }

    fun toggleBluetooth() {
        _uiState.update { it.copy(deviceStatus = it.deviceStatus.copy(bluetoothOn = !it.deviceStatus.bluetoothOn)) }
    }

    fun toggleFlashlight() {
        _uiState.update { it.copy(quickToggles = it.quickToggles.copy(flashlightOn = !it.quickToggles.flashlightOn)) }
    }

    fun toggleVolume() {
        _uiState.update { it.copy(quickToggles = it.quickToggles.copy(volumeHigh = !it.quickToggles.volumeHigh)) }
    }

    fun toggleDnd() {
        val next = !_uiState.value.quickToggles.dndOn
        val mgr = automationManager
        if (mgr != null) {
            val res = mgr.setDoNotDisturb(next)
            showToast(res.message)
        }
        _uiState.update { it.copy(quickToggles = it.quickToggles.copy(dndOn = next)) }
    }

    fun setAllWidgetsMode(mode: WidgetModeState) {
        _uiState.update {
            it.copy(
                weather = it.weather.copy(state = mode),
                today = it.today.copy(state = mode),
                mood = it.mood.copy(state = mode),
                battery = it.battery.copy(state = mode),
                reminders = it.reminders.copy(state = mode),
                music = it.music.copy(state = mode),
                deviceStatus = it.deviceStatus.copy(state = mode),
                quickToggles = it.quickToggles.copy(state = mode)
            )
        }
    }

    // Setup wizard & Permissions
    fun togglePermission(key: String, forceValue: Boolean? = null) {
        val mgr = automationManager
        if (mgr != null && forceValue == null) {
            when (key) {
                "accessibility" -> {
                    mgr.openSystemSettings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                    showToast("Enable 'Jarvis System Automation' in Accessibility Settings.")
                    return
                }
                "notifications" -> {
                    mgr.openSystemSettings(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    showToast("Enable 'Jarvis Notification Manager' in Notification Access.")
                    return
                }
                "battery" -> {
                    mgr.openSystemSettings(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                    showToast("Set Jarvis to Unrestricted battery usage.")
                    return
                }
            }
        }
        _uiState.update { st ->
            st.copy(
                permissions = st.permissions.map { p ->
                    if (p.key == key) p.copy(granted = forceValue ?: !p.granted) else p
                }
            )
        }
    }

    fun setWizardStep(step: Int) {
        _uiState.update { it.copy(wizardStepIndex = step.coerceIn(0, 7), wizardFinished = false) }
    }

    fun finishWizard() {
        _uiState.update { it.copy(wizardFinished = true) }
    }

    // Settings updates
    fun selectProvider(id: String) {
        _uiState.update { it.copy(selectedProviderId = id) }
    }

    fun updateProviderKey(id: String, newKey: String) {
        _uiState.update { st ->
            st.copy(
                providers = st.providers.map { p ->
                    if (p.id == id) p.copy(apiKey = newKey, keyTestedOk = null) else p
                }
            )
        }
    }

    fun testProviderKey(id: String) {
        _uiState.update { st ->
            st.copy(
                providers = st.providers.map { p ->
                    if (p.id == id) {
                        val valid = p.apiKey.trim().length >= 8
                        p.copy(keyTestedOk = valid)
                    } else p
                }
            )
        }
    }

    fun selectProviderModel(id: String, model: String) {
        _uiState.update { st ->
            st.copy(
                providers = st.providers.map { p -> if (p.id == id) p.copy(selectedModel = model) else p },
                diagnostics = st.diagnostics.copy(modelName = model)
            )
        }
    }

    fun selectVoice(voiceId: String) {
        _uiState.update { it.copy(selectedVoiceId = voiceId) }
    }

    fun setReplyPause(sec: Float) {
        _uiState.update { it.copy(replyPauseSec = sec) }
    }

    fun setAutoSwitchRole(enabled: Boolean) {
        _uiState.update { it.copy(autoSwitchRole = enabled) }
    }

    fun setEmotionStyle(style: String) {
        _uiState.update { it.copy(emotionStyle = style) }
    }

    fun setAudioRoute(route: AudioRoute) {
        _uiState.update {
            it.copy(
                diagnostics = it.diagnostics.copy(
                    route = route,
                    echoSuspected = route == AudioRoute.SPEAKER && !it.diagnostics.halfDuplexMode
                )
            )
        }
    }

    fun setHalfDuplexMode(enabled: Boolean) {
        _uiState.update {
            it.copy(
                diagnostics = it.diagnostics.copy(
                    halfDuplexMode = enabled,
                    echoSuspected = it.diagnostics.route == AudioRoute.SPEAKER && !enabled
                )
            )
        }
    }

    fun setSaveConversations(enabled: Boolean) {
        _uiState.update { it.copy(saveConversations = enabled) }
    }

    fun enrollVoiceLock() {
        _uiState.update { it.copy(voiceLockEnrolled = true) }
        showToast("Voice print enrolled cleanly.")
    }

    fun toggleCustomAvatarSlot(index: Int) {
        _uiState.update { st ->
            val updated = st.customAvatarSlots.toMutableList()
            updated[index] = if (updated[index] == null) "Custom Look ${index + 1}" else null
            st.copy(customAvatarSlots = updated)
        }
    }

    fun toggleAvatarRemoveBg() {
        _uiState.update { it.copy(avatarRemoveBg = !it.avatarRemoveBg) }
    }

    fun updatePattern(pattern: List<Int>) {
        _uiState.update { it.copy(savedPattern = pattern, patternTestResult = null) }
    }

    fun setPatternTuning(speedMs: Float, scale: Float) {
        _uiState.update { it.copy(patternSpeedMs = speedMs, patternScale = scale) }
    }

    fun testUnlockPattern() {
        val len = _uiState.value.savedPattern.size
        val mgr = automationManager
        val msg = if (len >= 4 && mgr != null && mgr.runtimeState.value.accessibilityEnabled) {
            mgr.runPatternUnlockGesture(_uiState.value.savedPattern, _uiState.value.patternSpeedMs, _uiState.value.patternScale).message
        } else if (len >= 4) {
            "Pattern swipe (${len} nodes @ ${_uiState.value.patternSpeedMs.toInt()}ms) validated. Enable Accessibility to dispatch on lock screen."
        } else {
            "Too short: use at least 4 dots to avoid lockouts."
        }
        _uiState.update { it.copy(patternTestResult = msg) }
    }

    fun toggleMasterNotifications() {
        _uiState.update { it.copy(notificationsEnabled = !it.notificationsEnabled) }
    }

    fun toggleAppNotification(app: String) {
        _uiState.update { st ->
            val map = st.appNotificationToggles.toMutableMap()
            map[app] = !(map[app] ?: false)
            st.copy(appNotificationToggles = map)
        }
    }

    fun toggleSavedAccount(platform: String) {
        _uiState.update { st ->
            val map = st.savedAccounts.toMutableMap()
            map[platform] = !(map[platform] ?: false)
            st.copy(savedAccounts = map)
        }
    }

    fun dismissOverlayNotification(id: String) {
        val mgr = automationManager
        if (mgr != null && mgr.runtimeState.value.notificationListenerEnabled) {
            mgr.dismissNotification(id)
        }
        _uiState.update { st ->
            st.copy(overlayNotifications = st.overlayNotifications.filterNot { it.id == id })
        }
    }

    fun setEdgeBanner(banner: EdgeErrorBanner) {
        reconnectJob?.cancel()
        _uiState.update {
            it.copy(
                edgeBanner = banner,
                reconnectCountdownSec = 5,
                assistantState = when (banner) {
                    EdgeErrorBanner.NO_INTERNET -> AssistantState.OFFLINE
                    EdgeErrorBanner.INVALID_API_KEY, EdgeErrorBanner.FREE_LIMIT,
                    EdgeErrorBanner.MIC_BUSY, EdgeErrorBanner.ACCESSIBILITY_OFF,
                    EdgeErrorBanner.PERMISSION_DENIED -> AssistantState.ERROR
                    EdgeErrorBanner.RECONNECTING -> AssistantState.CONNECTING
                    EdgeErrorBanner.NONE -> AssistantState.IDLE
                }
            )
        }
        if (banner == EdgeErrorBanner.RECONNECTING) {
            reconnectJob = viewModelScope.launch {
                for (s in 4 downTo 1) {
                    delay(1000L)
                    _uiState.update { it.copy(reconnectCountdownSec = s) }
                }
                _uiState.update {
                    it.copy(
                        edgeBanner = EdgeErrorBanner.NONE,
                        assistantState = AssistantState.IDLE
                    )
                }
                showToast("Reconnected cleanly.")
            }
        }
    }

    fun showToast(message: String, undoRole: RoleId? = null) {
        toastJob?.cancel()
        _uiState.update { it.copy(toastMessage = message, toastUndoRole = undoRole) }
        toastJob = viewModelScope.launch {
            delay(3600L)
            _uiState.update { it.copy(toastMessage = null, toastUndoRole = null) }
        }
    }

    fun undoRoleSwitch() {
        val prev = _uiState.value.toastUndoRole ?: return
        selectRole(prev, isAutoSwitch = false)
        _uiState.update { it.copy(toastMessage = null, toastUndoRole = null) }
    }

    fun dismissToast() {
        toastJob?.cancel()
        _uiState.update { it.copy(toastMessage = null, toastUndoRole = null) }
    }
}
