package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.automation.SystemAutomationManager
import com.example.viewmodel.JarvisViewModel
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SystemAutomationTest {

    @Test
    fun `automation catalog includes BGMI Minecraft and Free Fire`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val manager = SystemAutomationManager(context)
        val ids = manager.runtimeState.value.targetApps.map { it.id }

        assertTrue(ids.contains("app_bgmi"))
        assertTrue(ids.contains("app_minecraft"))
        assertTrue(ids.contains("app_freefire"))
        assertFalse(manager.runtimeState.value.executionLog.isEmpty())
    }

    @Test
    fun `viewmodel binds automation manager and executes command routing`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val viewModel = JarvisViewModel()
        viewModel.bindSystemAutomation(context)

        val initialLogSize = viewModel.uiState.value.automation.executionLog.size
        viewModel.launchSystemApp("app_bgmi")
        viewModel.executeScreenLock()

        val log = viewModel.uiState.value.automation.executionLog
        assertTrue(log.size > initialLogSize)
        assertTrue(log.any { it.title.contains("BGMI") })
        assertTrue(log.any { it.title.contains("Lock Screen") })
    }
}
