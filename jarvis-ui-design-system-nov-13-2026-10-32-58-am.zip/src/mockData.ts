export type AssistantState =
  | 'idle'
  | 'connecting'
  | 'listening'
  | 'thinking'
  | 'speaking'
  | 'interrupted'
  | 'muted'
  | 'error'
  | 'offline';

export type BackgroundStyle = 'cosmic_nebula' | 'aurora_blobs' | 'cyber_grid' | 'matrix_rain' | 'plain_gradient';

export interface Role {
  id: 'jarvis' | 'companion' | 'big_brother' | 'little_brother' | 'sister' | 'best_friend' | 'mentor' | 'listener';
  name: string;
  tagline: string;
  accent: string;
  accent2: string;
  voiceName: string;
  characterAssets: {
    basePortrait: string;
    eyesOpen: string;
    eyesClosed: string;
    mouthVisemes: string[];
    expressionOverlays: string[];
    glowLayer: string;
    background: string;
  };
  backgroundMood: string;
}

export interface Theme {
  id: string;
  name: string;
  bgTop: string;
  bgBottom: string;
  accent: string;
  accent2: string;
  backgroundStyle: BackgroundStyle;
  isLight: boolean;
}

export interface ChatMessage {
  id: string;
  kind: 'user' | 'assistant' | 'system';
  text: string;
  time: string;
  roleId: Role['id'];
  language: 'en' | 'hi' | 'hinglish';
}

export interface Task {
  id: string;
  title: string;
  kind: 'game' | 'social' | 'media' | 'create';
  steps: { id: string; label: string; status: 'pending' | 'active' | 'done' | 'failed' }[];
  status: 'running' | 'success' | 'failed' | 'stopped';
  startedAt: string;
}

export interface WeatherWidget {
  tempC: number;
  condition: string;
  highC: number;
  lowC: number;
  rainChancePct: number;
  city: string;
}

export interface BatteryWidget {
  percent: number;
  isCharging: boolean;
  estimatedTime: string;
}

export interface MusicWidget {
  title: string;
  artist: string;
  isPlaying: boolean;
  progress: number;
  queue: string[];
}

export interface ReminderWidget {
  items: { id: string; title: string; dueTime: string; done: boolean }[];
}

export interface DeviceStatusWidget {
  wifiOn: boolean;
  mobileDataOn: boolean;
  bluetoothOn: boolean;
}

export interface PermissionStatus {
  key: string;
  label: string;
  why: string;
  granted: boolean;
  fixAction: string;
}

export interface Diagnostics {
  connection: string;
  modelName: string;
  lastError: string;
  micLevel: number;
  route: 'speaker' | 'headphones' | 'bluetooth';
  echoSuspected: boolean;
  reconnectLog: string[];
}

export const ROLES: Role[] = [
  {
    id: 'jarvis',
    name: 'Jarvis',
    tagline: 'Calm, precise, cosmic HUD',
    accent: '#8B5CF6',
    accent2: '#00F5D4',
    voiceName: 'Aarav Neural',
    characterAssets: {
      basePortrait: 'char_jarvis_hoodie',
      eyesOpen: 'char_jarvis_eyes_open',
      eyesClosed: 'char_jarvis_eyes_closed',
      mouthVisemes: ['closed', 'small_open', 'wide_open', 'round_o', 'smile_open'],
      expressionOverlays: ['neutral', 'happy', 'sad', 'angry', 'surprised', 'thinking', 'listening', 'love_warm', 'sleepy_idle'],
      glowLayer: 'char_jarvis_glow',
      background: 'char_jarvis_cosmic_banner'
    },
    backgroundMood: 'Cosmic HUD & Starlight'
  },
  {
    id: 'companion',
    name: 'Companion',
    tagline: 'Warm, caring close friend (platonic)',
    accent: '#FF6FA5',
    accent2: '#FFB3D1',
    voiceName: 'Ananya Warm',
    characterAssets: {
      basePortrait: 'char_companion_base',
      eyesOpen: 'char_companion_eyes_open',
      eyesClosed: 'char_companion_eyes_closed',
      mouthVisemes: ['closed', 'small_open', 'wide_open', 'round_o', 'smile_open'],
      expressionOverlays: ['neutral', 'happy', 'sad', 'angry', 'surprised', 'thinking', 'listening', 'love_warm', 'sleepy_idle'],
      glowLayer: 'char_companion_glow',
      background: 'char_companion_bg'
    },
    backgroundMood: 'Golden Friendship Warmth'
  },
  {
    id: 'big_brother',
    name: 'Big Brother',
    tagline: 'Strong, protective, steady',
    accent: '#4FA3FF',
    accent2: '#8FB8FF',
    voiceName: 'Vikram Deep',
    characterAssets: {
      basePortrait: 'char_big_brother_base',
      eyesOpen: 'char_big_brother_eyes_open',
      eyesClosed: 'char_big_brother_eyes_closed',
      mouthVisemes: ['closed', 'small_open', 'wide_open', 'round_o', 'smile_open'],
      expressionOverlays: ['neutral', 'happy', 'sad', 'angry', 'surprised', 'thinking', 'listening', 'love_warm', 'sleepy_idle'],
      glowLayer: 'char_big_brother_glow',
      background: 'char_big_brother_bg'
    },
    backgroundMood: 'Steady Steel Horizon'
  },
  {
    id: 'little_brother',
    name: 'Little Brother',
    tagline: 'Playful, energetic, bright',
    accent: '#FF8A3D',
    accent2: '#FFD166',
    voiceName: 'Rohan Spark',
    characterAssets: {
      basePortrait: 'char_little_brother_base',
      eyesOpen: 'char_little_brother_eyes_open',
      eyesClosed: 'char_little_brother_eyes_closed',
      mouthVisemes: ['closed', 'small_open', 'wide_open', 'round_o', 'smile_open'],
      expressionOverlays: ['neutral', 'happy', 'sad', 'angry', 'surprised', 'thinking', 'listening', 'love_warm', 'sleepy_idle'],
      glowLayer: 'char_little_brother_glow',
      background: 'char_little_brother_bg'
    },
    backgroundMood: 'Bright Amber Spark'
  },
  {
    id: 'sister',
    name: 'Sister',
    tagline: 'Caring, observant, calm teal',
    accent: '#3DDBC0',
    accent2: '#8EF5E3',
    voiceName: 'Meera Clear',
    characterAssets: {
      basePortrait: 'char_sister_base',
      eyesOpen: 'char_sister_eyes_open',
      eyesClosed: 'char_sister_eyes_closed',
      mouthVisemes: ['closed', 'small_open', 'wide_open', 'round_o', 'smile_open'],
      expressionOverlays: ['neutral', 'happy', 'sad', 'angry', 'surprised', 'thinking', 'listening', 'love_warm', 'sleepy_idle'],
      glowLayer: 'char_sister_glow',
      background: 'char_sister_bg'
    },
    backgroundMood: 'Calm Teal Breeze'
  },
  {
    id: 'best_friend',
    name: 'Best Friend',
    tagline: 'Witty, playful, headset ready',
    accent: '#7CFF6B',
    accent2: '#B6FF6B',
    voiceName: 'Kabir Vibe',
    characterAssets: {
      basePortrait: 'char_best_friend_base',
      eyesOpen: 'char_best_friend_eyes_open',
      eyesClosed: 'char_best_friend_eyes_closed',
      mouthVisemes: ['closed', 'small_open', 'wide_open', 'round_o', 'smile_open'],
      expressionOverlays: ['neutral', 'happy', 'sad', 'angry', 'surprised', 'thinking', 'listening', 'love_warm', 'sleepy_idle'],
      glowLayer: 'char_best_friend_glow',
      background: 'char_best_friend_bg'
    },
    backgroundMood: 'Arcade Neon Glow'
  },
  {
    id: 'mentor',
    name: 'Mentor',
    tagline: 'Intelligent, composed, focused',
    accent: '#B388FF',
    accent2: '#D8C2FF',
    voiceName: 'Dr. Sen Sage',
    characterAssets: {
      basePortrait: 'char_mentor_base',
      eyesOpen: 'char_mentor_eyes_open',
      eyesClosed: 'char_mentor_eyes_closed',
      mouthVisemes: ['closed', 'small_open', 'wide_open', 'round_o', 'smile_open'],
      expressionOverlays: ['neutral', 'happy', 'sad', 'angry', 'surprised', 'thinking', 'listening', 'love_warm', 'sleepy_idle'],
      glowLayer: 'char_mentor_glow',
      background: 'char_mentor_bg'
    },
    backgroundMood: 'Editorial Library Violet'
  },
  {
    id: 'listener',
    name: 'Listener',
    tagline: 'Gentle, patient, supportive',
    accent: '#8FB8FF',
    accent2: '#C4B5FD',
    voiceName: 'Tara Soft',
    characterAssets: {
      basePortrait: 'char_listener_base',
      eyesOpen: 'char_listener_eyes_open',
      eyesClosed: 'char_listener_eyes_closed',
      mouthVisemes: ['closed', 'small_open', 'wide_open', 'round_o', 'smile_open'],
      expressionOverlays: ['neutral', 'happy', 'sad', 'angry', 'surprised', 'thinking', 'listening', 'love_warm', 'sleepy_idle'],
      glowLayer: 'char_listener_glow',
      background: 'char_listener_bg'
    },
    backgroundMood: 'Twilight Lavender Mist'
  }
];

export const THEMES: Theme[] = [
  { id: 'cosmic_nebula', name: 'Cosmic Nebula', bgTop: '#050314', bgBottom: '#170B3B', accent: '#8B5CF6', accent2: '#00F5D4', backgroundStyle: 'cosmic_nebula', isLight: false },
  { id: 'starlight_cyber', name: 'Starlight Cyber', bgTop: '#06071A', bgBottom: '#16123E', accent: '#38BDF8', accent2: '#F472B6', backgroundStyle: 'cosmic_nebula', isLight: false },
  { id: 'hyper_acid', name: 'Hyper Volt', bgTop: '#060A07', bgBottom: '#102214', accent: '#CCFF00', accent2: '#00F5D4', backgroundStyle: 'cyber_grid', isLight: false },
  { id: 'iron_gold', name: 'Iron Gold', bgTop: '#000000', bgBottom: '#1A1608', accent: '#C9A227', accent2: '#E8C766', backgroundStyle: 'aurora_blobs', isLight: false },
  { id: 'cyber_tech', name: 'Cyber Tech', bgTop: '#02060E', bgBottom: '#0A1F33', accent: '#00E5FF', accent2: '#7C4DFF', backgroundStyle: 'cyber_grid', isLight: false },
  { id: 'matrix', name: 'Matrix', bgTop: '#000000', bgBottom: '#001A06', accent: '#00FF41', accent2: '#00B82E', backgroundStyle: 'matrix_rain', isLight: false },
  { id: 'neon_future', name: 'Neon Future', bgTop: '#0A0014', bgBottom: '#1A0033', accent: '#FF2BD6', accent2: '#00E5FF', backgroundStyle: 'cyber_grid', isLight: false },
  { id: 'dark_luxury', name: 'Dark Luxury', bgTop: '#0B0B0B', bgBottom: '#1C1712', accent: '#D4AF37', accent2: '#8B6B23', backgroundStyle: 'plain_gradient', isLight: false },
  { id: 'midnight_blue', name: 'Midnight Blue', bgTop: '#050B1F', bgBottom: '#0B1E4A', accent: '#4F8CFF', accent2: '#8FB8FF', backgroundStyle: 'aurora_blobs', isLight: false },
  { id: 'anime_gaming', name: 'Anime Gaming', bgTop: '#0D0221', bgBottom: '#2A0A5E', accent: '#B388FF', accent2: '#FF4FD8', backgroundStyle: 'cosmic_nebula', isLight: false },
  { id: 'ocean', name: 'Ocean', bgTop: '#021A24', bgBottom: '#04485E', accent: '#21D4FD', accent2: '#2AF598', backgroundStyle: 'aurora_blobs', isLight: false },
  { id: 'sunset', name: 'Sunset', bgTop: '#1A0510', bgBottom: '#4A1A12', accent: '#FF7A3D', accent2: '#FF3D6E', backgroundStyle: 'aurora_blobs', isLight: false },
  { id: 'carbon_red', name: 'Carbon Red', bgTop: '#0A0A0A', bgBottom: '#1A0505', accent: '#FF1744', accent2: '#FF8A80', backgroundStyle: 'cyber_grid', isLight: false },
  { id: 'aurora', name: 'Aurora', bgTop: '#04121A', bgBottom: '#0A2A2A', accent: '#5CFFB5', accent2: '#7C9CFF', backgroundStyle: 'aurora_blobs', isLight: false },
  { id: 'stealth', name: 'Stealth', bgTop: '#0D0D0D', bgBottom: '#151515', accent: '#E0E0E0', accent2: '#9E9E9E', backgroundStyle: 'plain_gradient', isLight: false },
  { id: 'forest', name: 'Forest', bgTop: '#06150A', bgBottom: '#0F2E17', accent: '#6BFF8A', accent2: '#B6FF6B', backgroundStyle: 'aurora_blobs', isLight: false },
  { id: 'glassmorphism', name: 'Glassmorphism', bgTop: '#0E1424', bgBottom: '#1B2A4A', accent: '#9CC9FF', accent2: '#B388FF', backgroundStyle: 'aurora_blobs', isLight: false },
  { id: 'purple_fantasy', name: 'Purple Fantasy', bgTop: '#120626', bgBottom: '#2B0F55', accent: '#B26BFF', accent2: '#FF6BD6', backgroundStyle: 'cosmic_nebula', isLight: false },
  { id: 'rose', name: 'Rose', bgTop: '#1A0A12', bgBottom: '#3A1226', accent: '#FF6FA5', accent2: '#FFB3D1', backgroundStyle: 'plain_gradient', isLight: false },
  { id: 'light_mode', name: 'Light Mode', bgTop: '#F6F3EE', bgBottom: '#E8E2D8', accent: '#6A4AFF', accent2: '#B05A2A', backgroundStyle: 'plain_gradient', isLight: true },
  { id: 'follow_role', name: 'Follow Role', bgTop: '#05070E', bgBottom: '#141926', accent: '#8B5CF6', accent2: '#00F5D4', backgroundStyle: 'cosmic_nebula', isLight: false }
];
